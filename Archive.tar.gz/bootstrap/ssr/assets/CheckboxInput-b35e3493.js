import { a as jsx, F as Fragment } from "../ssr.js";
import { forwardRef, useRef, useEffect } from "react";
const CheckboxInput = forwardRef(function CheckboxInput2({ className = "", isFocused = false, svgIcon = /* @__PURE__ */ jsx(Fragment, {}), ...props }, ref) {
  const input = ref ? ref : useRef();
  useEffect(() => {
    if (isFocused) {
      input.current.focus();
    }
  }, []);
  return /* @__PURE__ */ jsx(
    "input",
    {
      ...props,
      type: "checkbox",
      className: "rounded w-4 h-4 text-sky-600 bg-gray-10 border-gray-300 focus:ring-sky-500 focus:ring-2 " + className,
      ref: input
    }
  );
});
export {
  CheckboxInput as C
};
