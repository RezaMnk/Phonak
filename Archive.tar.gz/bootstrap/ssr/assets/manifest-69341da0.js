const manifest = {
  "AuthenticatedLayout.css": {
    file: "assets/AuthenticatedLayout-b7bb1ac5.css",
    src: "AuthenticatedLayout.css"
  },
  "_AidInputs-1b6574ba.js": {
    file: "assets/AidInputs-1b6574ba.js",
    imports: [
      "resources/js/app.jsx",
      "_SelectInput-4ee34345.js",
      "_InputError-fb5e5bab.js",
      "_PrimaryButton-41aa3ab9.js",
      "_DangerButton-9763b115.js",
      "_AuthenticatedLayout-3a042c2b.js",
      "resources/js/Pages/Records/Components/Steps.jsx",
      "_TextInput-d082d320.js",
      "_TextAreaInput-6c201eca.js",
      "_IranStatesOptions-a068597e.js",
      "_FileInput-385ae1e5.js",
      "_RadioInput-f09411c8.js",
      "_InputLabel-3c24f6f9.js",
      "resources/js/Pages/Records/Components/ProductsSlider.jsx",
      "_useFirstRender-165c4719.js",
      "_CheckboxInput-f6846b35.js",
      "_Icon-873486fb.js"
    ],
    isDynamicEntry: true
  },
  "_ApplicationLogo-cfda91b2.js": {
    file: "assets/ApplicationLogo-cfda91b2.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_ArrowLink-a77c7f13.js": {
    file: "assets/ArrowLink-a77c7f13.js",
    imports: [
      "resources/js/app.jsx",
      "__commonjs-dynamic-modules-302442b1.js"
    ]
  },
  "_AuthenticatedLayout-3a042c2b.js": {
    css: [
      "assets/AuthenticatedLayout-b7bb1ac5.css"
    ],
    file: "assets/AuthenticatedLayout-3a042c2b.js",
    imports: [
      "resources/js/app.jsx",
      "_useMemorable-4be81a3e.js",
      "_ApplicationLogo-cfda91b2.js",
      "_Icon-873486fb.js"
    ]
  },
  "_CheckboxInput-f6846b35.js": {
    file: "assets/CheckboxInput-f6846b35.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_Create-ad0846f8.js": {
    file: "assets/Create-ad0846f8.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-3a042c2b.js",
      "_TextInput-d082d320.js",
      "_InputError-fb5e5bab.js",
      "_TextAreaInput-6c201eca.js",
      "_PrimaryButton-41aa3ab9.js",
      "_SelectInput-4ee34345.js",
      "_RadioInput-f09411c8.js",
      "_InputLabel-3c24f6f9.js",
      "resources/js/Pages/Accessories/Components/ProductsSlider.jsx",
      "_CheckboxInput-f6846b35.js",
      "_DangerButton-9763b115.js",
      "_Icon-873486fb.js"
    ],
    isDynamicEntry: true
  },
  "_DangerButton-9763b115.js": {
    file: "assets/DangerButton-9763b115.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_FileInput-385ae1e5.js": {
    file: "assets/FileInput-385ae1e5.js",
    imports: [
      "resources/js/app.jsx",
      "_Icon-873486fb.js",
      "_PrimaryButton-41aa3ab9.js"
    ]
  },
  "_GuestLayout-ee865871.js": {
    file: "assets/GuestLayout-ee865871.js",
    imports: [
      "resources/js/app.jsx",
      "_ApplicationLogo-cfda91b2.js",
      "_useMemorable-4be81a3e.js"
    ]
  },
  "_Icon-873486fb.js": {
    file: "assets/Icon-873486fb.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_InputError-fb5e5bab.js": {
    file: "assets/InputError-fb5e5bab.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_InputLabel-3c24f6f9.js": {
    file: "assets/InputLabel-3c24f6f9.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_IranStatesOptions-a068597e.js": {
    file: "assets/IranStatesOptions-a068597e.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_Modal-7528bbdc.js": {
    file: "assets/Modal-7528bbdc.js",
    imports: [
      "resources/js/app.jsx",
      "_transition-b2d11c5b.js"
    ]
  },
  "_Pagination-f99f7d58.js": {
    file: "assets/Pagination-f99f7d58.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_PrimaryButton-41aa3ab9.js": {
    file: "assets/PrimaryButton-41aa3ab9.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_RadioInput-f09411c8.js": {
    file: "assets/RadioInput-f09411c8.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_SecondaryButton-1080542a.js": {
    file: "assets/SecondaryButton-1080542a.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_SelectInput-4ee34345.js": {
    file: "assets/SelectInput-4ee34345.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_TextAreaInput-6c201eca.js": {
    file: "assets/TextAreaInput-6c201eca.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_TextInput-d082d320.js": {
    file: "assets/TextInput-d082d320.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_WarningButton-b446794c.js": {
    file: "assets/WarningButton-b446794c.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "__commonjs-dynamic-modules-302442b1.js": {
    file: "assets/_commonjs-dynamic-modules-302442b1.js"
  },
  "_index-ddcea41e.js": {
    file: "assets/index-ddcea41e.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_lottie-react.esm-1f7b7f77.js": {
    file: "assets/lottie-react.esm-1f7b7f77.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_manifest-c6b54637.js": {
    file: "assets/manifest-c6b54637.js"
  },
  "_pagination-b348de9d.js": {
    css: [
      "assets/pagination-211b41b8.css"
    ],
    file: "assets/pagination-b348de9d.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_transition-b2d11c5b.js": {
    file: "assets/transition-b2d11c5b.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_useFirstRender-165c4719.js": {
    file: "assets/useFirstRender-165c4719.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_useMemorable-4be81a3e.js": {
    file: "assets/useMemorable-4be81a3e.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "pagination.css": {
    file: "assets/pagination-211b41b8.css",
    src: "pagination.css"
  },
  "resources/fonts/woff/Dana-Black.woff": {
    file: "assets/Dana-Black-575de1e5.woff",
    src: "resources/fonts/woff/Dana-Black.woff"
  },
  "resources/fonts/woff/Dana-DemiBold.woff": {
    file: "assets/Dana-DemiBold-fa427dcf.woff",
    src: "resources/fonts/woff/Dana-DemiBold.woff"
  },
  "resources/fonts/woff/Dana-ExtraBlack.woff": {
    file: "assets/Dana-ExtraBlack-6c729c23.woff",
    src: "resources/fonts/woff/Dana-ExtraBlack.woff"
  },
  "resources/fonts/woff/Dana-ExtraBold.woff": {
    file: "assets/Dana-ExtraBold-0d7888d7.woff",
    src: "resources/fonts/woff/Dana-ExtraBold.woff"
  },
  "resources/fonts/woff/Dana-Fat.woff": {
    file: "assets/Dana-Fat-8831a7f0.woff",
    src: "resources/fonts/woff/Dana-Fat.woff"
  },
  "resources/fonts/woff/Dana-Hairline.woff": {
    file: "assets/Dana-Hairline-6d7bb084.woff",
    src: "resources/fonts/woff/Dana-Hairline.woff"
  },
  "resources/fonts/woff/Dana-Heavy.woff": {
    file: "assets/Dana-Heavy-e159608a.woff",
    src: "resources/fonts/woff/Dana-Heavy.woff"
  },
  "resources/fonts/woff/Dana-Light.woff": {
    file: "assets/Dana-Light-eeed4155.woff",
    src: "resources/fonts/woff/Dana-Light.woff"
  },
  "resources/fonts/woff/Dana-Medium.woff": {
    file: "assets/Dana-Medium-d0241b30.woff",
    src: "resources/fonts/woff/Dana-Medium.woff"
  },
  "resources/fonts/woff/Dana-Regular.woff": {
    file: "assets/Dana-Regular-eee25c04.woff",
    src: "resources/fonts/woff/Dana-Regular.woff"
  },
  "resources/fonts/woff/Dana-Thin.woff": {
    file: "assets/Dana-Thin-56dc1e1f.woff",
    src: "resources/fonts/woff/Dana-Thin.woff"
  },
  "resources/fonts/woff/Dana-UltraLight.woff": {
    file: "assets/Dana-UltraLight-a025f30e.woff",
    src: "resources/fonts/woff/Dana-UltraLight.woff"
  },
  "resources/fonts/woff2/Dana-Black.woff2": {
    file: "assets/Dana-Black-cdfe2203.woff2",
    src: "resources/fonts/woff2/Dana-Black.woff2"
  },
  "resources/fonts/woff2/Dana-DemiBold.woff2": {
    file: "assets/Dana-DemiBold-34870445.woff2",
    src: "resources/fonts/woff2/Dana-DemiBold.woff2"
  },
  "resources/fonts/woff2/Dana-ExtraBlack.woff2": {
    file: "assets/Dana-ExtraBlack-3208afe0.woff2",
    src: "resources/fonts/woff2/Dana-ExtraBlack.woff2"
  },
  "resources/fonts/woff2/Dana-ExtraBold.woff2": {
    file: "assets/Dana-ExtraBold-08dea612.woff2",
    src: "resources/fonts/woff2/Dana-ExtraBold.woff2"
  },
  "resources/fonts/woff2/Dana-Fat.woff2": {
    file: "assets/Dana-Fat-1f7b7061.woff2",
    src: "resources/fonts/woff2/Dana-Fat.woff2"
  },
  "resources/fonts/woff2/Dana-Hairline.woff2": {
    file: "assets/Dana-Hairline-7712cf11.woff2",
    src: "resources/fonts/woff2/Dana-Hairline.woff2"
  },
  "resources/fonts/woff2/Dana-Heavy.woff2": {
    file: "assets/Dana-Heavy-091eb261.woff2",
    src: "resources/fonts/woff2/Dana-Heavy.woff2"
  },
  "resources/fonts/woff2/Dana-Light.woff2": {
    file: "assets/Dana-Light-e07a4868.woff2",
    src: "resources/fonts/woff2/Dana-Light.woff2"
  },
  "resources/fonts/woff2/Dana-Medium.woff2": {
    file: "assets/Dana-Medium-d623f857.woff2",
    src: "resources/fonts/woff2/Dana-Medium.woff2"
  },
  "resources/fonts/woff2/Dana-Regular.woff2": {
    file: "assets/Dana-Regular-43506011.woff2",
    src: "resources/fonts/woff2/Dana-Regular.woff2"
  },
  "resources/fonts/woff2/Dana-Thin.woff2": {
    file: "assets/Dana-Thin-bec2bd8a.woff2",
    src: "resources/fonts/woff2/Dana-Thin.woff2"
  },
  "resources/fonts/woff2/Dana-UltraLight.woff2": {
    file: "assets/Dana-UltraLight-24615a03.woff2",
    src: "resources/fonts/woff2/Dana-UltraLight.woff2"
  },
  "resources/js/Pages/Accessories/Components/ProductsSlider.jsx": {
    file: "assets/ProductsSlider-03727b5f.js",
    imports: [
      "resources/js/app.jsx",
      "_pagination-b348de9d.js",
      "_RadioInput-f09411c8.js",
      "_InputLabel-3c24f6f9.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Accessories/Components/ProductsSlider.jsx"
  },
  "resources/js/Pages/Accessories/Index.jsx": {
    file: "assets/Index-9ec54998.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-3a042c2b.js",
      "_SecondaryButton-1080542a.js",
      "_DangerButton-9763b115.js",
      "_Modal-7528bbdc.js",
      "_PrimaryButton-41aa3ab9.js",
      "_Pagination-f99f7d58.js",
      "_useMemorable-4be81a3e.js",
      "_ApplicationLogo-cfda91b2.js",
      "_Icon-873486fb.js",
      "_transition-b2d11c5b.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Accessories/Index.jsx"
  },
  "resources/js/Pages/Accessories/Show.jsx": {
    file: "assets/Show-2e82ae01.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-3a042c2b.js",
      "_WarningButton-b446794c.js",
      "_PrimaryButton-41aa3ab9.js",
      "_SecondaryButton-1080542a.js",
      "_useMemorable-4be81a3e.js",
      "_ApplicationLogo-cfda91b2.js",
      "_Icon-873486fb.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Accessories/Show.jsx"
  },
  "resources/js/Pages/Admin/Accessories.jsx": {
    file: "assets/Accessories-89828025.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-3a042c2b.js",
      "_Pagination-f99f7d58.js",
      "_useFirstRender-165c4719.js",
      "_TextInput-d082d320.js",
      "_useMemorable-4be81a3e.js",
      "_ApplicationLogo-cfda91b2.js",
      "_Icon-873486fb.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Admin/Accessories.jsx"
  },
  "resources/js/Pages/Admin/Records.jsx": {
    file: "assets/Records-8e5af860.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-3a042c2b.js",
      "_Pagination-f99f7d58.js",
      "_TextInput-d082d320.js",
      "_useFirstRender-165c4719.js",
      "_useMemorable-4be81a3e.js",
      "_ApplicationLogo-cfda91b2.js",
      "_Icon-873486fb.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Admin/Records.jsx"
  },
  "resources/js/Pages/Auth/Address.jsx": {
    file: "assets/Address-981afe00.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-ee865871.js",
      "_InputError-fb5e5bab.js",
      "_PrimaryButton-41aa3ab9.js",
      "_TextInput-d082d320.js",
      "_TextAreaInput-6c201eca.js",
      "_RadioInput-f09411c8.js",
      "_InputLabel-3c24f6f9.js",
      "_Icon-873486fb.js",
      "_DangerButton-9763b115.js",
      "_ApplicationLogo-cfda91b2.js",
      "_useMemorable-4be81a3e.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Address.jsx"
  },
  "resources/js/Pages/Auth/ConfirmPassword.jsx": {
    file: "assets/ConfirmPassword-d9d5ee2b.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-ee865871.js",
      "_InputError-fb5e5bab.js",
      "_InputLabel-3c24f6f9.js",
      "_PrimaryButton-41aa3ab9.js",
      "_TextInput-d082d320.js",
      "_ApplicationLogo-cfda91b2.js",
      "_useMemorable-4be81a3e.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/ConfirmPassword.jsx"
  },
  "resources/js/Pages/Auth/ForgotPassword.jsx": {
    file: "assets/ForgotPassword-5f857b5c.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-ee865871.js",
      "_InputError-fb5e5bab.js",
      "_PrimaryButton-41aa3ab9.js",
      "_TextInput-d082d320.js",
      "_ApplicationLogo-cfda91b2.js",
      "_useMemorable-4be81a3e.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/ForgotPassword.jsx"
  },
  "resources/js/Pages/Auth/Info.jsx": {
    file: "assets/Info-c2591cf8.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-ee865871.js",
      "_InputError-fb5e5bab.js",
      "_PrimaryButton-41aa3ab9.js",
      "_TextInput-d082d320.js",
      "_TextAreaInput-6c201eca.js",
      "_FileInput-385ae1e5.js",
      "_InputLabel-3c24f6f9.js",
      "_ApplicationLogo-cfda91b2.js",
      "_useMemorable-4be81a3e.js",
      "_Icon-873486fb.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Info.jsx"
  },
  "resources/js/Pages/Auth/Login.jsx": {
    file: "assets/Login-bd3e4201.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-ee865871.js",
      "_InputError-fb5e5bab.js",
      "_InputLabel-3c24f6f9.js",
      "_PrimaryButton-41aa3ab9.js",
      "_TextInput-d082d320.js",
      "_CheckboxInput-f6846b35.js",
      "_WarningButton-b446794c.js",
      "_Icon-873486fb.js",
      "_ApplicationLogo-cfda91b2.js",
      "_useMemorable-4be81a3e.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Login.jsx"
  },
  "resources/js/Pages/Auth/Register.jsx": {
    file: "assets/Register-021172d1.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-ee865871.js",
      "_InputError-fb5e5bab.js",
      "_PrimaryButton-41aa3ab9.js",
      "_TextInput-d082d320.js",
      "_SelectInput-4ee34345.js",
      "_IranStatesOptions-a068597e.js",
      "_ApplicationLogo-cfda91b2.js",
      "_useMemorable-4be81a3e.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Register.jsx"
  },
  "resources/js/Pages/Auth/ResetPassword.jsx": {
    file: "assets/ResetPassword-569178d5.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-ee865871.js",
      "_InputError-fb5e5bab.js",
      "_PrimaryButton-41aa3ab9.js",
      "_TextInput-d082d320.js",
      "_ApplicationLogo-cfda91b2.js",
      "_useMemorable-4be81a3e.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/ResetPassword.jsx"
  },
  "resources/js/Pages/Auth/VerifyEmail.jsx": {
    file: "assets/VerifyEmail-06069d24.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-ee865871.js",
      "_PrimaryButton-41aa3ab9.js",
      "_ApplicationLogo-cfda91b2.js",
      "_useMemorable-4be81a3e.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/VerifyEmail.jsx"
  },
  "resources/js/Pages/Auth/WaitForVerify.jsx": {
    file: "assets/WaitForVerify-6733f8dc.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-ee865871.js",
      "_lottie-react.esm-1f7b7f77.js",
      "_PrimaryButton-41aa3ab9.js",
      "_DangerButton-9763b115.js",
      "_ApplicationLogo-cfda91b2.js",
      "_useMemorable-4be81a3e.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/WaitForVerify.jsx"
  },
  "resources/js/Pages/Dashboards/Admin.jsx": {
    file: "assets/Admin-f0f069f9.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-3a042c2b.js",
      "_ArrowLink-a77c7f13.js",
      "_useMemorable-4be81a3e.js",
      "_ApplicationLogo-cfda91b2.js",
      "_Icon-873486fb.js",
      "__commonjs-dynamic-modules-302442b1.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Dashboards/Admin.jsx"
  },
  "resources/js/Pages/Dashboards/User.jsx": {
    file: "assets/User-674cd063.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-3a042c2b.js",
      "_ArrowLink-a77c7f13.js",
      "_useMemorable-4be81a3e.js",
      "_ApplicationLogo-cfda91b2.js",
      "_Icon-873486fb.js",
      "__commonjs-dynamic-modules-302442b1.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Dashboards/User.jsx"
  },
  "resources/js/Pages/Download/Accessory.jsx": {
    file: "assets/Accessory-3016595d.js",
    imports: [
      "resources/js/app.jsx",
      "_manifest-c6b54637.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Download/Accessory.jsx"
  },
  "resources/js/Pages/Download/Record.jsx": {
    file: "assets/Record-de9ab612.js",
    imports: [
      "resources/js/app.jsx",
      "_manifest-c6b54637.js",
      "__commonjs-dynamic-modules-302442b1.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Download/Record.jsx"
  },
  "resources/js/Pages/Patients/Create.jsx": {
    file: "assets/Create-0ed44004.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-3a042c2b.js",
      "_TextInput-d082d320.js",
      "_InputError-fb5e5bab.js",
      "_TextAreaInput-6c201eca.js",
      "_PrimaryButton-41aa3ab9.js",
      "_SelectInput-4ee34345.js",
      "_IranStatesOptions-a068597e.js",
      "_DangerButton-9763b115.js",
      "_useMemorable-4be81a3e.js",
      "_ApplicationLogo-cfda91b2.js",
      "_Icon-873486fb.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Create.jsx"
  },
  "resources/js/Pages/Patients/Edit.jsx": {
    file: "assets/Edit-7c032484.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-3a042c2b.js",
      "_TextInput-d082d320.js",
      "_InputError-fb5e5bab.js",
      "_TextAreaInput-6c201eca.js",
      "_PrimaryButton-41aa3ab9.js",
      "_SelectInput-4ee34345.js",
      "_IranStatesOptions-a068597e.js",
      "_DangerButton-9763b115.js",
      "_useMemorable-4be81a3e.js",
      "_ApplicationLogo-cfda91b2.js",
      "_Icon-873486fb.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Edit.jsx"
  },
  "resources/js/Pages/Patients/Index.jsx": {
    file: "assets/Index-697ed52e.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-3a042c2b.js",
      "_SecondaryButton-1080542a.js",
      "_DangerButton-9763b115.js",
      "_Modal-7528bbdc.js",
      "_Pagination-f99f7d58.js",
      "_useMemorable-4be81a3e.js",
      "_ApplicationLogo-cfda91b2.js",
      "_Icon-873486fb.js",
      "_transition-b2d11c5b.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Index.jsx"
  },
  "resources/js/Pages/Patients/Partials/DeleteUserForm.jsx": {
    file: "assets/DeleteUserForm-dea70ddb.js",
    imports: [
      "resources/js/app.jsx",
      "_DangerButton-9763b115.js",
      "_InputError-fb5e5bab.js",
      "_InputLabel-3c24f6f9.js",
      "_Modal-7528bbdc.js",
      "_SecondaryButton-1080542a.js",
      "_TextInput-d082d320.js",
      "_transition-b2d11c5b.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Partials/DeleteUserForm.jsx"
  },
  "resources/js/Pages/Patients/Partials/UpdatePasswordForm.jsx": {
    file: "assets/UpdatePasswordForm-98857f67.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-fb5e5bab.js",
      "_InputLabel-3c24f6f9.js",
      "_PrimaryButton-41aa3ab9.js",
      "_TextInput-d082d320.js",
      "_transition-b2d11c5b.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Partials/UpdatePasswordForm.jsx"
  },
  "resources/js/Pages/Patients/Partials/UpdateProfileInformationForm.jsx": {
    file: "assets/UpdateProfileInformationForm-df075beb.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-fb5e5bab.js",
      "_InputLabel-3c24f6f9.js",
      "_PrimaryButton-41aa3ab9.js",
      "_TextInput-d082d320.js",
      "_transition-b2d11c5b.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Partials/UpdateProfileInformationForm.jsx"
  },
  "resources/js/Pages/Products/CreateOrEdit.jsx": {
    file: "assets/CreateOrEdit-12682491.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-3a042c2b.js",
      "_TextInput-d082d320.js",
      "_InputError-fb5e5bab.js",
      "_PrimaryButton-41aa3ab9.js",
      "_SelectInput-4ee34345.js",
      "_DangerButton-9763b115.js",
      "_Icon-873486fb.js",
      "_CheckboxInput-f6846b35.js",
      "_InputLabel-3c24f6f9.js",
      "_useMemorable-4be81a3e.js",
      "_ApplicationLogo-cfda91b2.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Products/CreateOrEdit.jsx"
  },
  "resources/js/Pages/Products/Index.jsx": {
    file: "assets/Index-7115a4d6.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-3a042c2b.js",
      "_SecondaryButton-1080542a.js",
      "_DangerButton-9763b115.js",
      "_Modal-7528bbdc.js",
      "_PrimaryButton-41aa3ab9.js",
      "_Pagination-f99f7d58.js",
      "_TextInput-d082d320.js",
      "_useMemorable-4be81a3e.js",
      "_ApplicationLogo-cfda91b2.js",
      "_Icon-873486fb.js",
      "_transition-b2d11c5b.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Products/Index.jsx"
  },
  "resources/js/Pages/Profile/Edit.jsx": {
    file: "assets/Edit-721e9f75.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-3a042c2b.js",
      "_GuestLayout-ee865871.js",
      "_TextInput-d082d320.js",
      "_InputError-fb5e5bab.js",
      "_TextAreaInput-6c201eca.js",
      "_PrimaryButton-41aa3ab9.js",
      "_DangerButton-9763b115.js",
      "_SelectInput-4ee34345.js",
      "_IranStatesOptions-a068597e.js",
      "_FileInput-385ae1e5.js",
      "_RadioInput-f09411c8.js",
      "_InputLabel-3c24f6f9.js",
      "_useMemorable-4be81a3e.js",
      "_ApplicationLogo-cfda91b2.js",
      "_Icon-873486fb.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Profile/Edit.jsx"
  },
  "resources/js/Pages/Profile/Index.jsx": {
    file: "assets/Index-ce59a05d.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-3a042c2b.js",
      "_WarningButton-b446794c.js",
      "_useMemorable-4be81a3e.js",
      "_ApplicationLogo-cfda91b2.js",
      "_Icon-873486fb.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Profile/Index.jsx"
  },
  "resources/js/Pages/Records/Components/ProductsSlider.jsx": {
    file: "assets/ProductsSlider-3a77a863.js",
    imports: [
      "resources/js/app.jsx",
      "_pagination-b348de9d.js",
      "_RadioInput-f09411c8.js",
      "_InputLabel-3c24f6f9.js",
      "_CheckboxInput-f6846b35.js",
      "_Icon-873486fb.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Components/ProductsSlider.jsx"
  },
  "resources/js/Pages/Records/Components/Steps.jsx": {
    file: "assets/Steps-44eb0373.js",
    imports: [
      "resources/js/app.jsx",
      "resources/js/Pages/Records/Partials/Step.jsx",
      "_Icon-873486fb.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Components/Steps.jsx"
  },
  "resources/js/Pages/Records/Index.jsx": {
    file: "assets/Index-51e8c681.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-3a042c2b.js",
      "_SecondaryButton-1080542a.js",
      "_DangerButton-9763b115.js",
      "_Modal-7528bbdc.js",
      "_PrimaryButton-41aa3ab9.js",
      "_Pagination-f99f7d58.js",
      "_useMemorable-4be81a3e.js",
      "_ApplicationLogo-cfda91b2.js",
      "_Icon-873486fb.js",
      "_transition-b2d11c5b.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Index.jsx"
  },
  "resources/js/Pages/Records/Partials/Step.jsx": {
    file: "assets/Step-4a9db97f.js",
    imports: [
      "resources/js/app.jsx"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Partials/Step.jsx"
  },
  "resources/js/Pages/Records/Show.jsx": {
    file: "assets/Show-27f81fd7.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-3a042c2b.js",
      "_WarningButton-b446794c.js",
      "_PrimaryButton-41aa3ab9.js",
      "_SecondaryButton-1080542a.js",
      "_useMemorable-4be81a3e.js",
      "_ApplicationLogo-cfda91b2.js",
      "_Icon-873486fb.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Show.jsx"
  },
  "resources/js/Pages/Settings/CreateOrEdit.jsx": {
    file: "assets/CreateOrEdit-61d79def.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-3a042c2b.js",
      "_TextInput-d082d320.js",
      "_InputError-fb5e5bab.js",
      "_PrimaryButton-41aa3ab9.js",
      "_DangerButton-9763b115.js",
      "_useMemorable-4be81a3e.js",
      "_ApplicationLogo-cfda91b2.js",
      "_Icon-873486fb.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/CreateOrEdit.jsx"
  },
  "resources/js/Pages/Settings/Index.jsx": {
    file: "assets/Index-c257a3b4.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-3a042c2b.js",
      "_SecondaryButton-1080542a.js",
      "_DangerButton-9763b115.js",
      "_Modal-7528bbdc.js",
      "_PrimaryButton-41aa3ab9.js",
      "_Pagination-f99f7d58.js",
      "_useMemorable-4be81a3e.js",
      "_ApplicationLogo-cfda91b2.js",
      "_Icon-873486fb.js",
      "_transition-b2d11c5b.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/Index.jsx"
  },
  "resources/js/Pages/Settings/OffLimits.jsx": {
    file: "assets/OffLimits-303dfafd.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-3a042c2b.js",
      "_PrimaryButton-41aa3ab9.js",
      "_lottie-react.esm-1f7b7f77.js",
      "_useMemorable-4be81a3e.js",
      "_ApplicationLogo-cfda91b2.js",
      "_Icon-873486fb.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/OffLimits.jsx"
  },
  "resources/js/Pages/Settings/OutOfSchedule.jsx": {
    file: "assets/OutOfSchedule-79a33948.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-3a042c2b.js",
      "_PrimaryButton-41aa3ab9.js",
      "_lottie-react.esm-1f7b7f77.js",
      "_useMemorable-4be81a3e.js",
      "_ApplicationLogo-cfda91b2.js",
      "_Icon-873486fb.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/OutOfSchedule.jsx"
  },
  "resources/js/Pages/Terms.jsx": {
    file: "assets/Terms-15e112dd.js",
    imports: [
      "resources/js/app.jsx",
      "_ApplicationLogo-cfda91b2.js",
      "_Icon-873486fb.js",
      "_PrimaryButton-41aa3ab9.js",
      "_index-ddcea41e.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Terms.jsx"
  },
  "resources/js/Pages/Users/Create.jsx": {
    file: "assets/Create-2a0b9cce.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-3a042c2b.js",
      "_TextInput-d082d320.js",
      "_InputError-fb5e5bab.js",
      "_TextAreaInput-6c201eca.js",
      "_PrimaryButton-41aa3ab9.js",
      "_SelectInput-4ee34345.js",
      "_IranStatesOptions-a068597e.js",
      "_DangerButton-9763b115.js",
      "_useMemorable-4be81a3e.js",
      "_ApplicationLogo-cfda91b2.js",
      "_Icon-873486fb.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Create.jsx"
  },
  "resources/js/Pages/Users/Edit.jsx": {
    file: "assets/Edit-96081394.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-3a042c2b.js",
      "_TextAreaInput-6c201eca.js",
      "_TextInput-d082d320.js",
      "_InputError-fb5e5bab.js",
      "_PrimaryButton-41aa3ab9.js",
      "_DangerButton-9763b115.js",
      "_SelectInput-4ee34345.js",
      "_WarningButton-b446794c.js",
      "_Modal-7528bbdc.js",
      "_CheckboxInput-f6846b35.js",
      "_InputLabel-3c24f6f9.js",
      "_useMemorable-4be81a3e.js",
      "_ApplicationLogo-cfda91b2.js",
      "_Icon-873486fb.js",
      "_transition-b2d11c5b.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Edit.jsx"
  },
  "resources/js/Pages/Users/Index.jsx": {
    file: "assets/Index-b281acde.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-3a042c2b.js",
      "_Pagination-f99f7d58.js",
      "_TextInput-d082d320.js",
      "_useFirstRender-165c4719.js",
      "_useMemorable-4be81a3e.js",
      "_ApplicationLogo-cfda91b2.js",
      "_Icon-873486fb.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Index.jsx"
  },
  "resources/js/Pages/Users/Partials/DeleteUserForm.jsx": {
    file: "assets/DeleteUserForm-5e6237b9.js",
    imports: [
      "resources/js/app.jsx",
      "_DangerButton-9763b115.js",
      "_InputError-fb5e5bab.js",
      "_InputLabel-3c24f6f9.js",
      "_Modal-7528bbdc.js",
      "_SecondaryButton-1080542a.js",
      "_TextInput-d082d320.js",
      "_transition-b2d11c5b.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Partials/DeleteUserForm.jsx"
  },
  "resources/js/Pages/Users/Partials/UpdatePasswordForm.jsx": {
    file: "assets/UpdatePasswordForm-20f0d51c.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-fb5e5bab.js",
      "_InputLabel-3c24f6f9.js",
      "_PrimaryButton-41aa3ab9.js",
      "_TextInput-d082d320.js",
      "_transition-b2d11c5b.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Partials/UpdatePasswordForm.jsx"
  },
  "resources/js/Pages/Users/Partials/UpdateProfileInformationForm.jsx": {
    file: "assets/UpdateProfileInformationForm-065a8994.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-fb5e5bab.js",
      "_InputLabel-3c24f6f9.js",
      "_PrimaryButton-41aa3ab9.js",
      "_TextInput-d082d320.js",
      "_transition-b2d11c5b.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Partials/UpdateProfileInformationForm.jsx"
  },
  "resources/js/Pages/Welcome.jsx": {
    file: "assets/Welcome-0936072d.js",
    imports: [
      "resources/js/app.jsx",
      "_ApplicationLogo-cfda91b2.js",
      "_Icon-873486fb.js",
      "_PrimaryButton-41aa3ab9.js",
      "_index-ddcea41e.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Welcome.jsx"
  },
  "resources/js/app.css": {
    file: "assets/app-cf48a240.css",
    src: "resources/js/app.css"
  },
  "resources/js/app.jsx": {
    assets: [
      "assets/Dana-Hairline-7712cf11.woff2",
      "assets/Dana-Hairline-6d7bb084.woff",
      "assets/Dana-Thin-bec2bd8a.woff2",
      "assets/Dana-Thin-56dc1e1f.woff",
      "assets/Dana-UltraLight-24615a03.woff2",
      "assets/Dana-UltraLight-a025f30e.woff",
      "assets/Dana-Light-e07a4868.woff2",
      "assets/Dana-Light-eeed4155.woff",
      "assets/Dana-Medium-d623f857.woff2",
      "assets/Dana-Medium-d0241b30.woff",
      "assets/Dana-DemiBold-34870445.woff2",
      "assets/Dana-DemiBold-fa427dcf.woff",
      "assets/Dana-ExtraBold-08dea612.woff2",
      "assets/Dana-ExtraBold-0d7888d7.woff",
      "assets/Dana-Black-cdfe2203.woff2",
      "assets/Dana-Black-575de1e5.woff",
      "assets/Dana-ExtraBlack-3208afe0.woff2",
      "assets/Dana-ExtraBlack-6c729c23.woff",
      "assets/Dana-Heavy-091eb261.woff2",
      "assets/Dana-Heavy-e159608a.woff",
      "assets/Dana-Fat-1f7b7061.woff2",
      "assets/Dana-Fat-8831a7f0.woff",
      "assets/Dana-Regular-43506011.woff2",
      "assets/Dana-Regular-eee25c04.woff"
    ],
    css: [
      "assets/app-cf48a240.css"
    ],
    dynamicImports: [
      "resources/js/Pages/Accessories/Components/ProductsSlider.jsx",
      "_Create-ad0846f8.js",
      "resources/js/Pages/Accessories/Index.jsx",
      "resources/js/Pages/Accessories/Show.jsx",
      "_Create-ad0846f8.js",
      "_Create-ad0846f8.js",
      "resources/js/Pages/Admin/Accessories.jsx",
      "resources/js/Pages/Admin/Records.jsx",
      "resources/js/Pages/Auth/Address.jsx",
      "resources/js/Pages/Auth/ConfirmPassword.jsx",
      "resources/js/Pages/Auth/ForgotPassword.jsx",
      "resources/js/Pages/Auth/Info.jsx",
      "resources/js/Pages/Auth/Login.jsx",
      "resources/js/Pages/Auth/Register.jsx",
      "resources/js/Pages/Auth/ResetPassword.jsx",
      "resources/js/Pages/Auth/VerifyEmail.jsx",
      "resources/js/Pages/Auth/WaitForVerify.jsx",
      "resources/js/Pages/Dashboards/Admin.jsx",
      "resources/js/Pages/Dashboards/User.jsx",
      "resources/js/Pages/Download/Accessory.jsx",
      "resources/js/Pages/Download/Record.jsx",
      "resources/js/Pages/Patients/Create.jsx",
      "resources/js/Pages/Patients/Edit.jsx",
      "resources/js/Pages/Patients/Index.jsx",
      "resources/js/Pages/Patients/Partials/DeleteUserForm.jsx",
      "resources/js/Pages/Patients/Partials/UpdatePasswordForm.jsx",
      "resources/js/Pages/Patients/Partials/UpdateProfileInformationForm.jsx",
      "resources/js/Pages/Products/CreateOrEdit.jsx",
      "resources/js/Pages/Products/Index.jsx",
      "resources/js/Pages/Profile/Edit.jsx",
      "resources/js/Pages/Profile/Index.jsx",
      "_AidInputs-1b6574ba.js",
      "resources/js/Pages/Records/Components/ProductsSlider.jsx",
      "resources/js/Pages/Records/Components/Steps.jsx",
      "_AidInputs-1b6574ba.js",
      "resources/js/Pages/Records/Index.jsx",
      "resources/js/Pages/Records/Partials/Step.jsx",
      "resources/js/Pages/Records/Show.jsx",
      "_AidInputs-1b6574ba.js",
      "_AidInputs-1b6574ba.js",
      "_AidInputs-1b6574ba.js",
      "_AidInputs-1b6574ba.js",
      "_AidInputs-1b6574ba.js",
      "resources/js/Pages/Settings/CreateOrEdit.jsx",
      "resources/js/Pages/Settings/Index.jsx",
      "resources/js/Pages/Settings/OffLimits.jsx",
      "resources/js/Pages/Settings/OutOfSchedule.jsx",
      "resources/js/Pages/Terms.jsx",
      "resources/js/Pages/Users/Create.jsx",
      "resources/js/Pages/Users/Edit.jsx",
      "resources/js/Pages/Users/Index.jsx",
      "resources/js/Pages/Users/Partials/DeleteUserForm.jsx",
      "resources/js/Pages/Users/Partials/UpdatePasswordForm.jsx",
      "resources/js/Pages/Users/Partials/UpdateProfileInformationForm.jsx",
      "resources/js/Pages/Welcome.jsx"
    ],
    file: "assets/app-95ff0ced.js",
    isEntry: true,
    src: "resources/js/app.jsx"
  }
};
export {
  manifest as m
};
