import { a as jsx, j as jsxs, F as Fragment } from "../ssr.js";
import { Pagination } from "swiper";
import { Swiper, SwiperSlide } from "swiper/react";
import { R as RadioInput } from "./RadioInput-a6c65c03.js";
import { I as InputLabel } from "./InputLabel-b9d20af6.js";
/* empty css                     */import { C as CheckboxInput } from "./CheckboxInput-b35e3493.js";
import { I as Icon } from "./Icon-2f3a2698.js";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react";
import "@inertiajs/react/server";
import "react";
const ProductsSlider = ({ products, product: selected_product, setProduct, setProductItems, productItems, productsItems, error }) => {
  return /* @__PURE__ */ jsx(
    Swiper,
    {
      pagination: {
        dynamicBullets: true,
        bulletClass: "bg-gray-300 dark:bg-slate-200 swiper-pagination-bullet"
      },
      modules: [Pagination],
      spaceBetween: 30,
      breakpoints: {
        576: {
          slidesPerView: 3
        },
        768: {
          slidesPerView: 5
        }
      },
      initialSlide: selected_product - 3 || 0,
      children: Object.values(products).map((product, key) => /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsxs(SwiperSlide, { children: [
          /* @__PURE__ */ jsx(
            RadioInput,
            {
              id: `product-` + product.id,
              className: "hidden peer",
              name: "product",
              checked: selected_product === product.id,
              onChange: () => setProduct(product.id)
            }
          ),
          /* @__PURE__ */ jsxs(
            InputLabel,
            {
              htmlFor: `product-` + product.id,
              className: `w-full relative bg-gray-100 dark:bg-slate-700 peer-checked:bg-sky-100 peer-checked:dark:bg-sky-900 cursor-pointer border ${error ? "border-red-200 dark:border-red-800" : "border-gray-200 dark:border-slate-500"} border-2 rounded-lg peer-checked:border-sky-400`,
              children: [
                selected_product === product.id && /* @__PURE__ */ jsx("div", { className: "absolute top-0 right-0", children: /* @__PURE__ */ jsx(Icon, { viewBox: "0 0 24 24", type: "fill", className: "fill-sky-400 dark:fill-sky-400", children: /* @__PURE__ */ jsxs(Fragment, { children: [
                  /* @__PURE__ */ jsx(
                    "path",
                    {
                      d: "M12 22C7.28595 22 4.92893 22 3.46447 20.5355C2 19.0711 2 16.714 2 12C2 7.28595 2 4.92893 3.46447 3.46447C4.92893 2 7.28595 2 12 2C16.714 2 19.0711 2 20.5355 3.46447C22 4.92893 22 7.28595 22 12C22 16.714 22 19.0711 20.5355 20.5355C19.0711 22 16.714 22 12 22Z"
                    }
                  ),
                  /* @__PURE__ */ jsx(
                    "path",
                    {
                      d: "M16.0303 8.96967C16.3232 9.26256 16.3232 9.73744 16.0303 10.0303L11.0303 15.0303C10.7374 15.3232 10.2626 15.3232 9.96967 15.0303L7.96967 13.0303C7.67678 12.7374 7.67678 12.2626 7.96967 11.9697C8.26256 11.6768 8.73744 11.6768 9.03033 11.9697L10.5 13.4393L14.9697 8.96967C15.2626 8.67678 15.7374 8.67678 16.0303 8.96967Z",
                      className: "fill-white dark:fill-slate-900"
                    }
                  )
                ] }) }) }),
                /* @__PURE__ */ jsxs("div", { className: "p-2", children: [
                  /* @__PURE__ */ jsx("img", { src: product.image_url, loading: "lazy", alt: product.id, className: "rounded-lg h-full w-full object-cover" }),
                  /* @__PURE__ */ jsx("hr", { className: "my-2 border-gray-200 dark:border-slate-500" }),
                  /* @__PURE__ */ jsxs("p", { className: "text-center text-xs font-bold", children: [
                    product.price.toLocaleString(),
                    " ریال"
                  ] }),
                  /* @__PURE__ */ jsx("hr", { className: "my-2 border-gray-200 dark:border-slate-500" }),
                  /* @__PURE__ */ jsx("p", { className: "text-center", children: product.name }),
                  /* @__PURE__ */ jsx("hr", { className: "my-2 border-gray-200 dark:border-slate-500" }),
                  /* @__PURE__ */ jsxs("p", { className: "text-center text-xs", children: [
                    /* @__PURE__ */ jsx("bdi", { className: "ml-1", children: "کد IRC:" }),
                    product.irc
                  ] })
                ] })
              ]
            }
          )
        ] }, key),
        selected_product === product.id && product.has_package && /* @__PURE__ */ jsxs(SwiperSlide, { children: [
          /* @__PURE__ */ jsx(
            CheckboxInput,
            {
              id: `product-package-` + product.id,
              className: "hidden peer",
              name: "product_package",
              checked: productItems.includes("package"),
              onChange: (e) => {
                if (e.target.checked) {
                  setProductItems([...productItems, "package"]);
                } else {
                  setProductItems(productItems.filter((item) => item !== "package"));
                }
              }
            }
          ),
          /* @__PURE__ */ jsxs(
            InputLabel,
            {
              htmlFor: `product-package-` + product.id,
              className: `w-full relative bg-yellow-50 dark:bg-yellow-800/20 peer-checked:bg-yellow-200 peer-checked:dark:bg-yellow-900 cursor-pointer border ${error ? "border-red-200 dark:border-red-800" : "border-yellow-200 dark:border-yellow-700"} border-2 rounded-lg peer-checked:border-yellow-400`,
              children: [
                productItems.includes("package") && /* @__PURE__ */ jsx("div", { className: "absolute top-0 right-0", children: /* @__PURE__ */ jsx(Icon, { viewBox: "0 0 24 24", type: "fill", className: "fill-yellow-400 dark:fill-yellow-400", children: /* @__PURE__ */ jsxs(Fragment, { children: [
                  /* @__PURE__ */ jsx(
                    "path",
                    {
                      d: "M12 22C7.28595 22 4.92893 22 3.46447 20.5355C2 19.0711 2 16.714 2 12C2 7.28595 2 4.92893 3.46447 3.46447C4.92893 2 7.28595 2 12 2C16.714 2 19.0711 2 20.5355 3.46447C22 4.92893 22 7.28595 22 12C22 16.714 22 19.0711 20.5355 20.5355C19.0711 22 16.714 22 12 22Z"
                    }
                  ),
                  /* @__PURE__ */ jsx(
                    "path",
                    {
                      d: "M16.0303 8.96967C16.3232 9.26256 16.3232 9.73744 16.0303 10.0303L11.0303 15.0303C10.7374 15.3232 10.2626 15.3232 9.96967 15.0303L7.96967 13.0303C7.67678 12.7374 7.67678 12.2626 7.96967 11.9697C8.26256 11.6768 8.73744 11.6768 9.03033 11.9697L10.5 13.4393L14.9697 8.96967C15.2626 8.67678 15.7374 8.67678 16.0303 8.96967Z",
                      className: "fill-white dark:fill-slate-900"
                    }
                  )
                ] }) }) }),
                /* @__PURE__ */ jsxs("div", { className: "p-2", children: [
                  /* @__PURE__ */ jsx("img", { src: product.image_url, loading: "lazy", alt: product.id, className: "rounded-lg h-full w-full object-cover" }),
                  /* @__PURE__ */ jsx("hr", { className: "my-2 border-yellow-200 dark:border-yellow-700" }),
                  /* @__PURE__ */ jsxs("p", { className: "text-center text-xs font-bold", children: [
                    product.package_price.toLocaleString(),
                    " ریال"
                  ] }),
                  /* @__PURE__ */ jsx("hr", { className: "my-2 border-yellow-200 dark:border-yellow-700" }),
                  /* @__PURE__ */ jsxs("p", { className: "text-center", children: [
                    "پکیج سمعک ",
                    product.name
                  ] })
                ] })
              ]
            }
          )
        ] }, "package-" + key),
        selected_product === product.id && product.has_mold && /* @__PURE__ */ jsxs(SwiperSlide, { children: [
          /* @__PURE__ */ jsx(
            CheckboxInput,
            {
              id: `product-mold-` + product.id,
              className: "hidden peer",
              name: "product_mold",
              checked: productItems.includes("mold"),
              onChange: (e) => {
                if (e.target.checked) {
                  setProductItems([...productItems, "mold"]);
                } else {
                  setProductItems(productItems.filter((item) => item !== "mold"));
                }
              }
            }
          ),
          /* @__PURE__ */ jsxs(
            InputLabel,
            {
              htmlFor: `product-mold-` + product.id,
              className: `w-full relative bg-green-50 dark:bg-green-800/20 peer-checked:bg-green-200 peer-checked:dark:bg-green-900 cursor-pointer border ${error ? "border-red-200 dark:border-red-800" : "border-green-200 dark:border-green-700"} border-2 rounded-lg peer-checked:border-green-400`,
              children: [
                productItems.includes("mold") && /* @__PURE__ */ jsx("div", { className: "absolute top-0 right-0", children: /* @__PURE__ */ jsx(Icon, { viewBox: "0 0 24 24", type: "fill", className: "fill-green-400 dark:fill-green-400", children: /* @__PURE__ */ jsxs(Fragment, { children: [
                  /* @__PURE__ */ jsx(
                    "path",
                    {
                      d: "M12 22C7.28595 22 4.92893 22 3.46447 20.5355C2 19.0711 2 16.714 2 12C2 7.28595 2 4.92893 3.46447 3.46447C4.92893 2 7.28595 2 12 2C16.714 2 19.0711 2 20.5355 3.46447C22 4.92893 22 7.28595 22 12C22 16.714 22 19.0711 20.5355 20.5355C19.0711 22 16.714 22 12 22Z"
                    }
                  ),
                  /* @__PURE__ */ jsx(
                    "path",
                    {
                      d: "M16.0303 8.96967C16.3232 9.26256 16.3232 9.73744 16.0303 10.0303L11.0303 15.0303C10.7374 15.3232 10.2626 15.3232 9.96967 15.0303L7.96967 13.0303C7.67678 12.7374 7.67678 12.2626 7.96967 11.9697C8.26256 11.6768 8.73744 11.6768 9.03033 11.9697L10.5 13.4393L14.9697 8.96967C15.2626 8.67678 15.7374 8.67678 16.0303 8.96967Z",
                      className: "fill-white dark:fill-slate-900"
                    }
                  )
                ] }) }) }),
                /* @__PURE__ */ jsxs("div", { className: "p-2", children: [
                  /* @__PURE__ */ jsx("img", { src: product.image_url, loading: "lazy", alt: product.id, className: "rounded-lg h-full w-full object-cover" }),
                  /* @__PURE__ */ jsx("hr", { className: "my-2 border-green-200 dark:border-green-700" }),
                  /* @__PURE__ */ jsxs("p", { className: "text-center text-xs font-bold", children: [
                    product.mold_price.toLocaleString(),
                    " ریال"
                  ] }),
                  /* @__PURE__ */ jsx("hr", { className: "my-2 border-green-200 dark:border-green-700" }),
                  /* @__PURE__ */ jsxs("p", { className: "text-center", children: [
                    "قالب سمعک ",
                    product.name
                  ] })
                ] })
              ]
            }
          )
        ] }, "mold-" + key),
        selected_product === product.id && product.has_charger && /* @__PURE__ */ jsxs(SwiperSlide, { children: [
          /* @__PURE__ */ jsx(
            CheckboxInput,
            {
              id: `product-charger-` + product.id,
              className: "hidden peer",
              name: "product_charger",
              checked: productItems.includes("charger"),
              onChange: (e) => {
                if (e.target.checked) {
                  setProductItems([...productItems, "charger"]);
                } else {
                  setProductItems(productItems.filter((item) => item !== "charger"));
                }
              }
            }
          ),
          /* @__PURE__ */ jsxs(
            InputLabel,
            {
              htmlFor: `product-charger-` + product.id,
              className: `w-full bg-violet-50 dark:bg-violet-800/20 peer-checked:bg-violet-200 peer-checked:dark:bg-violet-900 cursor-pointer border ${error ? "border-red-200 dark:border-red-800" : "border-violet-200 dark:border-violet-700"} border-2 rounded-lg peer-checked:border-violet-400`,
              children: [
                productItems.includes("charger") && /* @__PURE__ */ jsx("div", { className: "absolute top-0 right-0", children: /* @__PURE__ */ jsx(Icon, { viewBox: "0 0 24 24", type: "fill", className: "fill-violet-400 dark:fill-violet-400", children: /* @__PURE__ */ jsxs(Fragment, { children: [
                  /* @__PURE__ */ jsx(
                    "path",
                    {
                      d: "M12 22C7.28595 22 4.92893 22 3.46447 20.5355C2 19.0711 2 16.714 2 12C2 7.28595 2 4.92893 3.46447 3.46447C4.92893 2 7.28595 2 12 2C16.714 2 19.0711 2 20.5355 3.46447C22 4.92893 22 7.28595 22 12C22 16.714 22 19.0711 20.5355 20.5355C19.0711 22 16.714 22 12 22Z"
                    }
                  ),
                  /* @__PURE__ */ jsx(
                    "path",
                    {
                      d: "M16.0303 8.96967C16.3232 9.26256 16.3232 9.73744 16.0303 10.0303L11.0303 15.0303C10.7374 15.3232 10.2626 15.3232 9.96967 15.0303L7.96967 13.0303C7.67678 12.7374 7.67678 12.2626 7.96967 11.9697C8.26256 11.6768 8.73744 11.6768 9.03033 11.9697L10.5 13.4393L14.9697 8.96967C15.2626 8.67678 15.7374 8.67678 16.0303 8.96967Z",
                      className: "fill-white dark:fill-slate-900"
                    }
                  )
                ] }) }) }),
                /* @__PURE__ */ jsxs("div", { className: "p-2", children: [
                  /* @__PURE__ */ jsx("img", { src: product.image_url, loading: "lazy", alt: product.id, className: "rounded-lg h-full w-full object-cover" }),
                  /* @__PURE__ */ jsx("hr", { className: "my-2 border-violet-200 dark:border-violet-700" }),
                  /* @__PURE__ */ jsxs("p", { className: "text-center text-xs font-bold", children: [
                    product.charger_price.toLocaleString(),
                    " ریال"
                  ] }),
                  /* @__PURE__ */ jsx("hr", { className: "my-2 border-violet-200 dark:border-violet-700" }),
                  /* @__PURE__ */ jsxs("p", { className: "text-center", children: [
                    "شارژر سمعک ",
                    product.name
                  ] })
                ] })
              ]
            }
          )
        ] }, "charger-" + key)
      ] }, "div-" + key))
    }
  );
};
export {
  ProductsSlider as default
};
