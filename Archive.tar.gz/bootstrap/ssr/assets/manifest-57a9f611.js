const manifest = {
  "AuthenticatedLayout.css": {
    file: "assets/AuthenticatedLayout-3a83175c.css",
    src: "AuthenticatedLayout.css"
  },
  "_AidInputs-fcd0a7fe.js": {
    file: "assets/AidInputs-fcd0a7fe.js",
    imports: [
      "resources/js/app.jsx",
      "_SelectInput-5c69d683.js",
      "_InputError-d5c8b3fd.js",
      "_PrimaryButton-c2607c8e.js",
      "_DangerButton-7a257da6.js",
      "_AuthenticatedLayout-46e92118.js",
      "resources/js/Pages/Records/Components/Steps.jsx",
      "_TextInput-a311dfdb.js",
      "_TextAreaInput-c9c3c57b.js",
      "_IranStatesOptions-803b284a.js",
      "_FileInput-8ce9854a.js",
      "_RadioInput-b9d5fa94.js",
      "_InputLabel-f78ed7f5.js",
      "resources/js/Pages/Records/Components/ProductsSlider.jsx",
      "_useFirstRender-ccef18ab.js",
      "_CheckboxInput-69d52667.js",
      "_Icon-55744b42.js"
    ],
    isDynamicEntry: true
  },
  "_ApplicationLogo-3a59ca71.js": {
    file: "assets/ApplicationLogo-3a59ca71.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_ArrowLink-1dde1344.js": {
    file: "assets/ArrowLink-1dde1344.js",
    imports: [
      "resources/js/app.jsx",
      "__commonjs-dynamic-modules-302442b1.js"
    ]
  },
  "_AuthenticatedLayout-46e92118.js": {
    css: [
      "assets/AuthenticatedLayout-3a83175c.css"
    ],
    file: "assets/AuthenticatedLayout-46e92118.js",
    imports: [
      "resources/js/app.jsx",
      "_useMemorable-a29257ba.js",
      "_ApplicationLogo-3a59ca71.js",
      "_Icon-55744b42.js"
    ]
  },
  "_CheckboxInput-69d52667.js": {
    file: "assets/CheckboxInput-69d52667.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_Create-5884115e.js": {
    file: "assets/Create-5884115e.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-46e92118.js",
      "_TextInput-a311dfdb.js",
      "_InputError-d5c8b3fd.js",
      "_TextAreaInput-c9c3c57b.js",
      "_PrimaryButton-c2607c8e.js",
      "_SelectInput-5c69d683.js",
      "_RadioInput-b9d5fa94.js",
      "_InputLabel-f78ed7f5.js",
      "resources/js/Pages/Accessories/Components/ProductsSlider.jsx",
      "_CheckboxInput-69d52667.js",
      "_DangerButton-7a257da6.js",
      "_Icon-55744b42.js"
    ],
    isDynamicEntry: true
  },
  "_DangerButton-7a257da6.js": {
    file: "assets/DangerButton-7a257da6.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_FileInput-8ce9854a.js": {
    file: "assets/FileInput-8ce9854a.js",
    imports: [
      "resources/js/app.jsx",
      "_Icon-55744b42.js",
      "_PrimaryButton-c2607c8e.js"
    ]
  },
  "_GuestLayout-b5a348d4.js": {
    file: "assets/GuestLayout-b5a348d4.js",
    imports: [
      "resources/js/app.jsx",
      "_ApplicationLogo-3a59ca71.js",
      "_useMemorable-a29257ba.js"
    ]
  },
  "_Icon-55744b42.js": {
    file: "assets/Icon-55744b42.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_InputError-d5c8b3fd.js": {
    file: "assets/InputError-d5c8b3fd.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_InputLabel-f78ed7f5.js": {
    file: "assets/InputLabel-f78ed7f5.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_IranStatesOptions-803b284a.js": {
    file: "assets/IranStatesOptions-803b284a.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_Modal-2852e2bb.js": {
    file: "assets/Modal-2852e2bb.js",
    imports: [
      "resources/js/app.jsx",
      "_transition-cf187827.js"
    ]
  },
  "_Pagination-50c012a5.js": {
    file: "assets/Pagination-50c012a5.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_PrimaryButton-c2607c8e.js": {
    file: "assets/PrimaryButton-c2607c8e.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_RadioInput-b9d5fa94.js": {
    file: "assets/RadioInput-b9d5fa94.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_SecondaryButton-dfa7f132.js": {
    file: "assets/SecondaryButton-dfa7f132.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_SelectInput-5c69d683.js": {
    file: "assets/SelectInput-5c69d683.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_TextAreaInput-c9c3c57b.js": {
    file: "assets/TextAreaInput-c9c3c57b.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_TextInput-a311dfdb.js": {
    file: "assets/TextInput-a311dfdb.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_WarningButton-8c4dd501.js": {
    file: "assets/WarningButton-8c4dd501.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "__commonjs-dynamic-modules-302442b1.js": {
    file: "assets/_commonjs-dynamic-modules-302442b1.js"
  },
  "_index-cd14afc9.js": {
    file: "assets/index-cd14afc9.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_lottie-react.esm-97092771.js": {
    file: "assets/lottie-react.esm-97092771.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_manifest-5c25d49c.js": {
    file: "assets/manifest-5c25d49c.js"
  },
  "_pagination-79f20206.js": {
    css: [
      "assets/pagination-58c369bc.css"
    ],
    file: "assets/pagination-79f20206.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_transition-cf187827.js": {
    file: "assets/transition-cf187827.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_useFirstRender-ccef18ab.js": {
    file: "assets/useFirstRender-ccef18ab.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_useMemorable-a29257ba.js": {
    file: "assets/useMemorable-a29257ba.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "pagination.css": {
    file: "assets/pagination-58c369bc.css",
    src: "pagination.css"
  },
  "resources/fonts/woff/Dana-Black.woff": {
    file: "assets/Dana-Black-575de1e5.woff",
    src: "resources/fonts/woff/Dana-Black.woff"
  },
  "resources/fonts/woff/Dana-DemiBold.woff": {
    file: "assets/Dana-DemiBold-fa427dcf.woff",
    src: "resources/fonts/woff/Dana-DemiBold.woff"
  },
  "resources/fonts/woff/Dana-ExtraBlack.woff": {
    file: "assets/Dana-ExtraBlack-6c729c23.woff",
    src: "resources/fonts/woff/Dana-ExtraBlack.woff"
  },
  "resources/fonts/woff/Dana-ExtraBold.woff": {
    file: "assets/Dana-ExtraBold-0d7888d7.woff",
    src: "resources/fonts/woff/Dana-ExtraBold.woff"
  },
  "resources/fonts/woff/Dana-Fat.woff": {
    file: "assets/Dana-Fat-8831a7f0.woff",
    src: "resources/fonts/woff/Dana-Fat.woff"
  },
  "resources/fonts/woff/Dana-Hairline.woff": {
    file: "assets/Dana-Hairline-6d7bb084.woff",
    src: "resources/fonts/woff/Dana-Hairline.woff"
  },
  "resources/fonts/woff/Dana-Heavy.woff": {
    file: "assets/Dana-Heavy-e159608a.woff",
    src: "resources/fonts/woff/Dana-Heavy.woff"
  },
  "resources/fonts/woff/Dana-Light.woff": {
    file: "assets/Dana-Light-eeed4155.woff",
    src: "resources/fonts/woff/Dana-Light.woff"
  },
  "resources/fonts/woff/Dana-Medium.woff": {
    file: "assets/Dana-Medium-d0241b30.woff",
    src: "resources/fonts/woff/Dana-Medium.woff"
  },
  "resources/fonts/woff/Dana-Regular.woff": {
    file: "assets/Dana-Regular-eee25c04.woff",
    src: "resources/fonts/woff/Dana-Regular.woff"
  },
  "resources/fonts/woff/Dana-Thin.woff": {
    file: "assets/Dana-Thin-56dc1e1f.woff",
    src: "resources/fonts/woff/Dana-Thin.woff"
  },
  "resources/fonts/woff/Dana-UltraLight.woff": {
    file: "assets/Dana-UltraLight-a025f30e.woff",
    src: "resources/fonts/woff/Dana-UltraLight.woff"
  },
  "resources/fonts/woff2/Dana-Black.woff2": {
    file: "assets/Dana-Black-cdfe2203.woff2",
    src: "resources/fonts/woff2/Dana-Black.woff2"
  },
  "resources/fonts/woff2/Dana-DemiBold.woff2": {
    file: "assets/Dana-DemiBold-34870445.woff2",
    src: "resources/fonts/woff2/Dana-DemiBold.woff2"
  },
  "resources/fonts/woff2/Dana-ExtraBlack.woff2": {
    file: "assets/Dana-ExtraBlack-3208afe0.woff2",
    src: "resources/fonts/woff2/Dana-ExtraBlack.woff2"
  },
  "resources/fonts/woff2/Dana-ExtraBold.woff2": {
    file: "assets/Dana-ExtraBold-08dea612.woff2",
    src: "resources/fonts/woff2/Dana-ExtraBold.woff2"
  },
  "resources/fonts/woff2/Dana-Fat.woff2": {
    file: "assets/Dana-Fat-1f7b7061.woff2",
    src: "resources/fonts/woff2/Dana-Fat.woff2"
  },
  "resources/fonts/woff2/Dana-Hairline.woff2": {
    file: "assets/Dana-Hairline-7712cf11.woff2",
    src: "resources/fonts/woff2/Dana-Hairline.woff2"
  },
  "resources/fonts/woff2/Dana-Heavy.woff2": {
    file: "assets/Dana-Heavy-091eb261.woff2",
    src: "resources/fonts/woff2/Dana-Heavy.woff2"
  },
  "resources/fonts/woff2/Dana-Light.woff2": {
    file: "assets/Dana-Light-e07a4868.woff2",
    src: "resources/fonts/woff2/Dana-Light.woff2"
  },
  "resources/fonts/woff2/Dana-Medium.woff2": {
    file: "assets/Dana-Medium-d623f857.woff2",
    src: "resources/fonts/woff2/Dana-Medium.woff2"
  },
  "resources/fonts/woff2/Dana-Regular.woff2": {
    file: "assets/Dana-Regular-43506011.woff2",
    src: "resources/fonts/woff2/Dana-Regular.woff2"
  },
  "resources/fonts/woff2/Dana-Thin.woff2": {
    file: "assets/Dana-Thin-bec2bd8a.woff2",
    src: "resources/fonts/woff2/Dana-Thin.woff2"
  },
  "resources/fonts/woff2/Dana-UltraLight.woff2": {
    file: "assets/Dana-UltraLight-24615a03.woff2",
    src: "resources/fonts/woff2/Dana-UltraLight.woff2"
  },
  "resources/js/Pages/Accessories/Components/ProductsSlider.jsx": {
    file: "assets/ProductsSlider-177c273c.js",
    imports: [
      "resources/js/app.jsx",
      "_pagination-79f20206.js",
      "_RadioInput-b9d5fa94.js",
      "_InputLabel-f78ed7f5.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Accessories/Components/ProductsSlider.jsx"
  },
  "resources/js/Pages/Accessories/Index.jsx": {
    file: "assets/Index-5bf19d3e.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-46e92118.js",
      "_SecondaryButton-dfa7f132.js",
      "_DangerButton-7a257da6.js",
      "_Modal-2852e2bb.js",
      "_PrimaryButton-c2607c8e.js",
      "_Pagination-50c012a5.js",
      "_useMemorable-a29257ba.js",
      "_ApplicationLogo-3a59ca71.js",
      "_Icon-55744b42.js",
      "_transition-cf187827.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Accessories/Index.jsx"
  },
  "resources/js/Pages/Accessories/Show.jsx": {
    file: "assets/Show-10cf2869.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-46e92118.js",
      "_WarningButton-8c4dd501.js",
      "_PrimaryButton-c2607c8e.js",
      "_SecondaryButton-dfa7f132.js",
      "_useMemorable-a29257ba.js",
      "_ApplicationLogo-3a59ca71.js",
      "_Icon-55744b42.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Accessories/Show.jsx"
  },
  "resources/js/Pages/Admin/Accessories.jsx": {
    file: "assets/Accessories-a3e82fd1.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-46e92118.js",
      "_Pagination-50c012a5.js",
      "_useFirstRender-ccef18ab.js",
      "_TextInput-a311dfdb.js",
      "_useMemorable-a29257ba.js",
      "_ApplicationLogo-3a59ca71.js",
      "_Icon-55744b42.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Admin/Accessories.jsx"
  },
  "resources/js/Pages/Admin/Records.jsx": {
    file: "assets/Records-88779746.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-46e92118.js",
      "_Pagination-50c012a5.js",
      "_TextInput-a311dfdb.js",
      "_useFirstRender-ccef18ab.js",
      "_useMemorable-a29257ba.js",
      "_ApplicationLogo-3a59ca71.js",
      "_Icon-55744b42.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Admin/Records.jsx"
  },
  "resources/js/Pages/Auth/Address.jsx": {
    file: "assets/Address-e69e505f.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-b5a348d4.js",
      "_InputError-d5c8b3fd.js",
      "_PrimaryButton-c2607c8e.js",
      "_TextInput-a311dfdb.js",
      "_TextAreaInput-c9c3c57b.js",
      "_RadioInput-b9d5fa94.js",
      "_InputLabel-f78ed7f5.js",
      "_Icon-55744b42.js",
      "_DangerButton-7a257da6.js",
      "_ApplicationLogo-3a59ca71.js",
      "_useMemorable-a29257ba.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Address.jsx"
  },
  "resources/js/Pages/Auth/ConfirmPassword.jsx": {
    file: "assets/ConfirmPassword-3ce17763.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-b5a348d4.js",
      "_InputError-d5c8b3fd.js",
      "_InputLabel-f78ed7f5.js",
      "_PrimaryButton-c2607c8e.js",
      "_TextInput-a311dfdb.js",
      "_ApplicationLogo-3a59ca71.js",
      "_useMemorable-a29257ba.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/ConfirmPassword.jsx"
  },
  "resources/js/Pages/Auth/ForgotPassword.jsx": {
    file: "assets/ForgotPassword-a1fcc439.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-b5a348d4.js",
      "_InputError-d5c8b3fd.js",
      "_PrimaryButton-c2607c8e.js",
      "_TextInput-a311dfdb.js",
      "_ApplicationLogo-3a59ca71.js",
      "_useMemorable-a29257ba.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/ForgotPassword.jsx"
  },
  "resources/js/Pages/Auth/Info.jsx": {
    file: "assets/Info-1efa55cd.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-b5a348d4.js",
      "_InputError-d5c8b3fd.js",
      "_PrimaryButton-c2607c8e.js",
      "_TextInput-a311dfdb.js",
      "_TextAreaInput-c9c3c57b.js",
      "_FileInput-8ce9854a.js",
      "_InputLabel-f78ed7f5.js",
      "_ApplicationLogo-3a59ca71.js",
      "_useMemorable-a29257ba.js",
      "_Icon-55744b42.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Info.jsx"
  },
  "resources/js/Pages/Auth/Login.jsx": {
    file: "assets/Login-daff4284.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-b5a348d4.js",
      "_InputError-d5c8b3fd.js",
      "_InputLabel-f78ed7f5.js",
      "_PrimaryButton-c2607c8e.js",
      "_TextInput-a311dfdb.js",
      "_CheckboxInput-69d52667.js",
      "_WarningButton-8c4dd501.js",
      "_Icon-55744b42.js",
      "_ApplicationLogo-3a59ca71.js",
      "_useMemorable-a29257ba.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Login.jsx"
  },
  "resources/js/Pages/Auth/Register.jsx": {
    file: "assets/Register-57fea2e6.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-b5a348d4.js",
      "_InputError-d5c8b3fd.js",
      "_PrimaryButton-c2607c8e.js",
      "_TextInput-a311dfdb.js",
      "_SelectInput-5c69d683.js",
      "_IranStatesOptions-803b284a.js",
      "_ApplicationLogo-3a59ca71.js",
      "_useMemorable-a29257ba.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Register.jsx"
  },
  "resources/js/Pages/Auth/ResetPassword.jsx": {
    file: "assets/ResetPassword-be61430c.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-b5a348d4.js",
      "_InputError-d5c8b3fd.js",
      "_PrimaryButton-c2607c8e.js",
      "_TextInput-a311dfdb.js",
      "_ApplicationLogo-3a59ca71.js",
      "_useMemorable-a29257ba.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/ResetPassword.jsx"
  },
  "resources/js/Pages/Auth/VerifyEmail.jsx": {
    file: "assets/VerifyEmail-6e734cf8.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-b5a348d4.js",
      "_PrimaryButton-c2607c8e.js",
      "_ApplicationLogo-3a59ca71.js",
      "_useMemorable-a29257ba.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/VerifyEmail.jsx"
  },
  "resources/js/Pages/Auth/WaitForVerify.jsx": {
    file: "assets/WaitForVerify-ccd8d993.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-b5a348d4.js",
      "_lottie-react.esm-97092771.js",
      "_PrimaryButton-c2607c8e.js",
      "_DangerButton-7a257da6.js",
      "_ApplicationLogo-3a59ca71.js",
      "_useMemorable-a29257ba.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/WaitForVerify.jsx"
  },
  "resources/js/Pages/Dashboards/Admin.jsx": {
    file: "assets/Admin-fc8e4ffd.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-46e92118.js",
      "_ArrowLink-1dde1344.js",
      "_useMemorable-a29257ba.js",
      "_ApplicationLogo-3a59ca71.js",
      "_Icon-55744b42.js",
      "__commonjs-dynamic-modules-302442b1.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Dashboards/Admin.jsx"
  },
  "resources/js/Pages/Dashboards/User.jsx": {
    file: "assets/User-a89714ca.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-46e92118.js",
      "_ArrowLink-1dde1344.js",
      "_useMemorable-a29257ba.js",
      "_ApplicationLogo-3a59ca71.js",
      "_Icon-55744b42.js",
      "__commonjs-dynamic-modules-302442b1.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Dashboards/User.jsx"
  },
  "resources/js/Pages/Download/Accessory.jsx": {
    file: "assets/Accessory-f72b8f0e.js",
    imports: [
      "resources/js/app.jsx",
      "_manifest-5c25d49c.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Download/Accessory.jsx"
  },
  "resources/js/Pages/Download/Record.jsx": {
    file: "assets/Record-74af1a65.js",
    imports: [
      "resources/js/app.jsx",
      "_manifest-5c25d49c.js",
      "__commonjs-dynamic-modules-302442b1.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Download/Record.jsx"
  },
  "resources/js/Pages/Patients/Create.jsx": {
    file: "assets/Create-8c85226c.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-46e92118.js",
      "_TextInput-a311dfdb.js",
      "_InputError-d5c8b3fd.js",
      "_TextAreaInput-c9c3c57b.js",
      "_PrimaryButton-c2607c8e.js",
      "_SelectInput-5c69d683.js",
      "_IranStatesOptions-803b284a.js",
      "_DangerButton-7a257da6.js",
      "_useMemorable-a29257ba.js",
      "_ApplicationLogo-3a59ca71.js",
      "_Icon-55744b42.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Create.jsx"
  },
  "resources/js/Pages/Patients/Edit.jsx": {
    file: "assets/Edit-3c23b316.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-46e92118.js",
      "_TextInput-a311dfdb.js",
      "_InputError-d5c8b3fd.js",
      "_TextAreaInput-c9c3c57b.js",
      "_PrimaryButton-c2607c8e.js",
      "_SelectInput-5c69d683.js",
      "_IranStatesOptions-803b284a.js",
      "_DangerButton-7a257da6.js",
      "_useMemorable-a29257ba.js",
      "_ApplicationLogo-3a59ca71.js",
      "_Icon-55744b42.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Edit.jsx"
  },
  "resources/js/Pages/Patients/Index.jsx": {
    file: "assets/Index-52b5122c.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-46e92118.js",
      "_SecondaryButton-dfa7f132.js",
      "_DangerButton-7a257da6.js",
      "_Modal-2852e2bb.js",
      "_Pagination-50c012a5.js",
      "_useMemorable-a29257ba.js",
      "_ApplicationLogo-3a59ca71.js",
      "_Icon-55744b42.js",
      "_transition-cf187827.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Index.jsx"
  },
  "resources/js/Pages/Patients/Partials/DeleteUserForm.jsx": {
    file: "assets/DeleteUserForm-dc122e6e.js",
    imports: [
      "resources/js/app.jsx",
      "_DangerButton-7a257da6.js",
      "_InputError-d5c8b3fd.js",
      "_InputLabel-f78ed7f5.js",
      "_Modal-2852e2bb.js",
      "_SecondaryButton-dfa7f132.js",
      "_TextInput-a311dfdb.js",
      "_transition-cf187827.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Partials/DeleteUserForm.jsx"
  },
  "resources/js/Pages/Patients/Partials/UpdatePasswordForm.jsx": {
    file: "assets/UpdatePasswordForm-7b7f2f74.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-d5c8b3fd.js",
      "_InputLabel-f78ed7f5.js",
      "_PrimaryButton-c2607c8e.js",
      "_TextInput-a311dfdb.js",
      "_transition-cf187827.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Partials/UpdatePasswordForm.jsx"
  },
  "resources/js/Pages/Patients/Partials/UpdateProfileInformationForm.jsx": {
    file: "assets/UpdateProfileInformationForm-59166a34.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-d5c8b3fd.js",
      "_InputLabel-f78ed7f5.js",
      "_PrimaryButton-c2607c8e.js",
      "_TextInput-a311dfdb.js",
      "_transition-cf187827.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Partials/UpdateProfileInformationForm.jsx"
  },
  "resources/js/Pages/Products/CreateOrEdit.jsx": {
    file: "assets/CreateOrEdit-ed2831bb.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-46e92118.js",
      "_TextInput-a311dfdb.js",
      "_InputError-d5c8b3fd.js",
      "_PrimaryButton-c2607c8e.js",
      "_SelectInput-5c69d683.js",
      "_DangerButton-7a257da6.js",
      "_Icon-55744b42.js",
      "_CheckboxInput-69d52667.js",
      "_InputLabel-f78ed7f5.js",
      "_useMemorable-a29257ba.js",
      "_ApplicationLogo-3a59ca71.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Products/CreateOrEdit.jsx"
  },
  "resources/js/Pages/Products/Index.jsx": {
    file: "assets/Index-472342bd.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-46e92118.js",
      "_SecondaryButton-dfa7f132.js",
      "_DangerButton-7a257da6.js",
      "_Modal-2852e2bb.js",
      "_PrimaryButton-c2607c8e.js",
      "_Pagination-50c012a5.js",
      "_TextInput-a311dfdb.js",
      "_useMemorable-a29257ba.js",
      "_ApplicationLogo-3a59ca71.js",
      "_Icon-55744b42.js",
      "_transition-cf187827.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Products/Index.jsx"
  },
  "resources/js/Pages/Profile/Edit.jsx": {
    file: "assets/Edit-1eb52258.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-46e92118.js",
      "_GuestLayout-b5a348d4.js",
      "_TextInput-a311dfdb.js",
      "_InputError-d5c8b3fd.js",
      "_TextAreaInput-c9c3c57b.js",
      "_PrimaryButton-c2607c8e.js",
      "_DangerButton-7a257da6.js",
      "_SelectInput-5c69d683.js",
      "_IranStatesOptions-803b284a.js",
      "_FileInput-8ce9854a.js",
      "_RadioInput-b9d5fa94.js",
      "_InputLabel-f78ed7f5.js",
      "_useMemorable-a29257ba.js",
      "_ApplicationLogo-3a59ca71.js",
      "_Icon-55744b42.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Profile/Edit.jsx"
  },
  "resources/js/Pages/Profile/Index.jsx": {
    file: "assets/Index-b62e181f.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-46e92118.js",
      "_WarningButton-8c4dd501.js",
      "_useMemorable-a29257ba.js",
      "_ApplicationLogo-3a59ca71.js",
      "_Icon-55744b42.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Profile/Index.jsx"
  },
  "resources/js/Pages/Records/Components/ProductsSlider.jsx": {
    file: "assets/ProductsSlider-e0cd36a4.js",
    imports: [
      "resources/js/app.jsx",
      "_pagination-79f20206.js",
      "_RadioInput-b9d5fa94.js",
      "_InputLabel-f78ed7f5.js",
      "_CheckboxInput-69d52667.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Components/ProductsSlider.jsx"
  },
  "resources/js/Pages/Records/Components/Steps.jsx": {
    file: "assets/Steps-ccea973c.js",
    imports: [
      "resources/js/app.jsx",
      "resources/js/Pages/Records/Partials/Step.jsx",
      "_Icon-55744b42.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Components/Steps.jsx"
  },
  "resources/js/Pages/Records/Index.jsx": {
    file: "assets/Index-1b283ff2.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-46e92118.js",
      "_SecondaryButton-dfa7f132.js",
      "_DangerButton-7a257da6.js",
      "_Modal-2852e2bb.js",
      "_PrimaryButton-c2607c8e.js",
      "_Pagination-50c012a5.js",
      "_useMemorable-a29257ba.js",
      "_ApplicationLogo-3a59ca71.js",
      "_Icon-55744b42.js",
      "_transition-cf187827.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Index.jsx"
  },
  "resources/js/Pages/Records/Partials/Step.jsx": {
    file: "assets/Step-bea8ecba.js",
    imports: [
      "resources/js/app.jsx"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Partials/Step.jsx"
  },
  "resources/js/Pages/Records/Show.jsx": {
    file: "assets/Show-910ab786.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-46e92118.js",
      "_WarningButton-8c4dd501.js",
      "_PrimaryButton-c2607c8e.js",
      "_SecondaryButton-dfa7f132.js",
      "_useMemorable-a29257ba.js",
      "_ApplicationLogo-3a59ca71.js",
      "_Icon-55744b42.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Show.jsx"
  },
  "resources/js/Pages/Settings/CreateOrEdit.jsx": {
    file: "assets/CreateOrEdit-4d04d42f.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-46e92118.js",
      "_TextInput-a311dfdb.js",
      "_InputError-d5c8b3fd.js",
      "_PrimaryButton-c2607c8e.js",
      "_DangerButton-7a257da6.js",
      "_useMemorable-a29257ba.js",
      "_ApplicationLogo-3a59ca71.js",
      "_Icon-55744b42.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/CreateOrEdit.jsx"
  },
  "resources/js/Pages/Settings/Index.jsx": {
    file: "assets/Index-6f84d608.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-46e92118.js",
      "_SecondaryButton-dfa7f132.js",
      "_DangerButton-7a257da6.js",
      "_Modal-2852e2bb.js",
      "_PrimaryButton-c2607c8e.js",
      "_Pagination-50c012a5.js",
      "_useMemorable-a29257ba.js",
      "_ApplicationLogo-3a59ca71.js",
      "_Icon-55744b42.js",
      "_transition-cf187827.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/Index.jsx"
  },
  "resources/js/Pages/Settings/OffLimits.jsx": {
    file: "assets/OffLimits-d2d623eb.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-46e92118.js",
      "_PrimaryButton-c2607c8e.js",
      "_lottie-react.esm-97092771.js",
      "_useMemorable-a29257ba.js",
      "_ApplicationLogo-3a59ca71.js",
      "_Icon-55744b42.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/OffLimits.jsx"
  },
  "resources/js/Pages/Settings/OutOfSchedule.jsx": {
    file: "assets/OutOfSchedule-59d1ab35.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-46e92118.js",
      "_PrimaryButton-c2607c8e.js",
      "_lottie-react.esm-97092771.js",
      "_useMemorable-a29257ba.js",
      "_ApplicationLogo-3a59ca71.js",
      "_Icon-55744b42.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/OutOfSchedule.jsx"
  },
  "resources/js/Pages/Terms.jsx": {
    file: "assets/Terms-79fc9f3c.js",
    imports: [
      "resources/js/app.jsx",
      "_ApplicationLogo-3a59ca71.js",
      "_Icon-55744b42.js",
      "_PrimaryButton-c2607c8e.js",
      "_index-cd14afc9.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Terms.jsx"
  },
  "resources/js/Pages/Users/Create.jsx": {
    file: "assets/Create-289f2cf2.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-46e92118.js",
      "_TextInput-a311dfdb.js",
      "_InputError-d5c8b3fd.js",
      "_TextAreaInput-c9c3c57b.js",
      "_PrimaryButton-c2607c8e.js",
      "_SelectInput-5c69d683.js",
      "_IranStatesOptions-803b284a.js",
      "_DangerButton-7a257da6.js",
      "_useMemorable-a29257ba.js",
      "_ApplicationLogo-3a59ca71.js",
      "_Icon-55744b42.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Create.jsx"
  },
  "resources/js/Pages/Users/Edit.jsx": {
    file: "assets/Edit-5dd60c5b.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-46e92118.js",
      "_TextAreaInput-c9c3c57b.js",
      "_TextInput-a311dfdb.js",
      "_InputError-d5c8b3fd.js",
      "_PrimaryButton-c2607c8e.js",
      "_DangerButton-7a257da6.js",
      "_SelectInput-5c69d683.js",
      "_WarningButton-8c4dd501.js",
      "_Modal-2852e2bb.js",
      "_CheckboxInput-69d52667.js",
      "_InputLabel-f78ed7f5.js",
      "_useMemorable-a29257ba.js",
      "_ApplicationLogo-3a59ca71.js",
      "_Icon-55744b42.js",
      "_transition-cf187827.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Edit.jsx"
  },
  "resources/js/Pages/Users/Index.jsx": {
    file: "assets/Index-426e707d.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-46e92118.js",
      "_Pagination-50c012a5.js",
      "_TextInput-a311dfdb.js",
      "_useFirstRender-ccef18ab.js",
      "_useMemorable-a29257ba.js",
      "_ApplicationLogo-3a59ca71.js",
      "_Icon-55744b42.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Index.jsx"
  },
  "resources/js/Pages/Users/Partials/DeleteUserForm.jsx": {
    file: "assets/DeleteUserForm-e7a3d0d0.js",
    imports: [
      "resources/js/app.jsx",
      "_DangerButton-7a257da6.js",
      "_InputError-d5c8b3fd.js",
      "_InputLabel-f78ed7f5.js",
      "_Modal-2852e2bb.js",
      "_SecondaryButton-dfa7f132.js",
      "_TextInput-a311dfdb.js",
      "_transition-cf187827.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Partials/DeleteUserForm.jsx"
  },
  "resources/js/Pages/Users/Partials/UpdatePasswordForm.jsx": {
    file: "assets/UpdatePasswordForm-d7ef6b4e.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-d5c8b3fd.js",
      "_InputLabel-f78ed7f5.js",
      "_PrimaryButton-c2607c8e.js",
      "_TextInput-a311dfdb.js",
      "_transition-cf187827.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Partials/UpdatePasswordForm.jsx"
  },
  "resources/js/Pages/Users/Partials/UpdateProfileInformationForm.jsx": {
    file: "assets/UpdateProfileInformationForm-347e7162.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-d5c8b3fd.js",
      "_InputLabel-f78ed7f5.js",
      "_PrimaryButton-c2607c8e.js",
      "_TextInput-a311dfdb.js",
      "_transition-cf187827.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Partials/UpdateProfileInformationForm.jsx"
  },
  "resources/js/Pages/Welcome.jsx": {
    file: "assets/Welcome-d1927996.js",
    imports: [
      "resources/js/app.jsx",
      "_ApplicationLogo-3a59ca71.js",
      "_Icon-55744b42.js",
      "_PrimaryButton-c2607c8e.js",
      "_index-cd14afc9.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Welcome.jsx"
  },
  "resources/js/app.css": {
    file: "assets/app-4b746760.css",
    src: "resources/js/app.css"
  },
  "resources/js/app.jsx": {
    assets: [
      "assets/Dana-Hairline-7712cf11.woff2",
      "assets/Dana-Hairline-6d7bb084.woff",
      "assets/Dana-Thin-bec2bd8a.woff2",
      "assets/Dana-Thin-56dc1e1f.woff",
      "assets/Dana-UltraLight-24615a03.woff2",
      "assets/Dana-UltraLight-a025f30e.woff",
      "assets/Dana-Light-e07a4868.woff2",
      "assets/Dana-Light-eeed4155.woff",
      "assets/Dana-Medium-d623f857.woff2",
      "assets/Dana-Medium-d0241b30.woff",
      "assets/Dana-DemiBold-34870445.woff2",
      "assets/Dana-DemiBold-fa427dcf.woff",
      "assets/Dana-ExtraBold-08dea612.woff2",
      "assets/Dana-ExtraBold-0d7888d7.woff",
      "assets/Dana-Black-cdfe2203.woff2",
      "assets/Dana-Black-575de1e5.woff",
      "assets/Dana-ExtraBlack-3208afe0.woff2",
      "assets/Dana-ExtraBlack-6c729c23.woff",
      "assets/Dana-Heavy-091eb261.woff2",
      "assets/Dana-Heavy-e159608a.woff",
      "assets/Dana-Fat-1f7b7061.woff2",
      "assets/Dana-Fat-8831a7f0.woff",
      "assets/Dana-Regular-43506011.woff2",
      "assets/Dana-Regular-eee25c04.woff"
    ],
    css: [
      "assets/app-4b746760.css"
    ],
    dynamicImports: [
      "resources/js/Pages/Accessories/Components/ProductsSlider.jsx",
      "_Create-5884115e.js",
      "resources/js/Pages/Accessories/Index.jsx",
      "resources/js/Pages/Accessories/Show.jsx",
      "_Create-5884115e.js",
      "_Create-5884115e.js",
      "resources/js/Pages/Admin/Accessories.jsx",
      "resources/js/Pages/Admin/Records.jsx",
      "resources/js/Pages/Auth/Address.jsx",
      "resources/js/Pages/Auth/ConfirmPassword.jsx",
      "resources/js/Pages/Auth/ForgotPassword.jsx",
      "resources/js/Pages/Auth/Info.jsx",
      "resources/js/Pages/Auth/Login.jsx",
      "resources/js/Pages/Auth/Register.jsx",
      "resources/js/Pages/Auth/ResetPassword.jsx",
      "resources/js/Pages/Auth/VerifyEmail.jsx",
      "resources/js/Pages/Auth/WaitForVerify.jsx",
      "resources/js/Pages/Dashboards/Admin.jsx",
      "resources/js/Pages/Dashboards/User.jsx",
      "resources/js/Pages/Download/Accessory.jsx",
      "resources/js/Pages/Download/Record.jsx",
      "resources/js/Pages/Patients/Create.jsx",
      "resources/js/Pages/Patients/Edit.jsx",
      "resources/js/Pages/Patients/Index.jsx",
      "resources/js/Pages/Patients/Partials/DeleteUserForm.jsx",
      "resources/js/Pages/Patients/Partials/UpdatePasswordForm.jsx",
      "resources/js/Pages/Patients/Partials/UpdateProfileInformationForm.jsx",
      "resources/js/Pages/Products/CreateOrEdit.jsx",
      "resources/js/Pages/Products/Index.jsx",
      "resources/js/Pages/Profile/Edit.jsx",
      "resources/js/Pages/Profile/Index.jsx",
      "_AidInputs-fcd0a7fe.js",
      "resources/js/Pages/Records/Components/ProductsSlider.jsx",
      "resources/js/Pages/Records/Components/Steps.jsx",
      "_AidInputs-fcd0a7fe.js",
      "resources/js/Pages/Records/Index.jsx",
      "resources/js/Pages/Records/Partials/Step.jsx",
      "resources/js/Pages/Records/Show.jsx",
      "_AidInputs-fcd0a7fe.js",
      "_AidInputs-fcd0a7fe.js",
      "_AidInputs-fcd0a7fe.js",
      "_AidInputs-fcd0a7fe.js",
      "_AidInputs-fcd0a7fe.js",
      "resources/js/Pages/Settings/CreateOrEdit.jsx",
      "resources/js/Pages/Settings/Index.jsx",
      "resources/js/Pages/Settings/OffLimits.jsx",
      "resources/js/Pages/Settings/OutOfSchedule.jsx",
      "resources/js/Pages/Terms.jsx",
      "resources/js/Pages/Users/Create.jsx",
      "resources/js/Pages/Users/Edit.jsx",
      "resources/js/Pages/Users/Index.jsx",
      "resources/js/Pages/Users/Partials/DeleteUserForm.jsx",
      "resources/js/Pages/Users/Partials/UpdatePasswordForm.jsx",
      "resources/js/Pages/Users/Partials/UpdateProfileInformationForm.jsx",
      "resources/js/Pages/Welcome.jsx"
    ],
    file: "assets/app-44aa328c.js",
    isEntry: true,
    src: "resources/js/app.jsx"
  }
};
export {
  manifest as m
};
