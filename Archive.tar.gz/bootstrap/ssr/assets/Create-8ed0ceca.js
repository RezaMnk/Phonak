import { j as jsxs, F as Fragment, a as jsx } from "../ssr.js";
import { useContext, useState, useEffect, createContext } from "react";
import { A as Authenticated } from "./AuthenticatedLayout-3e6e087e.js";
import { useForm, Head } from "@inertiajs/react";
import { T as TextInput } from "./TextInput-ca1f9780.js";
import { I as InputError } from "./InputError-0c916dba.js";
import { T as TextAreaInput } from "./TextAreaInput-7c309df0.js";
import { P as PrimaryButton } from "./PrimaryButton-6a55fe23.js";
import { S as SelectInput } from "./SelectInput-257ca42f.js";
import { R as RadioInput } from "./RadioInput-a6c65c03.js";
import { I as InputLabel } from "./InputLabel-b9d20af6.js";
import ProductsSlider from "./ProductsSlider-c4180e92.js";
import { C as CheckboxInput } from "./CheckboxInput-6397bb51.js";
import { D as DangerButton } from "./DangerButton-d6ee3472.js";
function ShippingStep() {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j;
  const { accessory, prevStep } = useContext(StepContext);
  const { data, setData, post, processing, errors } = useForm({
    type: ((_a = accessory.shipping) == null ? void 0 : _a.type) || "",
    etc_delivery: ((_b = accessory.shipping) == null ? void 0 : _b.etc_delivery) || "",
    has_health_insurance: ((_c = accessory.shipping) == null ? void 0 : _c.has_health_insurance) || false,
    phone: ((_d = accessory.shipping) == null ? void 0 : _d.phone) || "",
    audiologist_med_number: ((_e = accessory.shipping) == null ? void 0 : _e.audiologist_med_number) || "",
    otolaryngologist_med_number: ((_f = accessory.shipping) == null ? void 0 : _f.otolaryngologist_med_number) || "",
    supplementary_insurance: ((_g = accessory.shipping) == null ? void 0 : _g.supplementary_insurance) || "",
    description: ((_h = accessory.shipping) == null ? void 0 : _h.description) || "",
    mail_address: ((_i = accessory.shipping) == null ? void 0 : _i.mail_address) || ((_j = accessory.shipping) == null ? void 0 : _j.address.mail_address)
  });
  const submit = (e) => {
    e.preventDefault();
    post(route("accessories.store_shipping", accessory.id), {
      preserveScroll: true
      // onSuccess: () => {
      //     nextStep()
      // }
    });
  };
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Head, { title: "سفارش - ارسال محصول" }),
    /* @__PURE__ */ jsxs("form", { className: "w-full", onSubmit: submit, children: [
      /* @__PURE__ */ jsxs("div", { className: "mt-5 text-gray-700 dark:text-slate-200", children: [
        /* @__PURE__ */ jsx("div", { className: "flex justify-between items-end", children: /* @__PURE__ */ jsx("h5", { children: "ارسال محصول" }) }),
        /* @__PURE__ */ jsx("hr", { className: "dark:border-slate-600" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-6 mb-5", children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3 ml-5", children: [
          /* @__PURE__ */ jsxs(
            SelectInput,
            {
              id: "type",
              name: "type",
              value: data.type,
              label: "شیوه ارسال",
              onChange: (e) => setData("type", e.target.value),
              error: errors.type,
              children: [
                /* @__PURE__ */ jsx("option", { value: "", disabled: "disabled", children: "انتخاب کنید" }),
                /* @__PURE__ */ jsx("option", { value: "terminal", children: "ترمینالی" }),
                /* @__PURE__ */ jsx("option", { value: "air", children: "هوایی" }),
                /* @__PURE__ */ jsx("option", { value: "tipax", children: "تیپاکس" }),
                /* @__PURE__ */ jsx("option", { value: "post", children: "پست" }),
                /* @__PURE__ */ jsx("option", { value: "co-worker delivery", children: "تحویل به پیک همکار" }),
                /* @__PURE__ */ jsx("option", { value: "company delivery", children: "ارسال با پیک شرکت" }),
                /* @__PURE__ */ jsx("option", { value: "etc", children: "سایر" })
              ]
            }
          ),
          /* @__PURE__ */ jsx(InputError, { message: errors.type, className: "mt-2" })
        ] }),
        data.type === "etc" && /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-2/3", children: [
          /* @__PURE__ */ jsx(
            TextInput,
            {
              id: "etc_delivery",
              etc_delivery: "etc_delivery",
              value: data.etc_delivery,
              label: "شیوه ارسال محصول",
              onChange: (e) => setData("etc_delivery", e.target.value),
              error: errors.etc_delivery
            }
          ),
          /* @__PURE__ */ jsx(InputError, { message: errors.etc_delivery, className: "mt-2" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mt-8 text-gray-700 dark:text-slate-200", children: [
        /* @__PURE__ */ jsx("div", { className: "flex justify-between items-end", children: /* @__PURE__ */ jsx("h5", { children: "آدرس جهت ارسال" }) }),
        /* @__PURE__ */ jsx("hr", { className: "dark:border-slate-600" })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "flex mt-8", children: /* @__PURE__ */ jsxs("div", { className: "w-full ml-5 text-gray-700 dark:text-slate-200", children: [
        /* @__PURE__ */ jsx("p", { children: "مرسولات شما به کدام آدرس ارسال شوند؟" }),
        /* @__PURE__ */ jsx(InputError, { message: errors.mail_address, className: "mt-2" }),
        /* @__PURE__ */ jsxs("div", { className: "mb-5 mt-2", children: [
          /* @__PURE__ */ jsxs("div", { className: "mb-5", children: [
            /* @__PURE__ */ jsx(
              RadioInput,
              {
                className: "hidden peer",
                id: "mail_address_work",
                name: "mail_address",
                checked: data.mail_address === "work",
                onChange: () => setData("mail_address", "work")
              }
            ),
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                className: "block p-4 rounded-lg bg-gray-100 dark:bg-slate-700 peer-checked:bg-sky-100 peer-checked:dark:bg-sky-900 border border-gray-200 dark:border-slate-500 peer-checked:border-sky-400",
                htmlFor: "mail_address_work",
                children: /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("h6", { className: "font-semibold border-b pb-2", children: "محل کار" }),
                  /* @__PURE__ */ jsxs("p", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-5 xl:mt-2", children: [
                    /* @__PURE__ */ jsx("span", { className: "inline-block", children: accessory.shipping.address.work_address }),
                    /* @__PURE__ */ jsxs("span", { className: "inline-block xl:mr-5 xl:pr-5 xl:border-r border-gray-300 dark:border-slate-600", children: [
                      "کدپستی: ",
                      accessory.shipping.address.work_post_code
                    ] }),
                    accessory.shipping.address.work_phone && /* @__PURE__ */ jsxs(
                      "span",
                      {
                        className: "inline-block xl:mr-5 xl:pr-5 xl:border-r border-gray-300 dark:border-slate-600",
                        children: [
                          "تلفن: ",
                          accessory.shipping.address.work_phone
                        ]
                      }
                    )
                  ] })
                ] })
              }
            )
          ] }),
          accessory.shipping.address.second_work_address && /* @__PURE__ */ jsxs("div", { className: "mb-5", children: [
            /* @__PURE__ */ jsx(
              RadioInput,
              {
                className: "hidden peer",
                id: "second_mail_address_work",
                name: "mail_address",
                checked: data.mail_address === "second_work",
                onChange: () => setData("mail_address", "second_work")
              }
            ),
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                className: "block p-4 rounded-lg bg-gray-100 dark:bg-slate-700 peer-checked:bg-sky-100 peer-checked:dark:bg-sky-900 border border-gray-200 dark:border-slate-500 peer-checked:border-sky-400",
                htmlFor: "second_mail_address_work",
                children: /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("h6", { className: "font-semibold border-b pb-2", children: "محل کار دوم" }),
                  /* @__PURE__ */ jsxs("p", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-5 xl:mt-2", children: [
                    /* @__PURE__ */ jsx("span", { className: "inline-block", children: accessory.shipping.address.second_work_address }),
                    /* @__PURE__ */ jsxs("span", { className: "inline-block xl:mr-5 xl:pr-5 xl:border-r border-gray-300 dark:border-slate-600", children: [
                      "کدپستی: ",
                      accessory.shipping.address.second_work_post_code
                    ] }),
                    accessory.shipping.address.second_work_phone && /* @__PURE__ */ jsxs(
                      "span",
                      {
                        className: "inline-block xl:mr-5 xl:pr-5 xl:border-r border-gray-300 dark:border-slate-600",
                        children: [
                          "تلفن: ",
                          accessory.shipping.address.second_work_phone
                        ]
                      }
                    )
                  ] })
                ] })
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "inline-block", children: [
            /* @__PURE__ */ jsx(
              RadioInput,
              {
                className: "hidden peer",
                id: "mail_address_home",
                name: "mail_address",
                checked: data.mail_address === "home",
                onChange: () => setData("mail_address", "home")
              }
            ),
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                className: "block p-4 rounded-lg bg-gray-100 dark:bg-slate-700 peer-checked:bg-sky-100 peer-checked:dark:bg-sky-900 border border-gray-200 dark:border-slate-500 peer-checked:border-sky-400",
                htmlFor: "mail_address_home",
                children: /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("h6", { className: "font-semibold border-b pb-2", children: "محل سکونت" }),
                  /* @__PURE__ */ jsxs("p", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-5 xl:mt-2", children: [
                    /* @__PURE__ */ jsx("span", { className: "inline-block", children: accessory.shipping.address.home_address }),
                    /* @__PURE__ */ jsxs("span", { className: "inline-block xl:mr-5 xl:pr-5 xl:border-r border-gray-300 dark:border-slate-600", children: [
                      "کدپستی: ",
                      accessory.shipping.address.home_post_code
                    ] }),
                    accessory.shipping.address.home_phone && /* @__PURE__ */ jsxs(
                      "span",
                      {
                        className: "inline-block xl:mr-5 xl:pr-5 xl:border-r border-gray-300 dark:border-slate-600",
                        children: [
                          "تلفن: ",
                          accessory.shipping.address.home_phone
                        ]
                      }
                    )
                  ] })
                ] })
              }
            )
          ] })
        ] })
      ] }) }),
      /* @__PURE__ */ jsxs("div", { className: "mt-5 text-gray-700 dark:text-slate-200", children: [
        /* @__PURE__ */ jsx("h5", { children: "بیمه سلامت" }),
        /* @__PURE__ */ jsx("hr", { className: "dark:border-slate-600" })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "flex mt-5 mb-5", children: /* @__PURE__ */ jsxs("div", { className: "w-full", children: [
        /* @__PURE__ */ jsx(
          CheckboxInput,
          {
            id: "has_health_insurance",
            name: "has_health_insurance",
            checked: data.has_health_insurance,
            onChange: (e) => setData("has_health_insurance", e.target.checked)
          }
        ),
        /* @__PURE__ */ jsx(
          InputLabel,
          {
            htmlFor: "has_health_insurance",
            value: "تمایل به دریافت برگه بیمه سلامت",
            className: "mr-2"
          }
        )
      ] }) }),
      data.has_health_insurance && /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-6 mb-5", children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 ml-5", children: [
          /* @__PURE__ */ jsx(
            TextInput,
            {
              id: "phone",
              name: "phone",
              type: "number",
              value: data.phone,
              label: "تلفن همراه کاربر",
              onChange: (e) => setData("phone", e.target.value),
              error: errors.phone
            }
          ),
          /* @__PURE__ */ jsx(InputError, { message: errors.phone, className: "mt-2" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 ml-5", children: [
          /* @__PURE__ */ jsx(
            TextInput,
            {
              id: "audiologist_med_number",
              name: "audiologist_med_number",
              type: "number",
              value: data.audiologist_med_number,
              label: "شماره نظام پزشکی شنوایی شناس",
              onChange: (e) => setData("audiologist_med_number", e.target.value),
              error: errors.audiologist_med_number
            }
          ),
          /* @__PURE__ */ jsx(InputError, { message: errors.audiologist_med_number, className: "mt-2" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 ml-5", children: [
          /* @__PURE__ */ jsx(
            TextInput,
            {
              id: "otolaryngologist_med_number",
              name: "otolaryngologist_med_number",
              type: "number",
              value: data.otolaryngologist_med_number,
              label: "شماره نظام پزشکی پزشک گوش و حلق و بینی",
              onChange: (e) => setData("otolaryngologist_med_number", e.target.value),
              error: errors.otolaryngologist_med_number
            }
          ),
          /* @__PURE__ */ jsx(InputError, { message: errors.otolaryngologist_med_number, className: "mt-2" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4", children: [
          /* @__PURE__ */ jsx(
            TextInput,
            {
              id: "supplementary_insurance",
              name: "supplementary_insurance",
              value: data.supplementary_insurance,
              label: "نوع بیمه تکمیلی",
              onChange: (e) => setData("supplementary_insurance", e.target.value),
              error: errors.supplementary_insurance
            }
          ),
          /* @__PURE__ */ jsx(InputError, { message: errors.supplementary_insurance, className: "mt-2" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex mt-16", children: [
        /* @__PURE__ */ jsx(
          TextAreaInput,
          {
            id: "description",
            name: "description",
            value: data.description,
            rows: "3",
            label: "توضیحات",
            onChange: (e) => setData("description", e.target.value),
            error: errors.description
          }
        ),
        /* @__PURE__ */ jsx(InputError, { message: errors.description, className: "mt-2" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex justify-between mt-8", children: [
        /* @__PURE__ */ jsx(
          DangerButton,
          {
            className: "!px-4 !py-2",
            type: "button",
            onClick: prevStep,
            children: "مرحله قبل"
          }
        ),
        /* @__PURE__ */ jsx(
          PrimaryButton,
          {
            className: "!px-4 !py-2",
            disabled: processing,
            type: "submit",
            children: "ذخیره و بستن سفارش"
          }
        )
      ] })
    ] })
  ] });
}
const ShippingStep$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: ShippingStep
}, Symbol.toStringTag, { value: "Module" }));
function ProductStep() {
  const { accessory, nextStep } = useContext(StepContext);
  const { data, setData, post, patch, processing, errors, clearErrors, reset } = useForm({
    brand: (accessory == null ? void 0 : accessory.brand) || "",
    count: (accessory == null ? void 0 : accessory.count) || "",
    product: (accessory == null ? void 0 : accessory.product_id) || ""
  });
  const [didMount, setDidMount] = useState(false);
  const [products, setProducts] = useState({});
  const [product, setProduct] = useState((accessory == null ? void 0 : accessory.product) || {});
  useEffect(() => {
    setDidMount(true);
  }, []);
  useEffect(() => {
    setData("product", product.id);
    clearErrors("product");
  }, [product]);
  useEffect(() => {
    if (data.brand)
      get_products();
    if (didMount) {
      reset("product");
      setProduct({});
    }
  }, [data.brand]);
  const submit = (e) => {
    e.preventDefault();
    if (accessory)
      patch(route("accessories.update", accessory.id), {
        preserveScroll: true,
        onSuccess: () => {
          nextStep();
        }
      });
    else
      post(route("accessories.store"), {
        preserveScroll: true,
        onSuccess: () => {
          nextStep();
        }
      });
  };
  const get_products = async () => {
    try {
      const response = await axios.post(route("accessories.products"), { brand: data.brand });
      let new_products = response.data.products;
      if (new_products) {
        setProducts(new_products);
      } else {
        console.log("none");
      }
    } catch (error) {
      console.log("error!");
    }
  };
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Head, { title: "سفارش - محصول" }),
    /* @__PURE__ */ jsxs("form", { className: "w-full", onSubmit: submit, noValidate: true, children: [
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-3", children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-2/5 ml-5 text-gray-700 dark:text-slate-200", children: [
          /* @__PURE__ */ jsx("p", { children: "برند مورد سفارش:" }),
          /* @__PURE__ */ jsx(InputError, { message: errors.brand, className: "mt-2" }),
          /* @__PURE__ */ jsxs("div", { className: "mt-5 flex flex-wrap gap-10 justify-around xl:justify-start", children: [
            /* @__PURE__ */ jsxs("div", { className: "inline-block", children: [
              /* @__PURE__ */ jsx(
                RadioInput,
                {
                  id: "brand_phonak",
                  className: "hidden peer",
                  name: "brand",
                  checked: data.brand === "phonak",
                  onChange: () => setData("brand", "phonak")
                }
              ),
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "brand_phonak",
                  className: "bg-lime-500/30 dark:bg-lime-400/40 peer-checked:bg-lime-500/50 peer-checked:dark:bg-lime-400/50 border border-gray-200 dark:border-slate-500 rounded-lg peer-checked:border-green-400",
                  children: /* @__PURE__ */ jsxs("div", { className: "p-2", children: [
                    /* @__PURE__ */ jsx("img", { src: "/storage/brands/phonak.png", alt: "", className: "w-20 h-20 object-contain" }),
                    /* @__PURE__ */ jsx("hr", { className: "my-4 border-gray-200 dark:border-slate-500" }),
                    /* @__PURE__ */ jsx("p", { className: "text-center", children: "فوناک" })
                  ] })
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "inline-block", children: [
              /* @__PURE__ */ jsx(
                RadioInput,
                {
                  id: "brand_hansaton",
                  className: "hidden peer",
                  name: "brand",
                  checked: data.brand === "hansaton",
                  onChange: () => setData("brand", "hansaton")
                }
              ),
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "brand_hansaton",
                  className: "bg-red-500/30 dark:bg-red-400/40 peer-checked:bg-red-500/50 peer-checked:dark:bg-red-400/50 border border-gray-200 dark:border-slate-500 rounded-lg peer-checked:border-red-400",
                  children: /* @__PURE__ */ jsxs("div", { className: "p-2", children: [
                    /* @__PURE__ */ jsx("img", { src: "/storage/brands/hansaton.png", alt: "", className: "w-20 h-20 object-contain" }),
                    /* @__PURE__ */ jsx("hr", { className: "my-4 border-gray-200 dark:border-slate-500" }),
                    /* @__PURE__ */ jsx("p", { className: "text-center", children: "هنزاتون" })
                  ] })
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "inline-block", children: [
              /* @__PURE__ */ jsx(
                RadioInput,
                {
                  id: "brand_unitron",
                  className: "hidden peer",
                  name: "brand",
                  checked: data.brand === "unitron",
                  onChange: () => setData("brand", "unitron")
                }
              ),
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "brand_unitron",
                  className: "bg-sky-500/30 dark:bg-sky-400/40 peer-checked:bg-sky-500/50 peer-checked:dark:bg-sky-400/50 border border-gray-200 dark:border-slate-500 rounded-lg peer-checked:border-sky-400",
                  children: /* @__PURE__ */ jsxs("div", { className: "p-2", children: [
                    /* @__PURE__ */ jsx("img", { src: "/storage/brands/unitron.png", alt: "", className: "w-20 h-20 object-contain" }),
                    /* @__PURE__ */ jsx("hr", { className: "my-4 border-gray-200 dark:border-slate-500" }),
                    /* @__PURE__ */ jsx("p", { className: "text-center", children: "یونیترون" })
                  ] })
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "inline-block", children: [
              /* @__PURE__ */ jsx(
                RadioInput,
                {
                  id: "brand_rayovac",
                  className: "hidden peer",
                  name: "brand",
                  checked: data.brand === "rayovac",
                  onChange: () => setData("brand", "rayovac")
                }
              ),
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "brand_rayovac",
                  className: "bg-stone-500/30 dark:bg-stone-400/40 peer-checked:bg-stone-500/50 peer-checked:dark:bg-stone-400/50 border border-gray-200 dark:border-slate-500 rounded-lg peer-checked:border-stone-400",
                  children: /* @__PURE__ */ jsxs("div", { className: "p-2", children: [
                    /* @__PURE__ */ jsx("img", { src: "/storage/brands/rayovac.png", alt: "", className: "w-20 h-20 object-contain" }),
                    /* @__PURE__ */ jsx("hr", { className: "my-4 border-gray-200 dark:border-slate-500" }),
                    /* @__PURE__ */ jsx("p", { className: "text-center", children: "ریواک" })
                  ] })
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "inline-block", children: [
              /* @__PURE__ */ jsx(
                RadioInput,
                {
                  id: "brand_detax",
                  className: "hidden peer",
                  name: "brand",
                  checked: data.brand === "detax",
                  onChange: () => setData("brand", "detax")
                }
              ),
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "brand_detax",
                  className: "bg-slate-500/30 dark:bg-slate-300/40 peer-checked:bg-slate-500/50 peer-checked:dark:bg-slate-300/50 border border-gray-200 dark:border-slate-500 rounded-lg peer-checked:border-slate-400",
                  children: /* @__PURE__ */ jsxs("div", { className: "p-2", children: [
                    /* @__PURE__ */ jsx("img", { src: "/storage/brands/detax.png", alt: "", className: "w-20 h-20 object-contain" }),
                    /* @__PURE__ */ jsx("hr", { className: "my-4 border-gray-200 dark:border-slate-500" }),
                    /* @__PURE__ */ jsx("p", { className: "text-center", children: "دیتاکس" })
                  ] })
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "inline-block", children: [
              /* @__PURE__ */ jsx(
                RadioInput,
                {
                  id: "brand_etc",
                  className: "hidden peer",
                  name: "brand",
                  checked: data.brand === "etc",
                  onChange: () => setData("brand", "etc"),
                  required: true
                }
              ),
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "brand_etc",
                  className: "bg-purple-500/30 dark:bg-purple-400/40 peer-checked:bg-purple-500/50 peer-checked:dark:bg-purple-400/50 border border-gray-200 dark:border-slate-500 rounded-lg peer-checked:border-purple-400",
                  children: /* @__PURE__ */ jsxs("div", { className: "p-2", children: [
                    /* @__PURE__ */ jsx("img", { src: "/storage/brands/etc.png", alt: "", className: "w-20 h-20 object-contain" }),
                    /* @__PURE__ */ jsx("hr", { className: "my-4 border-gray-200 dark:border-slate-500" }),
                    /* @__PURE__ */ jsx("p", { className: "text-center", children: "سایر" })
                  ] })
                }
              )
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-3/5 flex flex-col space-y-5 xl:space-y-0", children: [
          /* @__PURE__ */ jsx("p", { className: "mb-5 text-gray-700 dark:text-slate-200", children: "محصولات:" }),
          Object.keys(products).length === 0 && /* @__PURE__ */ jsx("p", { className: "text-lg text-gray-700 dark:text-slate-300", children: "با اطلاعات وارد شده، محصول قابل سفارشی برای گروه شما وجود ندارد!" }),
          /* @__PURE__ */ jsxs("div", { className: `transition-all ${!(accessory == null ? void 0 : accessory.product_id) && "ease-in-out duration-500"} ${Object.keys(products).length ? "max-h-full" : "max-h-0"} overflow-hidden`, children: [
            /* @__PURE__ */ jsx(ProductsSlider, { products, setProduct, product: product.id, error: errors.product }),
            /* @__PURE__ */ jsx(InputError, { message: errors.product, className: "mt-2" })
          ] })
        ] })
      ] }),
      product.has_count === 1 && /* @__PURE__ */ jsx("div", { className: "flex mt-5", children: /* @__PURE__ */ jsx("div", { className: "w-full flex", children: /* @__PURE__ */ jsxs("div", { className: "w-1/3 ml-5", children: [
        /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "count",
            type: "number",
            name: "count",
            value: data.count,
            label: "تعداد مورد سفارش",
            onChange: (e) => setData("count", e.target.value),
            error: errors.count,
            required: true
          }
        ),
        /* @__PURE__ */ jsx(InputError, { message: errors.count, className: "mt-2" })
      ] }) }) }),
      /* @__PURE__ */ jsx("div", { className: "flex justify-end mt-8", children: /* @__PURE__ */ jsx(
        PrimaryButton,
        {
          className: "!px-4 !py-2",
          disabled: processing,
          type: "submit",
          children: "مرحله بعد"
        }
      ) })
    ] })
  ] });
}
const ProductStep$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: ProductStep
}, Symbol.toStringTag, { value: "Module" }));
const StepContext = createContext();
function Create({ accessory }) {
  const [step, setStep] = useState(parseInt(new URLSearchParams(window.location.search).get("step")) || 1);
  const prevStep = () => {
    setStep((prev) => prev - 1);
  };
  useEffect(() => {
    const searchParams = new URLSearchParams(window.location.search);
    searchParams.set("step", step);
    const newUrl = `${window.location.pathname}?${searchParams.toString()}`;
    window.history.replaceState(null, "", newUrl);
  }, [step]);
  const nextStep = () => {
    setStep((prev) => prev + 1);
  };
  const showStep = () => {
    switch (step) {
      case 1:
        return /* @__PURE__ */ jsx(ProductStep, {});
      case 2:
        return /* @__PURE__ */ jsx(ShippingStep, {});
    }
  };
  return /* @__PURE__ */ jsx(
    Authenticated,
    {
      header: /* @__PURE__ */ jsx(Fragment, { children: "ایجاد کاربر" }),
      breadcrumbs: {
        "سفارشات لوازم جانبی": route("accessories.index"),
        [accessory ? "ویرایش سفارش" : "ایجاد سفارش"]: "#"
      },
      children: /* @__PURE__ */ jsx("div", { className: "flex flex-col sm:justify-center items-center", children: /* @__PURE__ */ jsx("div", { className: "w-full px-6 py-4 bg-white dark:bg-slate-800 border border-white dark:border-slate-600 sm:rounded-lg", children: /* @__PURE__ */ jsx(StepContext.Provider, { value: { accessory, prevStep, nextStep }, children: showStep() }) }) })
    }
  );
}
const Create$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  StepContext,
  default: Create
}, Symbol.toStringTag, { value: "Module" }));
export {
  Create$1 as C,
  ProductStep$1 as P,
  ShippingStep$1 as S
};
