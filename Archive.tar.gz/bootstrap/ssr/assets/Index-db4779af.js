import { j as jsxs, a as jsx } from "../ssr.js";
import { A as Authenticated } from "./AuthenticatedLayout-5fd2cf47.js";
import { router, Head, Link } from "@inertiajs/react";
import { P as Pagination } from "./Pagination-7f5980b7.js";
import { useState, useEffect } from "react";
import { T as TextInput } from "./TextInput-ca1f9780.js";
import { u as useFirstRender } from "./useFirstRender-5b0e5bdf.js";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "react-toastify";
import "./useMemorable-ea291d99.js";
import "./ApplicationLogo-40648ed6.js";
import "./Icon-2f3a2698.js";
function Index({ users }) {
  const [search, setSearch] = useState(new URLSearchParams(window.location.search).get("search") || "");
  const firstRender = useFirstRender();
  useEffect(() => {
    if (!firstRender) {
      const delayDebounceFn = setTimeout(() => {
        router.get(route(users.status === "unapproved" ? "users.not_verified" : "users.index"), {
          search
        });
      }, 1500);
      return () => clearTimeout(delayDebounceFn);
    }
  }, [search]);
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      header: "همکاران",
      breadcrumbs: {
        "همکاران": route("users.index")
      },
      headerExtra: /* @__PURE__ */ jsx("form", { id: "search", children: /* @__PURE__ */ jsx(
        TextInput,
        {
          id: "search-input",
          name: "search",
          value: search,
          label: "جستوجو...",
          className: "!py-2 !px-4",
          autoComplete: "name",
          onChange: (e) => setSearch(e.target.value),
          isFocused: !!search
        }
      ) }),
      children: [
        /* @__PURE__ */ jsx(Head, { title: "همکاران" }),
        /* @__PURE__ */ jsx("div", { className: "relative overflow-x-auto rounded-lg", children: /* @__PURE__ */ jsxs("table", { className: "w-full text-right text-gray-500 dark:text-slate-400", children: [
          /* @__PURE__ */ jsx("thead", { className: "text-xs text-gray-700 dark:text-gray-300 bg-gray-50 dark:bg-slate-700", children: /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx("th", { scope: "col", className: "px-6 py-3", children: "نام و نام خانوادگی" }),
            /* @__PURE__ */ jsx("th", { scope: "col", className: "px-6 py-3 hidden xl:table-cell", children: "شماره نظام پزشکی" }),
            /* @__PURE__ */ jsx("th", { scope: "col", className: "px-6 py-3 hidden xl:table-cell", children: "موقعیت" }),
            /* @__PURE__ */ jsx("th", { scope: "col", className: "px-6 py-3 hidden xl:table-cell", children: "شماره گروه" }),
            /* @__PURE__ */ jsx("th", { scope: "col", className: "px-6 py-3", children: "وضعیت" }),
            /* @__PURE__ */ jsx("th", { scope: "col", className: "px-6 py-3", children: "عملیات" })
          ] }) }),
          /* @__PURE__ */ jsx("tbody", { children: Object.keys(users.data).length ? Object.values(users.data).map((user) => {
            const is_last = users.data[Object.keys(users.data).length - 1] === user;
            return /* @__PURE__ */ jsxs("tr", { className: `bg-white dark:bg-slate-900 ${!is_last ? "border-b" : ""} border-gray-200 dark:border-slate-600`, children: [
              /* @__PURE__ */ jsx(
                "th",
                {
                  scope: "row",
                  className: "px-6 py-4 text-sm font-medium text-gray-700 dark:text-slate-300 whitespace-nowrap",
                  children: user.name
                }
              ),
              /* @__PURE__ */ jsx("td", { className: "px-6 py-4 hidden xl:table-cell", children: user.med_number }),
              /* @__PURE__ */ jsxs("td", { className: "px-6 py-4 hidden xl:table-cell", children: [
                user.state,
                " - ",
                user.city
              ] }),
              /* @__PURE__ */ jsx("td", { className: "px-6 py-4 hidden xl:table-cell", children: user.group === 0 ? "گروه بندی نشده" : user.group }),
              /* @__PURE__ */ jsxs("td", { className: "px-6 py-4", children: [
                user.status === "approved" && /* @__PURE__ */ jsx("span", { className: "inline-flex whitespace-nowrap items-center rounded-md bg-sky-50 dark:bg-sky-500/30 px-2 py-1 text-sm font-medium text-sky-800 dark:text-sky-300/70 ring-1 ring-inset ring-sky-600/20", children: "تایید شده" }),
                user.status === "waiting" && /* @__PURE__ */ jsx("span", { className: "inline-flex items-center rounded-md bg-yellow-50 dark:bg-yellow-500/30 px-2 py-1 text-sm font-medium text-yellow-800 dark:text-yellow-300/70 ring-1 ring-inset ring-yellow-600/20", children: "در انتظار تایید" }),
                user.status === "unapproved" && /* @__PURE__ */ jsx("span", { className: "inline-flex items-center rounded-md bg-red-50 dark:bg-red-500/30 px-2 py-1 text-sm font-medium text-red-800 dark:text-red-300/70 ring-1 ring-inset ring-red-600/20", children: "رد شده" })
              ] }),
              /* @__PURE__ */ jsx("td", { className: "px-6 py-4", children: /* @__PURE__ */ jsx(
                Link,
                {
                  href: route("users.edit", [user.id]),
                  className: "inline-flex px-2 py-1 text-xs text-center text-yellow-900 dark:text-yellow-200 transition-colors duration-300 bg-yellow-100 dark:bg-yellow-600/50 border border-yellow-200 dark:border-yellow-800 rounded-lg hover:bg-yellow-200 dark:hover:bg-yellow-600 focus:outline-none focus:ring-0 focus:border-yellow-500",
                  children: "ویرایش"
                }
              ) })
            ] }, user.id);
          }) : /* @__PURE__ */ jsx("tr", { className: "bg-white text-gray-700 dark:text-slate-300 dark:bg-slate-900", children: /* @__PURE__ */ jsx(
            "th",
            {
              scope: "row",
              colSpan: "6",
              className: "text-lg px-6 py-6",
              children: "هیچ همکاری یافت نشد!"
            }
          ) }) })
        ] }) }),
        /* @__PURE__ */ jsx(Pagination, { data: users, search })
      ]
    }
  );
}
export {
  Index as default
};
