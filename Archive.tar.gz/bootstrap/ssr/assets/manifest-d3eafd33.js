const manifest = {
  "AuthenticatedLayout.css": {
    file: "assets/AuthenticatedLayout-b7bb1ac5.css",
    src: "AuthenticatedLayout.css"
  },
  "_AidInputs-d19dafa9.js": {
    file: "assets/AidInputs-d19dafa9.js",
    imports: [
      "resources/js/app.jsx",
      "_SelectInput-00333a1a.js",
      "_InputError-bc123ba3.js",
      "_PrimaryButton-7b40fb7a.js",
      "_DangerButton-69546d75.js",
      "_AuthenticatedLayout-54357aa5.js",
      "resources/js/Pages/Records/Components/Steps.jsx",
      "_TextInput-069b546e.js",
      "_TextAreaInput-b95bcdb8.js",
      "_IranStatesOptions-6648d2c8.js",
      "_FileInput-27c75919.js",
      "_RadioInput-324de5cf.js",
      "_InputLabel-6173deae.js",
      "resources/js/Pages/Records/Components/ProductsSlider.jsx",
      "_useFirstRender-5387e4d4.js",
      "_CheckboxInput-9ea0b622.js",
      "_Icon-50c11904.js"
    ],
    isDynamicEntry: true
  },
  "_ApplicationLogo-e6cf41e6.js": {
    file: "assets/ApplicationLogo-e6cf41e6.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_ArrowLink-1492ae61.js": {
    file: "assets/ArrowLink-1492ae61.js",
    imports: [
      "resources/js/app.jsx",
      "__commonjs-dynamic-modules-302442b1.js"
    ]
  },
  "_AuthenticatedLayout-54357aa5.js": {
    css: [
      "assets/AuthenticatedLayout-b7bb1ac5.css"
    ],
    file: "assets/AuthenticatedLayout-54357aa5.js",
    imports: [
      "resources/js/app.jsx",
      "_useMemorable-e267c6b8.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_Icon-50c11904.js"
    ]
  },
  "_CheckboxInput-9ea0b622.js": {
    file: "assets/CheckboxInput-9ea0b622.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_Create-c46f57df.js": {
    file: "assets/Create-c46f57df.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-54357aa5.js",
      "_TextInput-069b546e.js",
      "_InputError-bc123ba3.js",
      "_TextAreaInput-b95bcdb8.js",
      "_PrimaryButton-7b40fb7a.js",
      "_SelectInput-00333a1a.js",
      "_RadioInput-324de5cf.js",
      "_InputLabel-6173deae.js",
      "resources/js/Pages/Accessories/Components/ProductsSlider.jsx",
      "_DangerButton-69546d75.js",
      "_Icon-50c11904.js"
    ],
    isDynamicEntry: true
  },
  "_DangerButton-69546d75.js": {
    file: "assets/DangerButton-69546d75.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_FileInput-27c75919.js": {
    file: "assets/FileInput-27c75919.js",
    imports: [
      "resources/js/app.jsx",
      "_Icon-50c11904.js",
      "_PrimaryButton-7b40fb7a.js"
    ]
  },
  "_GuestLayout-01ca834a.js": {
    file: "assets/GuestLayout-01ca834a.js",
    imports: [
      "resources/js/app.jsx",
      "_ApplicationLogo-e6cf41e6.js",
      "_useMemorable-e267c6b8.js"
    ]
  },
  "_Icon-50c11904.js": {
    file: "assets/Icon-50c11904.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_InputError-bc123ba3.js": {
    file: "assets/InputError-bc123ba3.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_InputLabel-6173deae.js": {
    file: "assets/InputLabel-6173deae.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_IranStatesOptions-6648d2c8.js": {
    file: "assets/IranStatesOptions-6648d2c8.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_Modal-fd1dd9ca.js": {
    file: "assets/Modal-fd1dd9ca.js",
    imports: [
      "resources/js/app.jsx",
      "_transition-f83752d2.js"
    ]
  },
  "_Pagination-29c0a636.js": {
    file: "assets/Pagination-29c0a636.js",
    imports: [
      "resources/js/app.jsx",
      "_useFirstRender-5387e4d4.js"
    ]
  },
  "_PrimaryButton-7b40fb7a.js": {
    file: "assets/PrimaryButton-7b40fb7a.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_RadioInput-324de5cf.js": {
    file: "assets/RadioInput-324de5cf.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_SecondaryButton-e8b2c1e2.js": {
    file: "assets/SecondaryButton-e8b2c1e2.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_SelectInput-00333a1a.js": {
    file: "assets/SelectInput-00333a1a.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_TextAreaInput-b95bcdb8.js": {
    file: "assets/TextAreaInput-b95bcdb8.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_TextInput-069b546e.js": {
    file: "assets/TextInput-069b546e.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_WarningButton-9de61c11.js": {
    file: "assets/WarningButton-9de61c11.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "__commonjs-dynamic-modules-302442b1.js": {
    file: "assets/_commonjs-dynamic-modules-302442b1.js"
  },
  "_index-9c160340.js": {
    file: "assets/index-9c160340.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_lottie-react.esm-e5548dc0.js": {
    file: "assets/lottie-react.esm-e5548dc0.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_manifest-67e97e9b.js": {
    file: "assets/manifest-67e97e9b.js"
  },
  "_pagination-de84887e.js": {
    css: [
      "assets/pagination-211b41b8.css"
    ],
    file: "assets/pagination-de84887e.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_transition-f83752d2.js": {
    file: "assets/transition-f83752d2.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_useFirstRender-5387e4d4.js": {
    file: "assets/useFirstRender-5387e4d4.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_useMemorable-e267c6b8.js": {
    file: "assets/useMemorable-e267c6b8.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "pagination.css": {
    file: "assets/pagination-211b41b8.css",
    src: "pagination.css"
  },
  "resources/fonts/woff/Dana-Black.woff": {
    file: "assets/Dana-Black-575de1e5.woff",
    src: "resources/fonts/woff/Dana-Black.woff"
  },
  "resources/fonts/woff/Dana-DemiBold.woff": {
    file: "assets/Dana-DemiBold-fa427dcf.woff",
    src: "resources/fonts/woff/Dana-DemiBold.woff"
  },
  "resources/fonts/woff/Dana-ExtraBlack.woff": {
    file: "assets/Dana-ExtraBlack-6c729c23.woff",
    src: "resources/fonts/woff/Dana-ExtraBlack.woff"
  },
  "resources/fonts/woff/Dana-ExtraBold.woff": {
    file: "assets/Dana-ExtraBold-0d7888d7.woff",
    src: "resources/fonts/woff/Dana-ExtraBold.woff"
  },
  "resources/fonts/woff/Dana-Fat.woff": {
    file: "assets/Dana-Fat-8831a7f0.woff",
    src: "resources/fonts/woff/Dana-Fat.woff"
  },
  "resources/fonts/woff/Dana-Hairline.woff": {
    file: "assets/Dana-Hairline-6d7bb084.woff",
    src: "resources/fonts/woff/Dana-Hairline.woff"
  },
  "resources/fonts/woff/Dana-Heavy.woff": {
    file: "assets/Dana-Heavy-e159608a.woff",
    src: "resources/fonts/woff/Dana-Heavy.woff"
  },
  "resources/fonts/woff/Dana-Light.woff": {
    file: "assets/Dana-Light-eeed4155.woff",
    src: "resources/fonts/woff/Dana-Light.woff"
  },
  "resources/fonts/woff/Dana-Medium.woff": {
    file: "assets/Dana-Medium-d0241b30.woff",
    src: "resources/fonts/woff/Dana-Medium.woff"
  },
  "resources/fonts/woff/Dana-Regular.woff": {
    file: "assets/Dana-Regular-eee25c04.woff",
    src: "resources/fonts/woff/Dana-Regular.woff"
  },
  "resources/fonts/woff/Dana-Thin.woff": {
    file: "assets/Dana-Thin-56dc1e1f.woff",
    src: "resources/fonts/woff/Dana-Thin.woff"
  },
  "resources/fonts/woff/Dana-UltraLight.woff": {
    file: "assets/Dana-UltraLight-a025f30e.woff",
    src: "resources/fonts/woff/Dana-UltraLight.woff"
  },
  "resources/fonts/woff2/Dana-Black.woff2": {
    file: "assets/Dana-Black-cdfe2203.woff2",
    src: "resources/fonts/woff2/Dana-Black.woff2"
  },
  "resources/fonts/woff2/Dana-DemiBold.woff2": {
    file: "assets/Dana-DemiBold-34870445.woff2",
    src: "resources/fonts/woff2/Dana-DemiBold.woff2"
  },
  "resources/fonts/woff2/Dana-ExtraBlack.woff2": {
    file: "assets/Dana-ExtraBlack-3208afe0.woff2",
    src: "resources/fonts/woff2/Dana-ExtraBlack.woff2"
  },
  "resources/fonts/woff2/Dana-ExtraBold.woff2": {
    file: "assets/Dana-ExtraBold-08dea612.woff2",
    src: "resources/fonts/woff2/Dana-ExtraBold.woff2"
  },
  "resources/fonts/woff2/Dana-Fat.woff2": {
    file: "assets/Dana-Fat-1f7b7061.woff2",
    src: "resources/fonts/woff2/Dana-Fat.woff2"
  },
  "resources/fonts/woff2/Dana-Hairline.woff2": {
    file: "assets/Dana-Hairline-7712cf11.woff2",
    src: "resources/fonts/woff2/Dana-Hairline.woff2"
  },
  "resources/fonts/woff2/Dana-Heavy.woff2": {
    file: "assets/Dana-Heavy-091eb261.woff2",
    src: "resources/fonts/woff2/Dana-Heavy.woff2"
  },
  "resources/fonts/woff2/Dana-Light.woff2": {
    file: "assets/Dana-Light-e07a4868.woff2",
    src: "resources/fonts/woff2/Dana-Light.woff2"
  },
  "resources/fonts/woff2/Dana-Medium.woff2": {
    file: "assets/Dana-Medium-d623f857.woff2",
    src: "resources/fonts/woff2/Dana-Medium.woff2"
  },
  "resources/fonts/woff2/Dana-Regular.woff2": {
    file: "assets/Dana-Regular-43506011.woff2",
    src: "resources/fonts/woff2/Dana-Regular.woff2"
  },
  "resources/fonts/woff2/Dana-Thin.woff2": {
    file: "assets/Dana-Thin-bec2bd8a.woff2",
    src: "resources/fonts/woff2/Dana-Thin.woff2"
  },
  "resources/fonts/woff2/Dana-UltraLight.woff2": {
    file: "assets/Dana-UltraLight-24615a03.woff2",
    src: "resources/fonts/woff2/Dana-UltraLight.woff2"
  },
  "resources/js/Pages/Accessories/Components/ProductsSlider.jsx": {
    file: "assets/ProductsSlider-4148f87d.js",
    imports: [
      "resources/js/app.jsx",
      "_pagination-de84887e.js",
      "_RadioInput-324de5cf.js",
      "_InputLabel-6173deae.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Accessories/Components/ProductsSlider.jsx"
  },
  "resources/js/Pages/Accessories/Index.jsx": {
    file: "assets/Index-1c2540c0.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-54357aa5.js",
      "_SecondaryButton-e8b2c1e2.js",
      "_DangerButton-69546d75.js",
      "_Modal-fd1dd9ca.js",
      "_PrimaryButton-7b40fb7a.js",
      "_Pagination-29c0a636.js",
      "_useMemorable-e267c6b8.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_Icon-50c11904.js",
      "_transition-f83752d2.js",
      "_useFirstRender-5387e4d4.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Accessories/Index.jsx"
  },
  "resources/js/Pages/Accessories/Show.jsx": {
    file: "assets/Show-1ffd9b35.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-54357aa5.js",
      "_WarningButton-9de61c11.js",
      "_PrimaryButton-7b40fb7a.js",
      "_SecondaryButton-e8b2c1e2.js",
      "_useMemorable-e267c6b8.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_Icon-50c11904.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Accessories/Show.jsx"
  },
  "resources/js/Pages/Admin/Accessories.jsx": {
    file: "assets/Accessories-476a914f.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-54357aa5.js",
      "_Pagination-29c0a636.js",
      "_useFirstRender-5387e4d4.js",
      "_TextInput-069b546e.js",
      "_useMemorable-e267c6b8.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_Icon-50c11904.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Admin/Accessories.jsx"
  },
  "resources/js/Pages/Admin/Records.jsx": {
    file: "assets/Records-de817575.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-54357aa5.js",
      "_Pagination-29c0a636.js",
      "_TextInput-069b546e.js",
      "_useFirstRender-5387e4d4.js",
      "_useMemorable-e267c6b8.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_Icon-50c11904.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Admin/Records.jsx"
  },
  "resources/js/Pages/Auth/Address.jsx": {
    file: "assets/Address-c6dd616b.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-01ca834a.js",
      "_InputError-bc123ba3.js",
      "_PrimaryButton-7b40fb7a.js",
      "_TextInput-069b546e.js",
      "_TextAreaInput-b95bcdb8.js",
      "_RadioInput-324de5cf.js",
      "_InputLabel-6173deae.js",
      "_Icon-50c11904.js",
      "_DangerButton-69546d75.js",
      "_SelectInput-00333a1a.js",
      "_IranStatesOptions-6648d2c8.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_useMemorable-e267c6b8.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Address.jsx"
  },
  "resources/js/Pages/Auth/ConfirmPassword.jsx": {
    file: "assets/ConfirmPassword-69bbe6c8.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-01ca834a.js",
      "_InputError-bc123ba3.js",
      "_InputLabel-6173deae.js",
      "_PrimaryButton-7b40fb7a.js",
      "_TextInput-069b546e.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_useMemorable-e267c6b8.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/ConfirmPassword.jsx"
  },
  "resources/js/Pages/Auth/ForgotPassword.jsx": {
    file: "assets/ForgotPassword-e4c0dfa9.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-01ca834a.js",
      "_InputError-bc123ba3.js",
      "_PrimaryButton-7b40fb7a.js",
      "_TextInput-069b546e.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_useMemorable-e267c6b8.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/ForgotPassword.jsx"
  },
  "resources/js/Pages/Auth/Info.jsx": {
    file: "assets/Info-62c470da.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-01ca834a.js",
      "_InputError-bc123ba3.js",
      "_PrimaryButton-7b40fb7a.js",
      "_TextInput-069b546e.js",
      "_TextAreaInput-b95bcdb8.js",
      "_FileInput-27c75919.js",
      "_InputLabel-6173deae.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_useMemorable-e267c6b8.js",
      "_Icon-50c11904.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Info.jsx"
  },
  "resources/js/Pages/Auth/Login.jsx": {
    file: "assets/Login-abedb13e.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-01ca834a.js",
      "_InputError-bc123ba3.js",
      "_InputLabel-6173deae.js",
      "_PrimaryButton-7b40fb7a.js",
      "_TextInput-069b546e.js",
      "_CheckboxInput-9ea0b622.js",
      "_WarningButton-9de61c11.js",
      "_Icon-50c11904.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_useMemorable-e267c6b8.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Login.jsx"
  },
  "resources/js/Pages/Auth/Register.jsx": {
    file: "assets/Register-11050766.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-01ca834a.js",
      "_InputError-bc123ba3.js",
      "_PrimaryButton-7b40fb7a.js",
      "_TextInput-069b546e.js",
      "_SelectInput-00333a1a.js",
      "_IranStatesOptions-6648d2c8.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_useMemorable-e267c6b8.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Register.jsx"
  },
  "resources/js/Pages/Auth/ResetPassword.jsx": {
    file: "assets/ResetPassword-ffe4e404.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-01ca834a.js",
      "_InputError-bc123ba3.js",
      "_PrimaryButton-7b40fb7a.js",
      "_TextInput-069b546e.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_useMemorable-e267c6b8.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/ResetPassword.jsx"
  },
  "resources/js/Pages/Auth/VerifyEmail.jsx": {
    file: "assets/VerifyEmail-7d2b819d.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-01ca834a.js",
      "_PrimaryButton-7b40fb7a.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_useMemorable-e267c6b8.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/VerifyEmail.jsx"
  },
  "resources/js/Pages/Auth/WaitForVerify.jsx": {
    file: "assets/WaitForVerify-701a9ad9.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-01ca834a.js",
      "_lottie-react.esm-e5548dc0.js",
      "_PrimaryButton-7b40fb7a.js",
      "_DangerButton-69546d75.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_useMemorable-e267c6b8.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/WaitForVerify.jsx"
  },
  "resources/js/Pages/Dashboards/Admin.jsx": {
    file: "assets/Admin-42e5fac9.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-54357aa5.js",
      "_ArrowLink-1492ae61.js",
      "_useMemorable-e267c6b8.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_Icon-50c11904.js",
      "__commonjs-dynamic-modules-302442b1.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Dashboards/Admin.jsx"
  },
  "resources/js/Pages/Dashboards/User.jsx": {
    file: "assets/User-74ba3e55.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-54357aa5.js",
      "_ArrowLink-1492ae61.js",
      "_useMemorable-e267c6b8.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_Icon-50c11904.js",
      "__commonjs-dynamic-modules-302442b1.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Dashboards/User.jsx"
  },
  "resources/js/Pages/Download/Accessory.jsx": {
    file: "assets/Accessory-141840d8.js",
    imports: [
      "resources/js/app.jsx",
      "_manifest-67e97e9b.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Download/Accessory.jsx"
  },
  "resources/js/Pages/Download/Record.jsx": {
    file: "assets/Record-2ce008e5.js",
    imports: [
      "resources/js/app.jsx",
      "_manifest-67e97e9b.js",
      "__commonjs-dynamic-modules-302442b1.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Download/Record.jsx"
  },
  "resources/js/Pages/Patients/Create.jsx": {
    file: "assets/Create-7f1e6d11.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-54357aa5.js",
      "_TextInput-069b546e.js",
      "_InputError-bc123ba3.js",
      "_TextAreaInput-b95bcdb8.js",
      "_PrimaryButton-7b40fb7a.js",
      "_SelectInput-00333a1a.js",
      "_IranStatesOptions-6648d2c8.js",
      "_DangerButton-69546d75.js",
      "_useMemorable-e267c6b8.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_Icon-50c11904.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Create.jsx"
  },
  "resources/js/Pages/Patients/Edit.jsx": {
    file: "assets/Edit-98ba182e.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-54357aa5.js",
      "_TextInput-069b546e.js",
      "_InputError-bc123ba3.js",
      "_TextAreaInput-b95bcdb8.js",
      "_PrimaryButton-7b40fb7a.js",
      "_SelectInput-00333a1a.js",
      "_IranStatesOptions-6648d2c8.js",
      "_DangerButton-69546d75.js",
      "_useMemorable-e267c6b8.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_Icon-50c11904.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Edit.jsx"
  },
  "resources/js/Pages/Patients/Index.jsx": {
    file: "assets/Index-e5d8e028.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-54357aa5.js",
      "_SecondaryButton-e8b2c1e2.js",
      "_DangerButton-69546d75.js",
      "_Modal-fd1dd9ca.js",
      "_Pagination-29c0a636.js",
      "_useMemorable-e267c6b8.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_Icon-50c11904.js",
      "_transition-f83752d2.js",
      "_useFirstRender-5387e4d4.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Index.jsx"
  },
  "resources/js/Pages/Patients/Partials/DeleteUserForm.jsx": {
    file: "assets/DeleteUserForm-19541000.js",
    imports: [
      "resources/js/app.jsx",
      "_DangerButton-69546d75.js",
      "_InputError-bc123ba3.js",
      "_InputLabel-6173deae.js",
      "_Modal-fd1dd9ca.js",
      "_SecondaryButton-e8b2c1e2.js",
      "_TextInput-069b546e.js",
      "_transition-f83752d2.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Partials/DeleteUserForm.jsx"
  },
  "resources/js/Pages/Patients/Partials/UpdatePasswordForm.jsx": {
    file: "assets/UpdatePasswordForm-8ee135f0.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-bc123ba3.js",
      "_InputLabel-6173deae.js",
      "_PrimaryButton-7b40fb7a.js",
      "_TextInput-069b546e.js",
      "_transition-f83752d2.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Partials/UpdatePasswordForm.jsx"
  },
  "resources/js/Pages/Patients/Partials/UpdateProfileInformationForm.jsx": {
    file: "assets/UpdateProfileInformationForm-64140435.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-bc123ba3.js",
      "_InputLabel-6173deae.js",
      "_PrimaryButton-7b40fb7a.js",
      "_TextInput-069b546e.js",
      "_transition-f83752d2.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Partials/UpdateProfileInformationForm.jsx"
  },
  "resources/js/Pages/Products/CreateOrEdit.jsx": {
    file: "assets/CreateOrEdit-c15b0937.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-54357aa5.js",
      "_TextInput-069b546e.js",
      "_InputError-bc123ba3.js",
      "_PrimaryButton-7b40fb7a.js",
      "_SelectInput-00333a1a.js",
      "_DangerButton-69546d75.js",
      "_Icon-50c11904.js",
      "_CheckboxInput-9ea0b622.js",
      "_InputLabel-6173deae.js",
      "_useMemorable-e267c6b8.js",
      "_ApplicationLogo-e6cf41e6.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Products/CreateOrEdit.jsx"
  },
  "resources/js/Pages/Products/Index.jsx": {
    file: "assets/Index-a86b5bfe.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-54357aa5.js",
      "_SecondaryButton-e8b2c1e2.js",
      "_DangerButton-69546d75.js",
      "_Modal-fd1dd9ca.js",
      "_PrimaryButton-7b40fb7a.js",
      "_Pagination-29c0a636.js",
      "_TextInput-069b546e.js",
      "_useFirstRender-5387e4d4.js",
      "_useMemorable-e267c6b8.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_Icon-50c11904.js",
      "_transition-f83752d2.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Products/Index.jsx"
  },
  "resources/js/Pages/Profile/Edit.jsx": {
    file: "assets/Edit-2581bcd1.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-54357aa5.js",
      "_GuestLayout-01ca834a.js",
      "_TextInput-069b546e.js",
      "_InputError-bc123ba3.js",
      "_TextAreaInput-b95bcdb8.js",
      "_PrimaryButton-7b40fb7a.js",
      "_DangerButton-69546d75.js",
      "_SelectInput-00333a1a.js",
      "_IranStatesOptions-6648d2c8.js",
      "_FileInput-27c75919.js",
      "_RadioInput-324de5cf.js",
      "_InputLabel-6173deae.js",
      "_Icon-50c11904.js",
      "_useMemorable-e267c6b8.js",
      "_ApplicationLogo-e6cf41e6.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Profile/Edit.jsx"
  },
  "resources/js/Pages/Profile/Index.jsx": {
    file: "assets/Index-63ae2d9e.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-54357aa5.js",
      "_WarningButton-9de61c11.js",
      "_useMemorable-e267c6b8.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_Icon-50c11904.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Profile/Index.jsx"
  },
  "resources/js/Pages/Records/Components/ProductsSlider.jsx": {
    file: "assets/ProductsSlider-6fd5670c.js",
    imports: [
      "resources/js/app.jsx",
      "_pagination-de84887e.js",
      "_RadioInput-324de5cf.js",
      "_InputLabel-6173deae.js",
      "_CheckboxInput-9ea0b622.js",
      "_Icon-50c11904.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Components/ProductsSlider.jsx"
  },
  "resources/js/Pages/Records/Components/Steps.jsx": {
    file: "assets/Steps-e0e9c09d.js",
    imports: [
      "resources/js/app.jsx",
      "resources/js/Pages/Records/Partials/Step.jsx",
      "_Icon-50c11904.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Components/Steps.jsx"
  },
  "resources/js/Pages/Records/Index.jsx": {
    file: "assets/Index-35a16052.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-54357aa5.js",
      "_SecondaryButton-e8b2c1e2.js",
      "_DangerButton-69546d75.js",
      "_Modal-fd1dd9ca.js",
      "_PrimaryButton-7b40fb7a.js",
      "_Pagination-29c0a636.js",
      "_useMemorable-e267c6b8.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_Icon-50c11904.js",
      "_transition-f83752d2.js",
      "_useFirstRender-5387e4d4.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Index.jsx"
  },
  "resources/js/Pages/Records/Partials/Step.jsx": {
    file: "assets/Step-3ac81625.js",
    imports: [
      "resources/js/app.jsx"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Partials/Step.jsx"
  },
  "resources/js/Pages/Records/Show.jsx": {
    file: "assets/Show-9d490cc3.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-54357aa5.js",
      "_WarningButton-9de61c11.js",
      "_PrimaryButton-7b40fb7a.js",
      "_SecondaryButton-e8b2c1e2.js",
      "_useMemorable-e267c6b8.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_Icon-50c11904.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Show.jsx"
  },
  "resources/js/Pages/Settings/CreateOrEdit.jsx": {
    file: "assets/CreateOrEdit-08805ab3.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-54357aa5.js",
      "_TextInput-069b546e.js",
      "_InputError-bc123ba3.js",
      "_PrimaryButton-7b40fb7a.js",
      "_DangerButton-69546d75.js",
      "_useMemorable-e267c6b8.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_Icon-50c11904.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/CreateOrEdit.jsx"
  },
  "resources/js/Pages/Settings/Index.jsx": {
    file: "assets/Index-5b7e7330.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-54357aa5.js",
      "_SecondaryButton-e8b2c1e2.js",
      "_DangerButton-69546d75.js",
      "_Modal-fd1dd9ca.js",
      "_PrimaryButton-7b40fb7a.js",
      "_Pagination-29c0a636.js",
      "_TextInput-069b546e.js",
      "_useFirstRender-5387e4d4.js",
      "_useMemorable-e267c6b8.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_Icon-50c11904.js",
      "_transition-f83752d2.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/Index.jsx"
  },
  "resources/js/Pages/Settings/OffLimits.jsx": {
    file: "assets/OffLimits-57aefc39.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-54357aa5.js",
      "_PrimaryButton-7b40fb7a.js",
      "_lottie-react.esm-e5548dc0.js",
      "_useMemorable-e267c6b8.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_Icon-50c11904.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/OffLimits.jsx"
  },
  "resources/js/Pages/Settings/OutOfSchedule.jsx": {
    file: "assets/OutOfSchedule-84a82986.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-54357aa5.js",
      "_PrimaryButton-7b40fb7a.js",
      "_lottie-react.esm-e5548dc0.js",
      "_useMemorable-e267c6b8.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_Icon-50c11904.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/OutOfSchedule.jsx"
  },
  "resources/js/Pages/Terms.jsx": {
    file: "assets/Terms-25516e5a.js",
    imports: [
      "resources/js/app.jsx",
      "_ApplicationLogo-e6cf41e6.js",
      "_Icon-50c11904.js",
      "_PrimaryButton-7b40fb7a.js",
      "_index-9c160340.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Terms.jsx"
  },
  "resources/js/Pages/Users/Create.jsx": {
    file: "assets/Create-4e02de4d.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-54357aa5.js",
      "_TextInput-069b546e.js",
      "_InputError-bc123ba3.js",
      "_TextAreaInput-b95bcdb8.js",
      "_PrimaryButton-7b40fb7a.js",
      "_SelectInput-00333a1a.js",
      "_IranStatesOptions-6648d2c8.js",
      "_DangerButton-69546d75.js",
      "_useMemorable-e267c6b8.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_Icon-50c11904.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Create.jsx"
  },
  "resources/js/Pages/Users/Edit.jsx": {
    file: "assets/Edit-ca8dcdb0.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-54357aa5.js",
      "_TextAreaInput-b95bcdb8.js",
      "_TextInput-069b546e.js",
      "_InputError-bc123ba3.js",
      "_PrimaryButton-7b40fb7a.js",
      "_DangerButton-69546d75.js",
      "_SelectInput-00333a1a.js",
      "_WarningButton-9de61c11.js",
      "_Modal-fd1dd9ca.js",
      "_CheckboxInput-9ea0b622.js",
      "_InputLabel-6173deae.js",
      "_useMemorable-e267c6b8.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_Icon-50c11904.js",
      "_transition-f83752d2.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Edit.jsx"
  },
  "resources/js/Pages/Users/Index.jsx": {
    file: "assets/Index-630bc487.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-54357aa5.js",
      "_Pagination-29c0a636.js",
      "_TextInput-069b546e.js",
      "_useFirstRender-5387e4d4.js",
      "_SelectInput-00333a1a.js",
      "_useMemorable-e267c6b8.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_Icon-50c11904.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Index.jsx"
  },
  "resources/js/Pages/Users/NotCompleted.jsx": {
    file: "assets/NotCompleted-4d57b8f9.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-54357aa5.js",
      "_Pagination-29c0a636.js",
      "_SecondaryButton-e8b2c1e2.js",
      "_DangerButton-69546d75.js",
      "_Modal-fd1dd9ca.js",
      "_TextInput-069b546e.js",
      "_useFirstRender-5387e4d4.js",
      "_useMemorable-e267c6b8.js",
      "_ApplicationLogo-e6cf41e6.js",
      "_Icon-50c11904.js",
      "_transition-f83752d2.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/NotCompleted.jsx"
  },
  "resources/js/Pages/Users/Partials/DeleteUserForm.jsx": {
    file: "assets/DeleteUserForm-9dcfa100.js",
    imports: [
      "resources/js/app.jsx",
      "_DangerButton-69546d75.js",
      "_InputError-bc123ba3.js",
      "_InputLabel-6173deae.js",
      "_Modal-fd1dd9ca.js",
      "_SecondaryButton-e8b2c1e2.js",
      "_TextInput-069b546e.js",
      "_transition-f83752d2.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Partials/DeleteUserForm.jsx"
  },
  "resources/js/Pages/Users/Partials/UpdatePasswordForm.jsx": {
    file: "assets/UpdatePasswordForm-738e7f2d.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-bc123ba3.js",
      "_InputLabel-6173deae.js",
      "_PrimaryButton-7b40fb7a.js",
      "_TextInput-069b546e.js",
      "_transition-f83752d2.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Partials/UpdatePasswordForm.jsx"
  },
  "resources/js/Pages/Users/Partials/UpdateProfileInformationForm.jsx": {
    file: "assets/UpdateProfileInformationForm-9b970822.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-bc123ba3.js",
      "_InputLabel-6173deae.js",
      "_PrimaryButton-7b40fb7a.js",
      "_TextInput-069b546e.js",
      "_transition-f83752d2.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Partials/UpdateProfileInformationForm.jsx"
  },
  "resources/js/Pages/Welcome.jsx": {
    file: "assets/Welcome-5919df8d.js",
    imports: [
      "resources/js/app.jsx",
      "_ApplicationLogo-e6cf41e6.js",
      "_Icon-50c11904.js",
      "_PrimaryButton-7b40fb7a.js",
      "_index-9c160340.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Welcome.jsx"
  },
  "resources/js/app.css": {
    file: "assets/app-025210b0.css",
    src: "resources/js/app.css"
  },
  "resources/js/app.jsx": {
    assets: [
      "assets/Dana-Hairline-7712cf11.woff2",
      "assets/Dana-Hairline-6d7bb084.woff",
      "assets/Dana-Thin-bec2bd8a.woff2",
      "assets/Dana-Thin-56dc1e1f.woff",
      "assets/Dana-UltraLight-24615a03.woff2",
      "assets/Dana-UltraLight-a025f30e.woff",
      "assets/Dana-Light-e07a4868.woff2",
      "assets/Dana-Light-eeed4155.woff",
      "assets/Dana-Medium-d623f857.woff2",
      "assets/Dana-Medium-d0241b30.woff",
      "assets/Dana-DemiBold-34870445.woff2",
      "assets/Dana-DemiBold-fa427dcf.woff",
      "assets/Dana-ExtraBold-08dea612.woff2",
      "assets/Dana-ExtraBold-0d7888d7.woff",
      "assets/Dana-Black-cdfe2203.woff2",
      "assets/Dana-Black-575de1e5.woff",
      "assets/Dana-ExtraBlack-3208afe0.woff2",
      "assets/Dana-ExtraBlack-6c729c23.woff",
      "assets/Dana-Heavy-091eb261.woff2",
      "assets/Dana-Heavy-e159608a.woff",
      "assets/Dana-Fat-1f7b7061.woff2",
      "assets/Dana-Fat-8831a7f0.woff",
      "assets/Dana-Regular-43506011.woff2",
      "assets/Dana-Regular-eee25c04.woff"
    ],
    css: [
      "assets/app-025210b0.css"
    ],
    dynamicImports: [
      "resources/js/Pages/Accessories/Components/ProductsSlider.jsx",
      "_Create-c46f57df.js",
      "resources/js/Pages/Accessories/Index.jsx",
      "resources/js/Pages/Accessories/Show.jsx",
      "_Create-c46f57df.js",
      "_Create-c46f57df.js",
      "resources/js/Pages/Admin/Accessories.jsx",
      "resources/js/Pages/Admin/Records.jsx",
      "resources/js/Pages/Auth/Address.jsx",
      "resources/js/Pages/Auth/ConfirmPassword.jsx",
      "resources/js/Pages/Auth/ForgotPassword.jsx",
      "resources/js/Pages/Auth/Info.jsx",
      "resources/js/Pages/Auth/Login.jsx",
      "resources/js/Pages/Auth/Register.jsx",
      "resources/js/Pages/Auth/ResetPassword.jsx",
      "resources/js/Pages/Auth/VerifyEmail.jsx",
      "resources/js/Pages/Auth/WaitForVerify.jsx",
      "resources/js/Pages/Dashboards/Admin.jsx",
      "resources/js/Pages/Dashboards/User.jsx",
      "resources/js/Pages/Download/Accessory.jsx",
      "resources/js/Pages/Download/Record.jsx",
      "resources/js/Pages/Patients/Create.jsx",
      "resources/js/Pages/Patients/Edit.jsx",
      "resources/js/Pages/Patients/Index.jsx",
      "resources/js/Pages/Patients/Partials/DeleteUserForm.jsx",
      "resources/js/Pages/Patients/Partials/UpdatePasswordForm.jsx",
      "resources/js/Pages/Patients/Partials/UpdateProfileInformationForm.jsx",
      "resources/js/Pages/Products/CreateOrEdit.jsx",
      "resources/js/Pages/Products/Index.jsx",
      "resources/js/Pages/Profile/Edit.jsx",
      "resources/js/Pages/Profile/Index.jsx",
      "_AidInputs-d19dafa9.js",
      "resources/js/Pages/Records/Components/ProductsSlider.jsx",
      "resources/js/Pages/Records/Components/Steps.jsx",
      "_AidInputs-d19dafa9.js",
      "resources/js/Pages/Records/Index.jsx",
      "resources/js/Pages/Records/Partials/Step.jsx",
      "resources/js/Pages/Records/Show.jsx",
      "_AidInputs-d19dafa9.js",
      "_AidInputs-d19dafa9.js",
      "_AidInputs-d19dafa9.js",
      "_AidInputs-d19dafa9.js",
      "_AidInputs-d19dafa9.js",
      "resources/js/Pages/Settings/CreateOrEdit.jsx",
      "resources/js/Pages/Settings/Index.jsx",
      "resources/js/Pages/Settings/OffLimits.jsx",
      "resources/js/Pages/Settings/OutOfSchedule.jsx",
      "resources/js/Pages/Terms.jsx",
      "resources/js/Pages/Users/Create.jsx",
      "resources/js/Pages/Users/Edit.jsx",
      "resources/js/Pages/Users/Index.jsx",
      "resources/js/Pages/Users/NotCompleted.jsx",
      "resources/js/Pages/Users/Partials/DeleteUserForm.jsx",
      "resources/js/Pages/Users/Partials/UpdatePasswordForm.jsx",
      "resources/js/Pages/Users/Partials/UpdateProfileInformationForm.jsx",
      "resources/js/Pages/Welcome.jsx"
    ],
    file: "assets/app-ff35311f.js",
    isEntry: true,
    src: "resources/js/app.jsx"
  }
};
export {
  manifest as m
};
