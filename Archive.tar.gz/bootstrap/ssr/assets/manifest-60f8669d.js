const manifest = {
  "AuthenticatedLayout.css": {
    file: "assets/AuthenticatedLayout-3a83175c.css",
    src: "AuthenticatedLayout.css"
  },
  "_AidInputs-61f2231f.js": {
    file: "assets/AidInputs-61f2231f.js",
    imports: [
      "resources/js/app.jsx",
      "_SelectInput-75d1eabf.js",
      "_InputError-e7ff0fb0.js",
      "_PrimaryButton-9f00309d.js",
      "_DangerButton-36244ab2.js",
      "_AuthenticatedLayout-f38a9f8c.js",
      "resources/js/Pages/Records/Components/Steps.jsx",
      "_TextInput-eef2fb7a.js",
      "_TextAreaInput-cb0527cc.js",
      "_IranStatesOptions-0e2734b3.js",
      "_FileInput-79514a62.js",
      "_RadioInput-60a7e986.js",
      "_InputLabel-c9c98d7e.js",
      "resources/js/Pages/Records/Components/ProductsSlider.jsx",
      "_useFirstRender-08e922f2.js",
      "_CheckboxInput-6c1e4dc3.js"
    ],
    isDynamicEntry: true
  },
  "_ApplicationLogo-e1673402.js": {
    file: "assets/ApplicationLogo-e1673402.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_ArrowLink-6eff003d.js": {
    file: "assets/ArrowLink-6eff003d.js",
    imports: [
      "resources/js/app.jsx",
      "__commonjs-dynamic-modules-302442b1.js"
    ]
  },
  "_AuthenticatedLayout-f38a9f8c.js": {
    css: [
      "assets/AuthenticatedLayout-3a83175c.css"
    ],
    file: "assets/AuthenticatedLayout-f38a9f8c.js",
    imports: [
      "resources/js/app.jsx",
      "_useMemorable-a23b07b1.js",
      "_ApplicationLogo-e1673402.js",
      "_Icon-5e3ee85e.js"
    ]
  },
  "_CheckboxInput-6c1e4dc3.js": {
    file: "assets/CheckboxInput-6c1e4dc3.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_Create-577a37cf.js": {
    file: "assets/Create-577a37cf.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-f38a9f8c.js",
      "_TextInput-eef2fb7a.js",
      "_InputError-e7ff0fb0.js",
      "_TextAreaInput-cb0527cc.js",
      "_PrimaryButton-9f00309d.js",
      "_SelectInput-75d1eabf.js",
      "_RadioInput-60a7e986.js",
      "_InputLabel-c9c98d7e.js",
      "resources/js/Pages/Accessories/Components/ProductsSlider.jsx",
      "_CheckboxInput-6c1e4dc3.js",
      "_DangerButton-36244ab2.js",
      "_Icon-5e3ee85e.js"
    ],
    isDynamicEntry: true
  },
  "_DangerButton-36244ab2.js": {
    file: "assets/DangerButton-36244ab2.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_FileInput-79514a62.js": {
    file: "assets/FileInput-79514a62.js",
    imports: [
      "resources/js/app.jsx",
      "_Icon-5e3ee85e.js",
      "_PrimaryButton-9f00309d.js"
    ]
  },
  "_GuestLayout-74d71f24.js": {
    file: "assets/GuestLayout-74d71f24.js",
    imports: [
      "resources/js/app.jsx",
      "_ApplicationLogo-e1673402.js",
      "_useMemorable-a23b07b1.js"
    ]
  },
  "_Icon-5e3ee85e.js": {
    file: "assets/Icon-5e3ee85e.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_InputError-e7ff0fb0.js": {
    file: "assets/InputError-e7ff0fb0.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_InputLabel-c9c98d7e.js": {
    file: "assets/InputLabel-c9c98d7e.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_IranStatesOptions-0e2734b3.js": {
    file: "assets/IranStatesOptions-0e2734b3.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_Modal-71119db2.js": {
    file: "assets/Modal-71119db2.js",
    imports: [
      "resources/js/app.jsx",
      "_transition-8389e0f6.js"
    ]
  },
  "_Pagination-22d9da98.js": {
    file: "assets/Pagination-22d9da98.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_PrimaryButton-9f00309d.js": {
    file: "assets/PrimaryButton-9f00309d.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_RadioInput-60a7e986.js": {
    file: "assets/RadioInput-60a7e986.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_SecondaryButton-0abe6917.js": {
    file: "assets/SecondaryButton-0abe6917.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_SelectInput-75d1eabf.js": {
    file: "assets/SelectInput-75d1eabf.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_TextAreaInput-cb0527cc.js": {
    file: "assets/TextAreaInput-cb0527cc.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_TextInput-eef2fb7a.js": {
    file: "assets/TextInput-eef2fb7a.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_WarningButton-7ee01e6c.js": {
    file: "assets/WarningButton-7ee01e6c.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "__commonjs-dynamic-modules-302442b1.js": {
    file: "assets/_commonjs-dynamic-modules-302442b1.js"
  },
  "_index-b0056569.js": {
    file: "assets/index-b0056569.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_lottie-react.esm-f5dd1098.js": {
    file: "assets/lottie-react.esm-f5dd1098.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_manifest-05b3c0a1.js": {
    file: "assets/manifest-05b3c0a1.js"
  },
  "_pagination-22e5af8c.js": {
    css: [
      "assets/pagination-58c369bc.css"
    ],
    file: "assets/pagination-22e5af8c.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_transition-8389e0f6.js": {
    file: "assets/transition-8389e0f6.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_useFirstRender-08e922f2.js": {
    file: "assets/useFirstRender-08e922f2.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_useMemorable-a23b07b1.js": {
    file: "assets/useMemorable-a23b07b1.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "pagination.css": {
    file: "assets/pagination-58c369bc.css",
    src: "pagination.css"
  },
  "resources/fonts/woff/Dana-Black.woff": {
    file: "assets/Dana-Black-575de1e5.woff",
    src: "resources/fonts/woff/Dana-Black.woff"
  },
  "resources/fonts/woff/Dana-DemiBold.woff": {
    file: "assets/Dana-DemiBold-fa427dcf.woff",
    src: "resources/fonts/woff/Dana-DemiBold.woff"
  },
  "resources/fonts/woff/Dana-ExtraBlack.woff": {
    file: "assets/Dana-ExtraBlack-6c729c23.woff",
    src: "resources/fonts/woff/Dana-ExtraBlack.woff"
  },
  "resources/fonts/woff/Dana-ExtraBold.woff": {
    file: "assets/Dana-ExtraBold-0d7888d7.woff",
    src: "resources/fonts/woff/Dana-ExtraBold.woff"
  },
  "resources/fonts/woff/Dana-Fat.woff": {
    file: "assets/Dana-Fat-8831a7f0.woff",
    src: "resources/fonts/woff/Dana-Fat.woff"
  },
  "resources/fonts/woff/Dana-Hairline.woff": {
    file: "assets/Dana-Hairline-6d7bb084.woff",
    src: "resources/fonts/woff/Dana-Hairline.woff"
  },
  "resources/fonts/woff/Dana-Heavy.woff": {
    file: "assets/Dana-Heavy-e159608a.woff",
    src: "resources/fonts/woff/Dana-Heavy.woff"
  },
  "resources/fonts/woff/Dana-Light.woff": {
    file: "assets/Dana-Light-eeed4155.woff",
    src: "resources/fonts/woff/Dana-Light.woff"
  },
  "resources/fonts/woff/Dana-Medium.woff": {
    file: "assets/Dana-Medium-d0241b30.woff",
    src: "resources/fonts/woff/Dana-Medium.woff"
  },
  "resources/fonts/woff/Dana-Regular.woff": {
    file: "assets/Dana-Regular-eee25c04.woff",
    src: "resources/fonts/woff/Dana-Regular.woff"
  },
  "resources/fonts/woff/Dana-Thin.woff": {
    file: "assets/Dana-Thin-56dc1e1f.woff",
    src: "resources/fonts/woff/Dana-Thin.woff"
  },
  "resources/fonts/woff/Dana-UltraLight.woff": {
    file: "assets/Dana-UltraLight-a025f30e.woff",
    src: "resources/fonts/woff/Dana-UltraLight.woff"
  },
  "resources/fonts/woff2/Dana-Black.woff2": {
    file: "assets/Dana-Black-cdfe2203.woff2",
    src: "resources/fonts/woff2/Dana-Black.woff2"
  },
  "resources/fonts/woff2/Dana-DemiBold.woff2": {
    file: "assets/Dana-DemiBold-34870445.woff2",
    src: "resources/fonts/woff2/Dana-DemiBold.woff2"
  },
  "resources/fonts/woff2/Dana-ExtraBlack.woff2": {
    file: "assets/Dana-ExtraBlack-3208afe0.woff2",
    src: "resources/fonts/woff2/Dana-ExtraBlack.woff2"
  },
  "resources/fonts/woff2/Dana-ExtraBold.woff2": {
    file: "assets/Dana-ExtraBold-08dea612.woff2",
    src: "resources/fonts/woff2/Dana-ExtraBold.woff2"
  },
  "resources/fonts/woff2/Dana-Fat.woff2": {
    file: "assets/Dana-Fat-1f7b7061.woff2",
    src: "resources/fonts/woff2/Dana-Fat.woff2"
  },
  "resources/fonts/woff2/Dana-Hairline.woff2": {
    file: "assets/Dana-Hairline-7712cf11.woff2",
    src: "resources/fonts/woff2/Dana-Hairline.woff2"
  },
  "resources/fonts/woff2/Dana-Heavy.woff2": {
    file: "assets/Dana-Heavy-091eb261.woff2",
    src: "resources/fonts/woff2/Dana-Heavy.woff2"
  },
  "resources/fonts/woff2/Dana-Light.woff2": {
    file: "assets/Dana-Light-e07a4868.woff2",
    src: "resources/fonts/woff2/Dana-Light.woff2"
  },
  "resources/fonts/woff2/Dana-Medium.woff2": {
    file: "assets/Dana-Medium-d623f857.woff2",
    src: "resources/fonts/woff2/Dana-Medium.woff2"
  },
  "resources/fonts/woff2/Dana-Regular.woff2": {
    file: "assets/Dana-Regular-43506011.woff2",
    src: "resources/fonts/woff2/Dana-Regular.woff2"
  },
  "resources/fonts/woff2/Dana-Thin.woff2": {
    file: "assets/Dana-Thin-bec2bd8a.woff2",
    src: "resources/fonts/woff2/Dana-Thin.woff2"
  },
  "resources/fonts/woff2/Dana-UltraLight.woff2": {
    file: "assets/Dana-UltraLight-24615a03.woff2",
    src: "resources/fonts/woff2/Dana-UltraLight.woff2"
  },
  "resources/js/Pages/Accessories/Components/ProductsSlider.jsx": {
    file: "assets/ProductsSlider-b4399f6d.js",
    imports: [
      "resources/js/app.jsx",
      "_pagination-22e5af8c.js",
      "_RadioInput-60a7e986.js",
      "_InputLabel-c9c98d7e.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Accessories/Components/ProductsSlider.jsx"
  },
  "resources/js/Pages/Accessories/Index.jsx": {
    file: "assets/Index-90c9407b.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-f38a9f8c.js",
      "_SecondaryButton-0abe6917.js",
      "_DangerButton-36244ab2.js",
      "_Modal-71119db2.js",
      "_PrimaryButton-9f00309d.js",
      "_Pagination-22d9da98.js",
      "_useMemorable-a23b07b1.js",
      "_ApplicationLogo-e1673402.js",
      "_Icon-5e3ee85e.js",
      "_transition-8389e0f6.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Accessories/Index.jsx"
  },
  "resources/js/Pages/Accessories/Show.jsx": {
    file: "assets/Show-d3d9cd9e.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-f38a9f8c.js",
      "_WarningButton-7ee01e6c.js",
      "_PrimaryButton-9f00309d.js",
      "_SecondaryButton-0abe6917.js",
      "_useMemorable-a23b07b1.js",
      "_ApplicationLogo-e1673402.js",
      "_Icon-5e3ee85e.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Accessories/Show.jsx"
  },
  "resources/js/Pages/Admin/Accessories.jsx": {
    file: "assets/Accessories-14b88120.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-f38a9f8c.js",
      "_Pagination-22d9da98.js",
      "_useFirstRender-08e922f2.js",
      "_TextInput-eef2fb7a.js",
      "_useMemorable-a23b07b1.js",
      "_ApplicationLogo-e1673402.js",
      "_Icon-5e3ee85e.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Admin/Accessories.jsx"
  },
  "resources/js/Pages/Admin/Records.jsx": {
    file: "assets/Records-a97a5101.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-f38a9f8c.js",
      "_Pagination-22d9da98.js",
      "_TextInput-eef2fb7a.js",
      "_useFirstRender-08e922f2.js",
      "_useMemorable-a23b07b1.js",
      "_ApplicationLogo-e1673402.js",
      "_Icon-5e3ee85e.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Admin/Records.jsx"
  },
  "resources/js/Pages/Auth/Address.jsx": {
    file: "assets/Address-6d51b0bc.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-74d71f24.js",
      "_InputError-e7ff0fb0.js",
      "_PrimaryButton-9f00309d.js",
      "_TextInput-eef2fb7a.js",
      "_TextAreaInput-cb0527cc.js",
      "_RadioInput-60a7e986.js",
      "_InputLabel-c9c98d7e.js",
      "_Icon-5e3ee85e.js",
      "_DangerButton-36244ab2.js",
      "_ApplicationLogo-e1673402.js",
      "_useMemorable-a23b07b1.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Address.jsx"
  },
  "resources/js/Pages/Auth/ConfirmPassword.jsx": {
    file: "assets/ConfirmPassword-1a268909.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-74d71f24.js",
      "_InputError-e7ff0fb0.js",
      "_InputLabel-c9c98d7e.js",
      "_PrimaryButton-9f00309d.js",
      "_TextInput-eef2fb7a.js",
      "_ApplicationLogo-e1673402.js",
      "_useMemorable-a23b07b1.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/ConfirmPassword.jsx"
  },
  "resources/js/Pages/Auth/ForgotPassword.jsx": {
    file: "assets/ForgotPassword-57e516c4.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-74d71f24.js",
      "_InputError-e7ff0fb0.js",
      "_PrimaryButton-9f00309d.js",
      "_TextInput-eef2fb7a.js",
      "_ApplicationLogo-e1673402.js",
      "_useMemorable-a23b07b1.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/ForgotPassword.jsx"
  },
  "resources/js/Pages/Auth/Info.jsx": {
    file: "assets/Info-b3c71cc8.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-74d71f24.js",
      "_InputError-e7ff0fb0.js",
      "_PrimaryButton-9f00309d.js",
      "_TextInput-eef2fb7a.js",
      "_TextAreaInput-cb0527cc.js",
      "_FileInput-79514a62.js",
      "_InputLabel-c9c98d7e.js",
      "_ApplicationLogo-e1673402.js",
      "_useMemorable-a23b07b1.js",
      "_Icon-5e3ee85e.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Info.jsx"
  },
  "resources/js/Pages/Auth/Login.jsx": {
    file: "assets/Login-8ba6dbb6.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-74d71f24.js",
      "_InputError-e7ff0fb0.js",
      "_InputLabel-c9c98d7e.js",
      "_PrimaryButton-9f00309d.js",
      "_TextInput-eef2fb7a.js",
      "_CheckboxInput-6c1e4dc3.js",
      "_WarningButton-7ee01e6c.js",
      "_Icon-5e3ee85e.js",
      "_ApplicationLogo-e1673402.js",
      "_useMemorable-a23b07b1.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Login.jsx"
  },
  "resources/js/Pages/Auth/Register.jsx": {
    file: "assets/Register-f1342e4c.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-74d71f24.js",
      "_InputError-e7ff0fb0.js",
      "_PrimaryButton-9f00309d.js",
      "_TextInput-eef2fb7a.js",
      "_SelectInput-75d1eabf.js",
      "_IranStatesOptions-0e2734b3.js",
      "_ApplicationLogo-e1673402.js",
      "_useMemorable-a23b07b1.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Register.jsx"
  },
  "resources/js/Pages/Auth/ResetPassword.jsx": {
    file: "assets/ResetPassword-1c4d2ce8.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-74d71f24.js",
      "_InputError-e7ff0fb0.js",
      "_PrimaryButton-9f00309d.js",
      "_TextInput-eef2fb7a.js",
      "_ApplicationLogo-e1673402.js",
      "_useMemorable-a23b07b1.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/ResetPassword.jsx"
  },
  "resources/js/Pages/Auth/VerifyEmail.jsx": {
    file: "assets/VerifyEmail-58e42039.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-74d71f24.js",
      "_PrimaryButton-9f00309d.js",
      "_ApplicationLogo-e1673402.js",
      "_useMemorable-a23b07b1.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/VerifyEmail.jsx"
  },
  "resources/js/Pages/Auth/WaitForVerify.jsx": {
    file: "assets/WaitForVerify-dca82982.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-74d71f24.js",
      "_lottie-react.esm-f5dd1098.js",
      "_PrimaryButton-9f00309d.js",
      "_DangerButton-36244ab2.js",
      "_ApplicationLogo-e1673402.js",
      "_useMemorable-a23b07b1.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/WaitForVerify.jsx"
  },
  "resources/js/Pages/Dashboards/Admin.jsx": {
    file: "assets/Admin-097fab4f.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-f38a9f8c.js",
      "_ArrowLink-6eff003d.js",
      "_useMemorable-a23b07b1.js",
      "_ApplicationLogo-e1673402.js",
      "_Icon-5e3ee85e.js",
      "__commonjs-dynamic-modules-302442b1.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Dashboards/Admin.jsx"
  },
  "resources/js/Pages/Dashboards/User.jsx": {
    file: "assets/User-e839ca95.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-f38a9f8c.js",
      "_ArrowLink-6eff003d.js",
      "_useMemorable-a23b07b1.js",
      "_ApplicationLogo-e1673402.js",
      "_Icon-5e3ee85e.js",
      "__commonjs-dynamic-modules-302442b1.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Dashboards/User.jsx"
  },
  "resources/js/Pages/Download/Accessory.jsx": {
    file: "assets/Accessory-52c94245.js",
    imports: [
      "resources/js/app.jsx",
      "_manifest-05b3c0a1.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Download/Accessory.jsx"
  },
  "resources/js/Pages/Download/Record.jsx": {
    file: "assets/Record-f251995e.js",
    imports: [
      "resources/js/app.jsx",
      "_manifest-05b3c0a1.js",
      "__commonjs-dynamic-modules-302442b1.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Download/Record.jsx"
  },
  "resources/js/Pages/Patients/Create.jsx": {
    file: "assets/Create-a4b0c920.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-f38a9f8c.js",
      "_TextInput-eef2fb7a.js",
      "_InputError-e7ff0fb0.js",
      "_TextAreaInput-cb0527cc.js",
      "_PrimaryButton-9f00309d.js",
      "_SelectInput-75d1eabf.js",
      "_IranStatesOptions-0e2734b3.js",
      "_DangerButton-36244ab2.js",
      "_useMemorable-a23b07b1.js",
      "_ApplicationLogo-e1673402.js",
      "_Icon-5e3ee85e.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Create.jsx"
  },
  "resources/js/Pages/Patients/Edit.jsx": {
    file: "assets/Edit-a11a16f6.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-f38a9f8c.js",
      "_TextInput-eef2fb7a.js",
      "_InputError-e7ff0fb0.js",
      "_TextAreaInput-cb0527cc.js",
      "_PrimaryButton-9f00309d.js",
      "_SelectInput-75d1eabf.js",
      "_IranStatesOptions-0e2734b3.js",
      "_DangerButton-36244ab2.js",
      "_useMemorable-a23b07b1.js",
      "_ApplicationLogo-e1673402.js",
      "_Icon-5e3ee85e.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Edit.jsx"
  },
  "resources/js/Pages/Patients/Index.jsx": {
    file: "assets/Index-83eb10ce.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-f38a9f8c.js",
      "_SecondaryButton-0abe6917.js",
      "_DangerButton-36244ab2.js",
      "_Modal-71119db2.js",
      "_Pagination-22d9da98.js",
      "_useMemorable-a23b07b1.js",
      "_ApplicationLogo-e1673402.js",
      "_Icon-5e3ee85e.js",
      "_transition-8389e0f6.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Index.jsx"
  },
  "resources/js/Pages/Patients/Partials/DeleteUserForm.jsx": {
    file: "assets/DeleteUserForm-685330f3.js",
    imports: [
      "resources/js/app.jsx",
      "_DangerButton-36244ab2.js",
      "_InputError-e7ff0fb0.js",
      "_InputLabel-c9c98d7e.js",
      "_Modal-71119db2.js",
      "_SecondaryButton-0abe6917.js",
      "_TextInput-eef2fb7a.js",
      "_transition-8389e0f6.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Partials/DeleteUserForm.jsx"
  },
  "resources/js/Pages/Patients/Partials/UpdatePasswordForm.jsx": {
    file: "assets/UpdatePasswordForm-631aeeae.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-e7ff0fb0.js",
      "_InputLabel-c9c98d7e.js",
      "_PrimaryButton-9f00309d.js",
      "_TextInput-eef2fb7a.js",
      "_transition-8389e0f6.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Partials/UpdatePasswordForm.jsx"
  },
  "resources/js/Pages/Patients/Partials/UpdateProfileInformationForm.jsx": {
    file: "assets/UpdateProfileInformationForm-a6dd7b17.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-e7ff0fb0.js",
      "_InputLabel-c9c98d7e.js",
      "_PrimaryButton-9f00309d.js",
      "_TextInput-eef2fb7a.js",
      "_transition-8389e0f6.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Partials/UpdateProfileInformationForm.jsx"
  },
  "resources/js/Pages/Products/CreateOrEdit.jsx": {
    file: "assets/CreateOrEdit-7c2ebfe9.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-f38a9f8c.js",
      "_TextInput-eef2fb7a.js",
      "_InputError-e7ff0fb0.js",
      "_PrimaryButton-9f00309d.js",
      "_SelectInput-75d1eabf.js",
      "_DangerButton-36244ab2.js",
      "_Icon-5e3ee85e.js",
      "_CheckboxInput-6c1e4dc3.js",
      "_InputLabel-c9c98d7e.js",
      "_useMemorable-a23b07b1.js",
      "_ApplicationLogo-e1673402.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Products/CreateOrEdit.jsx"
  },
  "resources/js/Pages/Products/Index.jsx": {
    file: "assets/Index-dafd97e2.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-f38a9f8c.js",
      "_SecondaryButton-0abe6917.js",
      "_DangerButton-36244ab2.js",
      "_Modal-71119db2.js",
      "_PrimaryButton-9f00309d.js",
      "_Pagination-22d9da98.js",
      "_TextInput-eef2fb7a.js",
      "_useMemorable-a23b07b1.js",
      "_ApplicationLogo-e1673402.js",
      "_Icon-5e3ee85e.js",
      "_transition-8389e0f6.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Products/Index.jsx"
  },
  "resources/js/Pages/Profile/Edit.jsx": {
    file: "assets/Edit-0ce3d35b.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-f38a9f8c.js",
      "_GuestLayout-74d71f24.js",
      "_TextInput-eef2fb7a.js",
      "_InputError-e7ff0fb0.js",
      "_TextAreaInput-cb0527cc.js",
      "_PrimaryButton-9f00309d.js",
      "_DangerButton-36244ab2.js",
      "_SelectInput-75d1eabf.js",
      "_IranStatesOptions-0e2734b3.js",
      "_FileInput-79514a62.js",
      "_RadioInput-60a7e986.js",
      "_InputLabel-c9c98d7e.js",
      "_useMemorable-a23b07b1.js",
      "_ApplicationLogo-e1673402.js",
      "_Icon-5e3ee85e.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Profile/Edit.jsx"
  },
  "resources/js/Pages/Profile/Index.jsx": {
    file: "assets/Index-13dc4c59.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-f38a9f8c.js",
      "_WarningButton-7ee01e6c.js",
      "_useMemorable-a23b07b1.js",
      "_ApplicationLogo-e1673402.js",
      "_Icon-5e3ee85e.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Profile/Index.jsx"
  },
  "resources/js/Pages/Records/Components/ProductsSlider.jsx": {
    file: "assets/ProductsSlider-7245ece9.js",
    imports: [
      "resources/js/app.jsx",
      "_pagination-22e5af8c.js",
      "_RadioInput-60a7e986.js",
      "_InputLabel-c9c98d7e.js",
      "_CheckboxInput-6c1e4dc3.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Components/ProductsSlider.jsx"
  },
  "resources/js/Pages/Records/Components/Steps.jsx": {
    file: "assets/Steps-30bf7036.js",
    imports: [
      "resources/js/app.jsx",
      "resources/js/Pages/Records/Partials/Step.jsx",
      "_Icon-5e3ee85e.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Components/Steps.jsx"
  },
  "resources/js/Pages/Records/Index.jsx": {
    file: "assets/Index-0e632f96.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-f38a9f8c.js",
      "_SecondaryButton-0abe6917.js",
      "_DangerButton-36244ab2.js",
      "_Modal-71119db2.js",
      "_PrimaryButton-9f00309d.js",
      "_Pagination-22d9da98.js",
      "_useMemorable-a23b07b1.js",
      "_ApplicationLogo-e1673402.js",
      "_Icon-5e3ee85e.js",
      "_transition-8389e0f6.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Index.jsx"
  },
  "resources/js/Pages/Records/Partials/Step.jsx": {
    file: "assets/Step-5e6220f6.js",
    imports: [
      "resources/js/app.jsx"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Partials/Step.jsx"
  },
  "resources/js/Pages/Records/Show.jsx": {
    file: "assets/Show-336e51a9.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-f38a9f8c.js",
      "_WarningButton-7ee01e6c.js",
      "_PrimaryButton-9f00309d.js",
      "_SecondaryButton-0abe6917.js",
      "_useMemorable-a23b07b1.js",
      "_ApplicationLogo-e1673402.js",
      "_Icon-5e3ee85e.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Show.jsx"
  },
  "resources/js/Pages/Settings/CreateOrEdit.jsx": {
    file: "assets/CreateOrEdit-db2b69d8.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-f38a9f8c.js",
      "_TextInput-eef2fb7a.js",
      "_InputError-e7ff0fb0.js",
      "_PrimaryButton-9f00309d.js",
      "_DangerButton-36244ab2.js",
      "_useMemorable-a23b07b1.js",
      "_ApplicationLogo-e1673402.js",
      "_Icon-5e3ee85e.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/CreateOrEdit.jsx"
  },
  "resources/js/Pages/Settings/Index.jsx": {
    file: "assets/Index-160bab34.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-f38a9f8c.js",
      "_SecondaryButton-0abe6917.js",
      "_DangerButton-36244ab2.js",
      "_Modal-71119db2.js",
      "_PrimaryButton-9f00309d.js",
      "_Pagination-22d9da98.js",
      "_useMemorable-a23b07b1.js",
      "_ApplicationLogo-e1673402.js",
      "_Icon-5e3ee85e.js",
      "_transition-8389e0f6.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/Index.jsx"
  },
  "resources/js/Pages/Settings/OffLimits.jsx": {
    file: "assets/OffLimits-5ee9cbc6.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-f38a9f8c.js",
      "_PrimaryButton-9f00309d.js",
      "_lottie-react.esm-f5dd1098.js",
      "_useMemorable-a23b07b1.js",
      "_ApplicationLogo-e1673402.js",
      "_Icon-5e3ee85e.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/OffLimits.jsx"
  },
  "resources/js/Pages/Settings/OutOfSchedule.jsx": {
    file: "assets/OutOfSchedule-39f236a0.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-f38a9f8c.js",
      "_PrimaryButton-9f00309d.js",
      "_lottie-react.esm-f5dd1098.js",
      "_useMemorable-a23b07b1.js",
      "_ApplicationLogo-e1673402.js",
      "_Icon-5e3ee85e.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/OutOfSchedule.jsx"
  },
  "resources/js/Pages/Terms.jsx": {
    file: "assets/Terms-75aeb7bb.js",
    imports: [
      "resources/js/app.jsx",
      "_ApplicationLogo-e1673402.js",
      "_Icon-5e3ee85e.js",
      "_PrimaryButton-9f00309d.js",
      "_index-b0056569.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Terms.jsx"
  },
  "resources/js/Pages/Users/Create.jsx": {
    file: "assets/Create-cdeab708.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-f38a9f8c.js",
      "_TextInput-eef2fb7a.js",
      "_InputError-e7ff0fb0.js",
      "_TextAreaInput-cb0527cc.js",
      "_PrimaryButton-9f00309d.js",
      "_SelectInput-75d1eabf.js",
      "_IranStatesOptions-0e2734b3.js",
      "_DangerButton-36244ab2.js",
      "_useMemorable-a23b07b1.js",
      "_ApplicationLogo-e1673402.js",
      "_Icon-5e3ee85e.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Create.jsx"
  },
  "resources/js/Pages/Users/Edit.jsx": {
    file: "assets/Edit-412f95f9.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-f38a9f8c.js",
      "_TextAreaInput-cb0527cc.js",
      "_TextInput-eef2fb7a.js",
      "_InputError-e7ff0fb0.js",
      "_PrimaryButton-9f00309d.js",
      "_DangerButton-36244ab2.js",
      "_SelectInput-75d1eabf.js",
      "_WarningButton-7ee01e6c.js",
      "_Modal-71119db2.js",
      "_useMemorable-a23b07b1.js",
      "_ApplicationLogo-e1673402.js",
      "_Icon-5e3ee85e.js",
      "_transition-8389e0f6.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Edit.jsx"
  },
  "resources/js/Pages/Users/Index.jsx": {
    file: "assets/Index-be5c7508.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-f38a9f8c.js",
      "_Pagination-22d9da98.js",
      "_TextInput-eef2fb7a.js",
      "_useFirstRender-08e922f2.js",
      "_useMemorable-a23b07b1.js",
      "_ApplicationLogo-e1673402.js",
      "_Icon-5e3ee85e.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Index.jsx"
  },
  "resources/js/Pages/Users/Partials/DeleteUserForm.jsx": {
    file: "assets/DeleteUserForm-cb90829e.js",
    imports: [
      "resources/js/app.jsx",
      "_DangerButton-36244ab2.js",
      "_InputError-e7ff0fb0.js",
      "_InputLabel-c9c98d7e.js",
      "_Modal-71119db2.js",
      "_SecondaryButton-0abe6917.js",
      "_TextInput-eef2fb7a.js",
      "_transition-8389e0f6.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Partials/DeleteUserForm.jsx"
  },
  "resources/js/Pages/Users/Partials/UpdatePasswordForm.jsx": {
    file: "assets/UpdatePasswordForm-942edd32.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-e7ff0fb0.js",
      "_InputLabel-c9c98d7e.js",
      "_PrimaryButton-9f00309d.js",
      "_TextInput-eef2fb7a.js",
      "_transition-8389e0f6.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Partials/UpdatePasswordForm.jsx"
  },
  "resources/js/Pages/Users/Partials/UpdateProfileInformationForm.jsx": {
    file: "assets/UpdateProfileInformationForm-f7a3d509.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-e7ff0fb0.js",
      "_InputLabel-c9c98d7e.js",
      "_PrimaryButton-9f00309d.js",
      "_TextInput-eef2fb7a.js",
      "_transition-8389e0f6.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Partials/UpdateProfileInformationForm.jsx"
  },
  "resources/js/Pages/Welcome.jsx": {
    file: "assets/Welcome-bc0a3770.js",
    imports: [
      "resources/js/app.jsx",
      "_ApplicationLogo-e1673402.js",
      "_Icon-5e3ee85e.js",
      "_PrimaryButton-9f00309d.js",
      "_index-b0056569.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Welcome.jsx"
  },
  "resources/js/app.css": {
    file: "assets/app-eb351a47.css",
    src: "resources/js/app.css"
  },
  "resources/js/app.jsx": {
    assets: [
      "assets/Dana-Hairline-7712cf11.woff2",
      "assets/Dana-Hairline-6d7bb084.woff",
      "assets/Dana-Thin-bec2bd8a.woff2",
      "assets/Dana-Thin-56dc1e1f.woff",
      "assets/Dana-UltraLight-24615a03.woff2",
      "assets/Dana-UltraLight-a025f30e.woff",
      "assets/Dana-Light-e07a4868.woff2",
      "assets/Dana-Light-eeed4155.woff",
      "assets/Dana-Medium-d623f857.woff2",
      "assets/Dana-Medium-d0241b30.woff",
      "assets/Dana-DemiBold-34870445.woff2",
      "assets/Dana-DemiBold-fa427dcf.woff",
      "assets/Dana-ExtraBold-08dea612.woff2",
      "assets/Dana-ExtraBold-0d7888d7.woff",
      "assets/Dana-Black-cdfe2203.woff2",
      "assets/Dana-Black-575de1e5.woff",
      "assets/Dana-ExtraBlack-3208afe0.woff2",
      "assets/Dana-ExtraBlack-6c729c23.woff",
      "assets/Dana-Heavy-091eb261.woff2",
      "assets/Dana-Heavy-e159608a.woff",
      "assets/Dana-Fat-1f7b7061.woff2",
      "assets/Dana-Fat-8831a7f0.woff",
      "assets/Dana-Regular-43506011.woff2",
      "assets/Dana-Regular-eee25c04.woff"
    ],
    css: [
      "assets/app-eb351a47.css"
    ],
    dynamicImports: [
      "resources/js/Pages/Accessories/Components/ProductsSlider.jsx",
      "_Create-577a37cf.js",
      "resources/js/Pages/Accessories/Index.jsx",
      "resources/js/Pages/Accessories/Show.jsx",
      "_Create-577a37cf.js",
      "_Create-577a37cf.js",
      "resources/js/Pages/Admin/Accessories.jsx",
      "resources/js/Pages/Admin/Records.jsx",
      "resources/js/Pages/Auth/Address.jsx",
      "resources/js/Pages/Auth/ConfirmPassword.jsx",
      "resources/js/Pages/Auth/ForgotPassword.jsx",
      "resources/js/Pages/Auth/Info.jsx",
      "resources/js/Pages/Auth/Login.jsx",
      "resources/js/Pages/Auth/Register.jsx",
      "resources/js/Pages/Auth/ResetPassword.jsx",
      "resources/js/Pages/Auth/VerifyEmail.jsx",
      "resources/js/Pages/Auth/WaitForVerify.jsx",
      "resources/js/Pages/Dashboards/Admin.jsx",
      "resources/js/Pages/Dashboards/User.jsx",
      "resources/js/Pages/Download/Accessory.jsx",
      "resources/js/Pages/Download/Record.jsx",
      "resources/js/Pages/Patients/Create.jsx",
      "resources/js/Pages/Patients/Edit.jsx",
      "resources/js/Pages/Patients/Index.jsx",
      "resources/js/Pages/Patients/Partials/DeleteUserForm.jsx",
      "resources/js/Pages/Patients/Partials/UpdatePasswordForm.jsx",
      "resources/js/Pages/Patients/Partials/UpdateProfileInformationForm.jsx",
      "resources/js/Pages/Products/CreateOrEdit.jsx",
      "resources/js/Pages/Products/Index.jsx",
      "resources/js/Pages/Profile/Edit.jsx",
      "resources/js/Pages/Profile/Index.jsx",
      "_AidInputs-61f2231f.js",
      "resources/js/Pages/Records/Components/ProductsSlider.jsx",
      "resources/js/Pages/Records/Components/Steps.jsx",
      "_AidInputs-61f2231f.js",
      "resources/js/Pages/Records/Index.jsx",
      "resources/js/Pages/Records/Partials/Step.jsx",
      "resources/js/Pages/Records/Show.jsx",
      "_AidInputs-61f2231f.js",
      "_AidInputs-61f2231f.js",
      "_AidInputs-61f2231f.js",
      "_AidInputs-61f2231f.js",
      "_AidInputs-61f2231f.js",
      "resources/js/Pages/Settings/CreateOrEdit.jsx",
      "resources/js/Pages/Settings/Index.jsx",
      "resources/js/Pages/Settings/OffLimits.jsx",
      "resources/js/Pages/Settings/OutOfSchedule.jsx",
      "resources/js/Pages/Terms.jsx",
      "resources/js/Pages/Users/Create.jsx",
      "resources/js/Pages/Users/Edit.jsx",
      "resources/js/Pages/Users/Index.jsx",
      "resources/js/Pages/Users/Partials/DeleteUserForm.jsx",
      "resources/js/Pages/Users/Partials/UpdatePasswordForm.jsx",
      "resources/js/Pages/Users/Partials/UpdateProfileInformationForm.jsx",
      "resources/js/Pages/Welcome.jsx"
    ],
    file: "assets/app-e583e225.js",
    isEntry: true,
    src: "resources/js/app.jsx"
  }
};
export {
  manifest as m
};
