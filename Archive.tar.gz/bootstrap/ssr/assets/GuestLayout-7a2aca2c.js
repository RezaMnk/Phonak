import { j as jsxs, a as jsx } from "../ssr.js";
import { A as ApplicationLogo } from "./ApplicationLogo-40648ed6.js";
import { Link } from "@inertiajs/react";
import { u as useMemorable } from "./useMemorable-ea291d99.js";
import { useEffect } from "react";
function Guest({ children, name = "", className = "" }) {
  const [dark] = useMemorable(false, "dark");
  useEffect(() => {
    if (dark) {
      document.body.classList.add("dark");
    } else {
      document.body.classList.remove("dark");
    }
  }, [dark]);
  return /* @__PURE__ */ jsxs("div", { className: "min-h-screen flex flex-col p-5 justify-center items-center xl:py-12 sm:py-0 bg-gray-100/50 dark:bg-slate-700/95", children: [
    /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(Link, { href: "/", children: /* @__PURE__ */ jsx(ApplicationLogo, { className: "h-28", dark }) }) }),
    /* @__PURE__ */ jsxs("div", { className: `w-full sm:max-w-xl mt-6 px-6 py-4 bg-white dark:bg-slate-800 overflow-hidden rounded-lg ` + className, children: [
      name && /* @__PURE__ */ jsxs("div", { className: "mb-5 flex items-center", children: [
        /* @__PURE__ */ jsx("div", { className: "flex-grow h-px bg-gray-400 dark:bg-slate-600" }),
        /* @__PURE__ */ jsx("h3", { className: "px-5 text-lg font-semibold text-center text-gray-700 dark:text-slate-300", children: name }),
        /* @__PURE__ */ jsx("div", { className: "flex-grow h-px bg-gray-400 dark:bg-slate-600" })
      ] }),
      children
    ] })
  ] });
}
export {
  Guest as G
};
