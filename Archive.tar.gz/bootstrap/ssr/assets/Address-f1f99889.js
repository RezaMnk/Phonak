import { j as jsxs, a as jsx } from "../ssr.js";
import { G as Guest } from "./GuestLayout-ceec5b24.js";
import { I as InputError } from "./InputError-0c916dba.js";
import { P as PrimaryButton } from "./PrimaryButton-6a55fe23.js";
import { T as TextInput } from "./TextInput-ca1f9780.js";
import { useForm, Head } from "@inertiajs/react";
import { T as TextAreaInput } from "./TextAreaInput-7c309df0.js";
import { R as RadioInput } from "./RadioInput-a6c65c03.js";
import { I as InputLabel } from "./InputLabel-b9d20af6.js";
import { I as Icon } from "./Icon-2f3a2698.js";
import { useState, useEffect } from "react";
import { D as DangerButton } from "./DangerButton-d6ee3472.js";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "./ApplicationLogo-40648ed6.js";
import "./useMemorable-ea291d99.js";
function Address() {
  const { data, setData, post, reset, processing, errors } = useForm({
    mail_address: "work",
    home_post_code: "",
    home_phone: "",
    home_address: "",
    work_post_code: "",
    work_phone: "",
    work_address: "",
    second_work_post_code: "",
    second_work_phone: "",
    second_work_address: "",
    has_second: false
  });
  const [hasSecondAddress, setHasSecondAddress] = useState(false);
  const [showAddAddressBtn, setShowAddAddressBtn] = useState(true);
  useEffect(() => {
    if (hasSecondAddress)
      setShowAddAddressBtn(false);
    else {
      setTimeout(() => {
        setShowAddAddressBtn(true);
      }, 550);
      reset("second_work_post_code", "second_work_phone", "second_work_address", "mail_address");
    }
  }, [hasSecondAddress]);
  const submit = (e) => {
    e.preventDefault();
    post(route("addresses"));
  };
  return /* @__PURE__ */ jsxs(Guest, { className: "!max-w-3xl", name: "آدرس ها", children: [
    /* @__PURE__ */ jsx(Head, { title: "آدرس ها" }),
    /* @__PURE__ */ jsxs("form", { className: "w-full max-w-3xl h-1/2", onSubmit: submit, children: [
      /* @__PURE__ */ jsxs("div", { className: "text-gray-700 dark:text-slate-200", children: [
        /* @__PURE__ */ jsx("h5", { children: "مشخصات محل اقامت" }),
        /* @__PURE__ */ jsx("hr", { className: "border-gray-300 dark:border-slate-600" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-3", children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/2 ml-5", children: [
          /* @__PURE__ */ jsxs("div", { className: "mb-5", children: [
            /* @__PURE__ */ jsx(
              TextInput,
              {
                id: "home_post_code",
                name: "home_post_code",
                value: data.home_post_code,
                label: "کد پستی منزل",
                svgIcon: /* @__PURE__ */ jsxs("g", { children: [
                  /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M10 3L8 21" }),
                  /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M16 3L14 21" }),
                  /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M3.5 9H21.5" }),
                  /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M2.5 15H20.5" })
                ] }),
                autoComplete: "home_post_code",
                isFocused: true,
                onChange: (e) => setData("home_post_code", e.target.value),
                error: errors.home_post_code
              }
            ),
            /* @__PURE__ */ jsx(InputError, { message: errors.home_post_code, className: "mt-2" })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(
              TextInput,
              {
                id: "home_phone",
                type: "number",
                name: "home_phone",
                label: "تلفن منزل (با کد شهر)",
                value: data.home_phone,
                svgIcon: /* @__PURE__ */ jsx(
                  "path",
                  {
                    d: "M20.9995 19.1864V16.4767C21.0105 16.0337 20.858 15.6021 20.5709 15.264C19.7615 14.3106 16.9855 13.7008 15.8851 13.935C15.0274 14.1176 14.4272 14.9788 13.8405 15.5644C11.5747 14.2785 9.69864 12.4062 8.41026 10.1448C8.99696 9.55929 9.85994 8.96036 10.0429 8.10428C10.2772 7.00777 9.66819 4.24949 8.72138 3.43684C8.38835 3.151 7.96253 2.99577 7.52331 3.00009H4.80817C3.77364 3.00106 2.91294 3.92895 3.00713 4.96919C3.00006 13.935 10.0001 21 19.0265 20.9929C20.0723 21.0873 21.0037 20.2223 20.9995 19.1864Z",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                  }
                ),
                onChange: (e) => setData("home_phone", e.target.value),
                error: errors.home_phone
              }
            ),
            /* @__PURE__ */ jsx(InputError, { message: errors.home_phone, className: "mt-2" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/2", children: [
          /* @__PURE__ */ jsx(
            TextAreaInput,
            {
              id: "home_address",
              name: "home_address",
              value: data.home_address,
              rows: "4",
              label: "آدرس منزل",
              svgIcon: /* @__PURE__ */ jsx(
                "path",
                {
                  d: "M3.99999 10L12 3L20 10L20 20H15V16C15 15.2044 14.6839 14.4413 14.1213 13.8787C13.5587 13.3161 12.7956 13 12 13C11.2043 13 10.4413 13.3161 9.87868 13.8787C9.31607 14.4413 9 15.2043 9 16V20H4L3.99999 10Z",
                  strokeLinecap: "round",
                  strokeLinejoin: "round"
                }
              ),
              onChange: (e) => setData("home_address", e.target.value),
              error: errors.home_address
            }
          ),
          /* @__PURE__ */ jsx(InputError, { message: errors.home_address, className: "mt-2" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mt-8 text-gray-700 dark:text-slate-200", children: [
        /* @__PURE__ */ jsx("h5", { children: "مشخصات محل کار" }),
        /* @__PURE__ */ jsx("hr", { className: "border-gray-300 dark:border-slate-600" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-3", children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/2 ml-5", children: [
          /* @__PURE__ */ jsxs("div", { className: "mb-5", children: [
            /* @__PURE__ */ jsx(
              TextInput,
              {
                id: "work_post_code",
                name: "work_post_code",
                value: data.work_post_code,
                label: "کد پستی محل کار",
                svgIcon: /* @__PURE__ */ jsxs("g", { children: [
                  /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M10 3L8 21" }),
                  /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M16 3L14 21" }),
                  /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M3.5 9H21.5" }),
                  /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M2.5 15H20.5" })
                ] }),
                autoComplete: "work_post_code",
                onChange: (e) => setData("work_post_code", e.target.value),
                error: errors.work_post_code
              }
            ),
            /* @__PURE__ */ jsx(InputError, { message: errors.work_post_code, className: "mt-2" })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(
              TextInput,
              {
                id: "work_phone",
                type: "number",
                name: "work_phone",
                label: "تلفن محل کار",
                value: data.work_phone,
                svgIcon: /* @__PURE__ */ jsx(
                  "path",
                  {
                    d: "M20.9995 19.1864V16.4767C21.0105 16.0337 20.858 15.6021 20.5709 15.264C19.7615 14.3106 16.9855 13.7008 15.8851 13.935C15.0274 14.1176 14.4272 14.9788 13.8405 15.5644C11.5747 14.2785 9.69864 12.4062 8.41026 10.1448C8.99696 9.55929 9.85994 8.96036 10.0429 8.10428C10.2772 7.00777 9.66819 4.24949 8.72138 3.43684C8.38835 3.151 7.96253 2.99577 7.52331 3.00009H4.80817C3.77364 3.00106 2.91294 3.92895 3.00713 4.96919C3.00006 13.935 10.0001 21 19.0265 20.9929C20.0723 21.0873 21.0037 20.2223 20.9995 19.1864Z",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                  }
                ),
                onChange: (e) => setData("work_phone", e.target.value),
                error: errors.work_phone
              }
            ),
            /* @__PURE__ */ jsx(InputError, { message: errors.work_phone, className: "mt-2" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/2", children: [
          /* @__PURE__ */ jsx(
            TextAreaInput,
            {
              id: "work_address",
              name: "work_address",
              value: data.work_address,
              rows: "4",
              label: "آدرس محل کار",
              svgIcon: /* @__PURE__ */ jsx(
                "path",
                {
                  d: "M3.99999 10L12 3L20 10L20 20H15V16C15 15.2044 14.6839 14.4413 14.1213 13.8787C13.5587 13.3161 12.7956 13 12 13C11.2043 13 10.4413 13.3161 9.87868 13.8787C9.31607 14.4413 9 15.2043 9 16V20H4L3.99999 10Z",
                  strokeLinecap: "round",
                  strokeLinejoin: "round"
                }
              ),
              onChange: (e) => setData("work_address", e.target.value),
              error: errors.work_address
            }
          ),
          /* @__PURE__ */ jsx(InputError, { message: errors.work_address, className: "mt-2" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col mt-8", children: [
        showAddAddressBtn && /* @__PURE__ */ jsxs(
          "button",
          {
            type: "button",
            className: "w-full text-center text-sm font-semibold bg-sky-500/40 dark:bg-sky-700/60 text-gray-800 dark:text-white rounded-lg py-2",
            onClick: () => {
              setHasSecondAddress(true);
              setData("has_second", true);
            },
            children: [
              /* @__PURE__ */ jsx(Icon, { viewBox: "0 0 24 24", width: "3", type: "stroke", className: "inline-block ml-2 text-gray-800 dark:text-white", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M12 6v12m6-6H6" }) }),
              /* @__PURE__ */ jsx("span", { children: "افزون آدرس محل کار" })
            ]
          }
        ),
        /* @__PURE__ */ jsx("div", { className: `transition-all ease-in-out duration-500 ${hasSecondAddress ? "max-h-96" : "max-h-0"} overflow-hidden`, children: /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between text-gray-700 dark:text-slate-200", children: [
            /* @__PURE__ */ jsx("h5", { className: "inline-block", children: "مشخصات محل کار دوم" }),
            /* @__PURE__ */ jsx(
              DangerButton,
              {
                className: "mb-1 text-xs !px-2 !py-1",
                onClick: () => {
                  setHasSecondAddress(false);
                  setData("has_second", false);
                },
                type: "button",
                children: "حذف"
              }
            )
          ] }),
          /* @__PURE__ */ jsx("hr", { className: "w-full mt-1 border-gray-300 dark:border-slate-600" }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-3", children: [
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/2 ml-5", children: [
              /* @__PURE__ */ jsxs("div", { className: "mb-5", children: [
                /* @__PURE__ */ jsx(
                  TextInput,
                  {
                    id: "second_work_post_code",
                    name: "second_work_post_code",
                    value: data.second_work_post_code,
                    label: "کد پستی محل کار دوم",
                    svgIcon: /* @__PURE__ */ jsxs("g", { children: [
                      /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M10 3L8 21" }),
                      /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M16 3L14 21" }),
                      /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M3.5 9H21.5" }),
                      /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M2.5 15H20.5" })
                    ] }),
                    autoComplete: "second_work_post_code",
                    onChange: (e) => setData("second_work_post_code", e.target.value),
                    error: errors.second_work_post_code,
                    required: hasSecondAddress
                  }
                ),
                /* @__PURE__ */ jsx(InputError, { message: errors.second_work_post_code, className: "mt-2" })
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx(
                  TextInput,
                  {
                    id: "second_work_phone",
                    type: "number",
                    name: "second_work_phone",
                    label: "تلفن محل کار دوم",
                    value: data.second_work_phone,
                    svgIcon: /* @__PURE__ */ jsx(
                      "path",
                      {
                        d: "M20.9995 19.1864V16.4767C21.0105 16.0337 20.858 15.6021 20.5709 15.264C19.7615 14.3106 16.9855 13.7008 15.8851 13.935C15.0274 14.1176 14.4272 14.9788 13.8405 15.5644C11.5747 14.2785 9.69864 12.4062 8.41026 10.1448C8.99696 9.55929 9.85994 8.96036 10.0429 8.10428C10.2772 7.00777 9.66819 4.24949 8.72138 3.43684C8.38835 3.151 7.96253 2.99577 7.52331 3.00009H4.80817C3.77364 3.00106 2.91294 3.92895 3.00713 4.96919C3.00006 13.935 10.0001 21 19.0265 20.9929C20.0723 21.0873 21.0037 20.2223 20.9995 19.1864Z",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                      }
                    ),
                    onChange: (e) => setData("second_work_phone", e.target.value),
                    error: errors.second_work_phone,
                    required: hasSecondAddress
                  }
                ),
                /* @__PURE__ */ jsx(InputError, { message: errors.second_work_phone, className: "mt-2" })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/2", children: [
              /* @__PURE__ */ jsx(
                TextAreaInput,
                {
                  id: "second_work_address",
                  name: "second_work_address",
                  value: data.second_work_address,
                  rows: "4",
                  label: "آدرس محل کار دوم",
                  svgIcon: /* @__PURE__ */ jsx(
                    "path",
                    {
                      d: "M3.99999 10L12 3L20 10L20 20H15V16C15 15.2044 14.6839 14.4413 14.1213 13.8787C13.5587 13.3161 12.7956 13 12 13C11.2043 13 10.4413 13.3161 9.87868 13.8787C9.31607 14.4413 9 15.2043 9 16V20H4L3.99999 10Z",
                      strokeLinecap: "round",
                      strokeLinejoin: "round"
                    }
                  ),
                  onChange: (e) => setData("second_work_address", e.target.value),
                  error: errors.second_work_address,
                  required: hasSecondAddress
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.second_work_address, className: "mt-2" })
            ] })
          ] })
        ] }) })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "flex mt-8", children: /* @__PURE__ */ jsxs("div", { className: "w-full ml-5 text-gray-700 dark:text-slate-200", children: [
        /* @__PURE__ */ jsx("p", { children: "مرسولات شما به کدام آدرس ارسال شوند؟" }),
        /* @__PURE__ */ jsx(InputError, { message: errors.mail_address, className: "mt-2" }),
        /* @__PURE__ */ jsxs("div", { className: "mb-5 mt-2", children: [
          /* @__PURE__ */ jsxs("div", { className: "inline-block ml-8", children: [
            /* @__PURE__ */ jsx(
              RadioInput,
              {
                id: "mail_address_work",
                name: "mail_address",
                checked: data.mail_address === "work",
                onChange: () => setData("mail_address", "work")
              }
            ),
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                htmlFor: "mail_address_work",
                value: "محل کار",
                className: "mr-2"
              }
            )
          ] }),
          hasSecondAddress && /* @__PURE__ */ jsxs("div", { className: "inline-block ml-8", children: [
            /* @__PURE__ */ jsx(
              RadioInput,
              {
                id: "second_mail_address_work",
                name: "mail_address",
                checked: data.mail_address === "second_work",
                onChange: () => setData("mail_address", "second_work")
              }
            ),
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                htmlFor: "second_mail_address_work",
                value: "محل کار دوم",
                className: "mr-2"
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "inline-block", children: [
            /* @__PURE__ */ jsx(
              RadioInput,
              {
                id: "mail_address_home",
                name: "mail_address",
                checked: data.mail_address === "home",
                onChange: () => setData("mail_address", "home")
              }
            ),
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                htmlFor: "mail_address_home",
                value: "محل اقامت",
                className: "mr-2"
              }
            )
          ] })
        ] })
      ] }) }),
      /* @__PURE__ */ jsx("div", { className: "mt-6", children: /* @__PURE__ */ jsx(PrimaryButton, { className: "w-full", disabled: processing, children: "ثبت آدرس" }) })
    ] })
  ] });
}
export {
  Address as default
};
