import { j as jsxs, a as jsx, F as Fragment } from "../ssr.js";
import { A as Authenticated } from "./AuthenticatedLayout-0977ce1d.js";
import { Head } from "@inertiajs/react";
import { W as WarningButton } from "./WarningButton-ea0dcf3d.js";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "react-toastify";
import "./useMemorable-ea291d99.js";
import "react";
import "./ApplicationLogo-40648ed6.js";
import "./Icon-2f3a2698.js";
function Edit({ user }) {
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      header: /* @__PURE__ */ jsx(Fragment, { children: "ویرایش پروفایل" }),
      breadcrumbs: {
        "پروفایل": route("dashboard"),
        "ویرایش": "#"
      },
      headerExtra: /* @__PURE__ */ jsx(
        WarningButton,
        {
          link: true,
          href: route("profile.edit"),
          className: "!px-4 !py-2 text-xs",
          children: "ویرایش پروفایل"
        }
      ),
      children: [
        /* @__PURE__ */ jsx(Head, { title: "ویرایش پروفایل" }),
        /* @__PURE__ */ jsx("div", { className: "flex flex-col sm:justify-center items-center", children: /* @__PURE__ */ jsx("div", { className: "w-full px-6 py-4 bg-white dark:bg-slate-800 border border-white dark:border-slate-600 sm:rounded-lg", children: /* @__PURE__ */ jsxs("div", { className: "w-full text-gray-700 dark:text-slate-200", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("h5", { children: "اطلاعات فردی" }),
            /* @__PURE__ */ jsx("hr", { className: "dark:border-slate-600" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-6", children: [
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/5 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
              /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
                /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-sky-400 dark:bg-sky-600" }),
                "نام و نام خانوادگی"
              ] }),
              /* @__PURE__ */ jsx("p", { className: "mt-2", children: user.name })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/5 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
              /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
                /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-sky-400 dark:bg-sky-600" }),
                "کد ملی"
              ] }),
              /* @__PURE__ */ jsx("p", { className: "mt-2", children: user.national_code })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/5 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
              /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
                /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-sky-400 dark:bg-sky-600" }),
                "شماره نظام پزشکی"
              ] }),
              /* @__PURE__ */ jsx("p", { className: "mt-2", children: user.med_number })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/5 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
              /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
                /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-sky-400 dark:bg-sky-600" }),
                "سال فارغ التحصیلی"
              ] }),
              /* @__PURE__ */ jsx("p", { className: "mt-2", children: user.grad_year ? user.grad_year : "تعریف نشده!" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/5 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3", children: [
              /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
                /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-sky-400 dark:bg-sky-600" }),
                "دانشگاه فارغ التحصیلی"
              ] }),
              /* @__PURE__ */ jsx("p", { className: "mt-2", children: user.university ? user.university : "تعریف نشده!" })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-5 xl:mt-8", children: [
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/5 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
              /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
                /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-sky-400 dark:bg-sky-600" }),
                "ایمیل"
              ] }),
              /* @__PURE__ */ jsx("p", { className: "mt-2", children: user.email ? user.email : "تعریف نشده!" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/5 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
              /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
                /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-sky-400 dark:bg-sky-600" }),
                "استان محل اقامت"
              ] }),
              /* @__PURE__ */ jsx("p", { className: "mt-2", children: user.state ? user.state : "تعریف نشده!" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/5 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3", children: [
              /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
                /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-sky-400 dark:bg-sky-600" }),
                "شهر محل اقامت"
              ] }),
              /* @__PURE__ */ jsx("p", { className: "mt-2", children: user.city ? user.city : "تعریف نشده!" })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "mt-12", children: [
            /* @__PURE__ */ jsx("h5", { children: "آدرس های همکار" }),
            /* @__PURE__ */ jsx("hr", { className: "dark:border-slate-600" })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "flex mt-6", children: /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3", children: [
            /* @__PURE__ */ jsx("p", { className: "text-xs flex flex-col xl:flex-row space-y-5 xl:space-y-0 items-start xl:items-center", children: /* @__PURE__ */ jsxs("span", { className: "flex items-center", children: [
              /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-sky-400 dark:bg-sky-600" }),
              "محل سکونت",
              user.address.mail_address === "home" && /* @__PURE__ */ jsx("span", { className: "font-semibold mr-2 pr-2 border-r border-gray-300 dark:border-slate-600", children: "محل ارسال محصولات پستی" })
            ] }) }),
            /* @__PURE__ */ jsxs("p", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-5 xl:mt-2", children: [
              /* @__PURE__ */ jsx("span", { className: "inline-block", children: user.address.home_address }),
              /* @__PURE__ */ jsxs("span", { className: "inline-block xl:mr-5 xl:pr-5 xl:border-r border-gray-300 dark:border-slate-600", children: [
                "کدپستی: ",
                user.address.home_post_code
              ] }),
              user.address.home_phone && /* @__PURE__ */ jsxs(
                "span",
                {
                  className: "inline-block xl:mr-5 xl:pr-5 xl:border-r border-gray-300 dark:border-slate-600",
                  children: [
                    "تلفن: ",
                    user.address.home_phone
                  ]
                }
              )
            ] })
          ] }) }),
          /* @__PURE__ */ jsx("div", { className: "flex mt-8", children: /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3", children: [
            /* @__PURE__ */ jsx("p", { className: "text-xs flex flex-col xl:flex-row space-y-5 xl:space-y-0 items-start xl:items-center", children: /* @__PURE__ */ jsxs("span", { className: "flex items-center", children: [
              /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-sky-400 dark:bg-sky-600" }),
              "محل کار",
              user.address.mail_address === "work" && /* @__PURE__ */ jsx("span", { className: "font-semibold mr-2 pr-2 border-r border-gray-300 dark:border-slate-600", children: "محل ارسال محصولات پستی" })
            ] }) }),
            /* @__PURE__ */ jsxs("p", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-5 xl:mt-2", children: [
              /* @__PURE__ */ jsx("span", { className: "inline-block", children: user.address.work_address }),
              /* @__PURE__ */ jsxs("span", { className: "inline-block xl:mr-5 xl:pr-5 xl:border-r border-gray-300 dark:border-slate-600", children: [
                "کدپستی: ",
                user.address.work_post_code
              ] }),
              user.address.work_phone && /* @__PURE__ */ jsxs(
                "span",
                {
                  className: "inline-block xl:mr-5 xl:pr-5 xl:border-r border-gray-300 dark:border-slate-600",
                  children: [
                    "تلفن: ",
                    user.address.work_phone
                  ]
                }
              )
            ] })
          ] }) }),
          user.address.second_work_address && /* @__PURE__ */ jsx("div", { className: "flex mt-8", children: /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3", children: [
            /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
              /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-sky-400 dark:bg-sky-600" }),
              "محل کار دوم",
              user.address.mail_address === "second_work" && /* @__PURE__ */ jsx("span", { className: "mr-2 pr-2 border-r border-gray-300 dark:border-slate-600", children: "محل ارسال محصولات پستی" })
            ] }),
            /* @__PURE__ */ jsxs("p", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-5 xl:mt-2", children: [
              /* @__PURE__ */ jsx("span", { className: "inline-block", children: user.address.second_work_address }),
              /* @__PURE__ */ jsxs("span", { className: "inline-block xl:mr-5 xl:pr-5 xl:border-r border-gray-300 dark:border-slate-600", children: [
                "کدپستی: ",
                user.address.second_work_post_code
              ] }),
              user.address.second_work_phone && /* @__PURE__ */ jsxs(
                "span",
                {
                  className: "inline-block xl:mr-5 xl:pr-5 xl:border-r border-gray-300 dark:border-slate-600",
                  children: [
                    "تلفن: ",
                    user.address.second_work_phone
                  ]
                }
              )
            ] })
          ] }) }),
          /* @__PURE__ */ jsxs("div", { className: "mt-12", children: [
            /* @__PURE__ */ jsx("h5", { children: "اطلاعات تکمیلی" }),
            /* @__PURE__ */ jsx("hr", { className: "dark:border-slate-600" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-6", children: [
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
              /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
                /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-sky-400 dark:bg-sky-600" }),
                "شماره تلفن همراه"
              ] }),
              /* @__PURE__ */ jsx("p", { className: "mt-2", children: user.info.phone })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
              /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
                /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-sky-400 dark:bg-sky-600" }),
                "شماره تلفن ثابت"
              ] }),
              /* @__PURE__ */ jsx("p", { className: "mt-2", children: user.info.landline ? user.info.landline : "تعریف نشده!" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3", children: [
              /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
                /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-sky-400 dark:bg-sky-600" }),
                "شماره تلفن واتساپ"
              ] }),
              /* @__PURE__ */ jsx("p", { className: "mt-2", children: user.info.whatsapp_phone })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-5 xl:mt-8", children: [
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
              /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
                /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-sky-400 dark:bg-sky-600" }),
                "نام معرف اول"
              ] }),
              /* @__PURE__ */ jsx("p", { className: "mt-2", children: user.info.referral_name ? user.info.referral_name : "تعریف نشده!" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
              /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
                /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-sky-400 dark:bg-sky-600" }),
                "شماره تلفن معرف اول"
              ] }),
              /* @__PURE__ */ jsx("p", { className: "mt-2", children: user.info.referral_phone ? user.info.referral_phone : "تعریف نشده!" })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "hidden xl:block w-fit p-2 mx-2 border-r border-gray-200 dark:border-slate-700" }),
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
              /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
                /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-sky-400 dark:bg-sky-600" }),
                "نام معرف دوم"
              ] }),
              /* @__PURE__ */ jsx("p", { className: "mt-2", children: user.info.second_referral_name ? user.info.second_referral_name : "تعریف نشده!" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3", children: [
              /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
                /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-sky-400 dark:bg-sky-600" }),
                "شماره تلفن معرف دوم"
              ] }),
              /* @__PURE__ */ jsx("p", { className: "mt-2", children: user.info.second_referral_phone ? user.info.second_referral_phone : "تعریف نشده!" })
            ] })
          ] }),
          user.info.history_description && /* @__PURE__ */ jsx("div", { className: "flex mt-6", children: /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3", children: [
            /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
              /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-sky-400 dark:bg-sky-600" }),
              "توضیحات سابقه همکاری با فوناک"
            ] }),
            /* @__PURE__ */ jsx("p", { className: "mt-2", children: user.info.history_description ? user.info.history_description : "تعریف نشده!" })
          ] }) }),
          user.info.conditions_description && /* @__PURE__ */ jsx("div", { className: "flex mt-6", children: /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3", children: [
            /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
              /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-sky-400 dark:bg-sky-600" }),
              "توضیحات شرایط خاصی مرکز"
            ] }),
            /* @__PURE__ */ jsx("p", { className: "mt-2", children: user.info.conditions_description ? user.info.conditions_description : "تعریف نشده!" })
          ] }) }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-6", children: [
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-12", children: [
              /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
                /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-sky-400 dark:bg-sky-600" }),
                "تصویر کارت ملی"
              ] }),
              user.info.id_card_image ? /* @__PURE__ */ jsx("a", { href: user.info.id_card_image_url, target: "_blank", className: "mt-2", children: /* @__PURE__ */ jsx("div", { className: "w-full p-2 rounded-lg bg-gray-100 dark:bg-slate-700", children: /* @__PURE__ */ jsx("img", { src: user.info.id_card_image_url, alt: "تصویر کارت ملی" }) }) }) : /* @__PURE__ */ jsx("p", { className: "mt-2", children: "تعریف نشده!" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-12", children: [
              /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
                /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-sky-400 dark:bg-sky-600" }),
                "تصویر کارت نظام پزشکی"
              ] }),
              user.info.med_card_image ? /* @__PURE__ */ jsx("a", { href: user.info.med_card_image_url, target: "_blank", className: "mt-2", children: /* @__PURE__ */ jsx("div", { className: "w-full p-2 rounded-lg bg-gray-100 dark:bg-slate-700", children: /* @__PURE__ */ jsx("img", { src: user.info.med_card_image_url, alt: "تصویر کارت ملی" }) }) }) : /* @__PURE__ */ jsx("p", { className: "mt-2", children: "تعریف نشده!" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3", children: [
              /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
                /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-sky-400 dark:bg-sky-600" }),
                "تصویر مجوز فعالیت"
              ] }),
              user.info.license_image ? /* @__PURE__ */ jsx("a", { href: user.info.license_image_url, target: "_blank", className: "mt-2", children: /* @__PURE__ */ jsx("div", { className: "w-full p-2 rounded-lg bg-gray-100 dark:bg-slate-700", children: /* @__PURE__ */ jsx("img", { src: user.info.license_image_url, alt: "تصویر کارت ملی" }) }) }) : /* @__PURE__ */ jsx("p", { className: "mt-2", children: "تعریف نشده!" })
            ] })
          ] })
        ] }) }) })
      ]
    }
  );
}
export {
  Edit as default
};
