const manifest = {
  "AuthenticatedLayout.css": {
    file: "assets/AuthenticatedLayout-b7bb1ac5.css",
    src: "AuthenticatedLayout.css"
  },
  "_AidInputs-7d83a21d.js": {
    file: "assets/AidInputs-7d83a21d.js",
    imports: [
      "resources/js/app.jsx",
      "_SelectInput-a4bcb65f.js",
      "_InputError-d819808c.js",
      "_PrimaryButton-15e1f725.js",
      "_DangerButton-76ab6699.js",
      "_AuthenticatedLayout-91f361bd.js",
      "resources/js/Pages/Records/Components/Steps.jsx",
      "_TextInput-eb1932a1.js",
      "_TextAreaInput-3915a84d.js",
      "_IranStatesOptions-06764a25.js",
      "_FileInput-2e9e4949.js",
      "_RadioInput-5e9441ef.js",
      "_InputLabel-0000cb07.js",
      "resources/js/Pages/Records/Components/ProductsSlider.jsx",
      "_useFirstRender-4c1fa5a4.js",
      "_CheckboxInput-62e99544.js",
      "_Icon-fbdb9045.js"
    ],
    isDynamicEntry: true
  },
  "_ApplicationLogo-0a6ae78f.js": {
    file: "assets/ApplicationLogo-0a6ae78f.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_ArrowLink-613cb697.js": {
    file: "assets/ArrowLink-613cb697.js",
    imports: [
      "resources/js/app.jsx",
      "__commonjs-dynamic-modules-302442b1.js"
    ]
  },
  "_AuthenticatedLayout-91f361bd.js": {
    css: [
      "assets/AuthenticatedLayout-b7bb1ac5.css"
    ],
    file: "assets/AuthenticatedLayout-91f361bd.js",
    imports: [
      "resources/js/app.jsx",
      "_useMemorable-4c077465.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_Icon-fbdb9045.js"
    ]
  },
  "_CheckboxInput-62e99544.js": {
    file: "assets/CheckboxInput-62e99544.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_Create-2d1cd55c.js": {
    file: "assets/Create-2d1cd55c.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-91f361bd.js",
      "_TextInput-eb1932a1.js",
      "_InputError-d819808c.js",
      "_TextAreaInput-3915a84d.js",
      "_PrimaryButton-15e1f725.js",
      "_SelectInput-a4bcb65f.js",
      "_RadioInput-5e9441ef.js",
      "_InputLabel-0000cb07.js",
      "resources/js/Pages/Accessories/Components/ProductsSlider.jsx",
      "_DangerButton-76ab6699.js",
      "_Icon-fbdb9045.js"
    ],
    isDynamicEntry: true
  },
  "_DangerButton-76ab6699.js": {
    file: "assets/DangerButton-76ab6699.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_FileInput-2e9e4949.js": {
    file: "assets/FileInput-2e9e4949.js",
    imports: [
      "resources/js/app.jsx",
      "_Icon-fbdb9045.js",
      "_PrimaryButton-15e1f725.js"
    ]
  },
  "_GuestLayout-eed184ad.js": {
    file: "assets/GuestLayout-eed184ad.js",
    imports: [
      "resources/js/app.jsx",
      "_ApplicationLogo-0a6ae78f.js",
      "_useMemorable-4c077465.js"
    ]
  },
  "_Icon-fbdb9045.js": {
    file: "assets/Icon-fbdb9045.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_InputError-d819808c.js": {
    file: "assets/InputError-d819808c.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_InputLabel-0000cb07.js": {
    file: "assets/InputLabel-0000cb07.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_IranStatesOptions-06764a25.js": {
    file: "assets/IranStatesOptions-06764a25.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_Modal-5409478e.js": {
    file: "assets/Modal-5409478e.js",
    imports: [
      "resources/js/app.jsx",
      "_transition-70017498.js"
    ]
  },
  "_Pagination-fafa5d58.js": {
    file: "assets/Pagination-fafa5d58.js",
    imports: [
      "resources/js/app.jsx",
      "_useFirstRender-4c1fa5a4.js"
    ]
  },
  "_PrimaryButton-15e1f725.js": {
    file: "assets/PrimaryButton-15e1f725.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_RadioInput-5e9441ef.js": {
    file: "assets/RadioInput-5e9441ef.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_SecondaryButton-0597d2b2.js": {
    file: "assets/SecondaryButton-0597d2b2.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_SelectInput-a4bcb65f.js": {
    file: "assets/SelectInput-a4bcb65f.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_TextAreaInput-3915a84d.js": {
    file: "assets/TextAreaInput-3915a84d.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_TextInput-eb1932a1.js": {
    file: "assets/TextInput-eb1932a1.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_WarningButton-84602cc5.js": {
    file: "assets/WarningButton-84602cc5.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "__commonjs-dynamic-modules-302442b1.js": {
    file: "assets/_commonjs-dynamic-modules-302442b1.js"
  },
  "_index-4e3bb690.js": {
    file: "assets/index-4e3bb690.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_lottie-react.esm-fab63579.js": {
    file: "assets/lottie-react.esm-fab63579.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_manifest-2a57ceab.js": {
    file: "assets/manifest-2a57ceab.js"
  },
  "_pagination-f0cee491.js": {
    css: [
      "assets/pagination-211b41b8.css"
    ],
    file: "assets/pagination-f0cee491.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_transition-70017498.js": {
    file: "assets/transition-70017498.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_useFirstRender-4c1fa5a4.js": {
    file: "assets/useFirstRender-4c1fa5a4.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_useMemorable-4c077465.js": {
    file: "assets/useMemorable-4c077465.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "pagination.css": {
    file: "assets/pagination-211b41b8.css",
    src: "pagination.css"
  },
  "resources/fonts/woff/Dana-Black.woff": {
    file: "assets/Dana-Black-575de1e5.woff",
    src: "resources/fonts/woff/Dana-Black.woff"
  },
  "resources/fonts/woff/Dana-DemiBold.woff": {
    file: "assets/Dana-DemiBold-fa427dcf.woff",
    src: "resources/fonts/woff/Dana-DemiBold.woff"
  },
  "resources/fonts/woff/Dana-ExtraBlack.woff": {
    file: "assets/Dana-ExtraBlack-6c729c23.woff",
    src: "resources/fonts/woff/Dana-ExtraBlack.woff"
  },
  "resources/fonts/woff/Dana-ExtraBold.woff": {
    file: "assets/Dana-ExtraBold-0d7888d7.woff",
    src: "resources/fonts/woff/Dana-ExtraBold.woff"
  },
  "resources/fonts/woff/Dana-Fat.woff": {
    file: "assets/Dana-Fat-8831a7f0.woff",
    src: "resources/fonts/woff/Dana-Fat.woff"
  },
  "resources/fonts/woff/Dana-Hairline.woff": {
    file: "assets/Dana-Hairline-6d7bb084.woff",
    src: "resources/fonts/woff/Dana-Hairline.woff"
  },
  "resources/fonts/woff/Dana-Heavy.woff": {
    file: "assets/Dana-Heavy-e159608a.woff",
    src: "resources/fonts/woff/Dana-Heavy.woff"
  },
  "resources/fonts/woff/Dana-Light.woff": {
    file: "assets/Dana-Light-eeed4155.woff",
    src: "resources/fonts/woff/Dana-Light.woff"
  },
  "resources/fonts/woff/Dana-Medium.woff": {
    file: "assets/Dana-Medium-d0241b30.woff",
    src: "resources/fonts/woff/Dana-Medium.woff"
  },
  "resources/fonts/woff/Dana-Regular.woff": {
    file: "assets/Dana-Regular-eee25c04.woff",
    src: "resources/fonts/woff/Dana-Regular.woff"
  },
  "resources/fonts/woff/Dana-Thin.woff": {
    file: "assets/Dana-Thin-56dc1e1f.woff",
    src: "resources/fonts/woff/Dana-Thin.woff"
  },
  "resources/fonts/woff/Dana-UltraLight.woff": {
    file: "assets/Dana-UltraLight-a025f30e.woff",
    src: "resources/fonts/woff/Dana-UltraLight.woff"
  },
  "resources/fonts/woff2/Dana-Black.woff2": {
    file: "assets/Dana-Black-cdfe2203.woff2",
    src: "resources/fonts/woff2/Dana-Black.woff2"
  },
  "resources/fonts/woff2/Dana-DemiBold.woff2": {
    file: "assets/Dana-DemiBold-34870445.woff2",
    src: "resources/fonts/woff2/Dana-DemiBold.woff2"
  },
  "resources/fonts/woff2/Dana-ExtraBlack.woff2": {
    file: "assets/Dana-ExtraBlack-3208afe0.woff2",
    src: "resources/fonts/woff2/Dana-ExtraBlack.woff2"
  },
  "resources/fonts/woff2/Dana-ExtraBold.woff2": {
    file: "assets/Dana-ExtraBold-08dea612.woff2",
    src: "resources/fonts/woff2/Dana-ExtraBold.woff2"
  },
  "resources/fonts/woff2/Dana-Fat.woff2": {
    file: "assets/Dana-Fat-1f7b7061.woff2",
    src: "resources/fonts/woff2/Dana-Fat.woff2"
  },
  "resources/fonts/woff2/Dana-Hairline.woff2": {
    file: "assets/Dana-Hairline-7712cf11.woff2",
    src: "resources/fonts/woff2/Dana-Hairline.woff2"
  },
  "resources/fonts/woff2/Dana-Heavy.woff2": {
    file: "assets/Dana-Heavy-091eb261.woff2",
    src: "resources/fonts/woff2/Dana-Heavy.woff2"
  },
  "resources/fonts/woff2/Dana-Light.woff2": {
    file: "assets/Dana-Light-e07a4868.woff2",
    src: "resources/fonts/woff2/Dana-Light.woff2"
  },
  "resources/fonts/woff2/Dana-Medium.woff2": {
    file: "assets/Dana-Medium-d623f857.woff2",
    src: "resources/fonts/woff2/Dana-Medium.woff2"
  },
  "resources/fonts/woff2/Dana-Regular.woff2": {
    file: "assets/Dana-Regular-43506011.woff2",
    src: "resources/fonts/woff2/Dana-Regular.woff2"
  },
  "resources/fonts/woff2/Dana-Thin.woff2": {
    file: "assets/Dana-Thin-bec2bd8a.woff2",
    src: "resources/fonts/woff2/Dana-Thin.woff2"
  },
  "resources/fonts/woff2/Dana-UltraLight.woff2": {
    file: "assets/Dana-UltraLight-24615a03.woff2",
    src: "resources/fonts/woff2/Dana-UltraLight.woff2"
  },
  "resources/js/Pages/Accessories/Components/ProductsSlider.jsx": {
    file: "assets/ProductsSlider-f79903d3.js",
    imports: [
      "resources/js/app.jsx",
      "_pagination-f0cee491.js",
      "_RadioInput-5e9441ef.js",
      "_InputLabel-0000cb07.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Accessories/Components/ProductsSlider.jsx"
  },
  "resources/js/Pages/Accessories/Index.jsx": {
    file: "assets/Index-bb1ac0bd.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-91f361bd.js",
      "_SecondaryButton-0597d2b2.js",
      "_DangerButton-76ab6699.js",
      "_Modal-5409478e.js",
      "_PrimaryButton-15e1f725.js",
      "_Pagination-fafa5d58.js",
      "_useMemorable-4c077465.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_Icon-fbdb9045.js",
      "_transition-70017498.js",
      "_useFirstRender-4c1fa5a4.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Accessories/Index.jsx"
  },
  "resources/js/Pages/Accessories/Show.jsx": {
    file: "assets/Show-ff24f900.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-91f361bd.js",
      "_WarningButton-84602cc5.js",
      "_PrimaryButton-15e1f725.js",
      "_SecondaryButton-0597d2b2.js",
      "_useMemorable-4c077465.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_Icon-fbdb9045.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Accessories/Show.jsx"
  },
  "resources/js/Pages/Admin/Accessories.jsx": {
    file: "assets/Accessories-af0dd25b.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-91f361bd.js",
      "_Pagination-fafa5d58.js",
      "_useFirstRender-4c1fa5a4.js",
      "_TextInput-eb1932a1.js",
      "_useMemorable-4c077465.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_Icon-fbdb9045.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Admin/Accessories.jsx"
  },
  "resources/js/Pages/Admin/Records.jsx": {
    file: "assets/Records-d37fd832.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-91f361bd.js",
      "_Pagination-fafa5d58.js",
      "_TextInput-eb1932a1.js",
      "_useFirstRender-4c1fa5a4.js",
      "_useMemorable-4c077465.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_Icon-fbdb9045.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Admin/Records.jsx"
  },
  "resources/js/Pages/Auth/Address.jsx": {
    file: "assets/Address-177d2e9c.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-eed184ad.js",
      "_InputError-d819808c.js",
      "_PrimaryButton-15e1f725.js",
      "_TextInput-eb1932a1.js",
      "_TextAreaInput-3915a84d.js",
      "_RadioInput-5e9441ef.js",
      "_InputLabel-0000cb07.js",
      "_Icon-fbdb9045.js",
      "_DangerButton-76ab6699.js",
      "_SelectInput-a4bcb65f.js",
      "_IranStatesOptions-06764a25.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_useMemorable-4c077465.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Address.jsx"
  },
  "resources/js/Pages/Auth/ConfirmPassword.jsx": {
    file: "assets/ConfirmPassword-ef9704ef.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-eed184ad.js",
      "_InputError-d819808c.js",
      "_InputLabel-0000cb07.js",
      "_PrimaryButton-15e1f725.js",
      "_TextInput-eb1932a1.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_useMemorable-4c077465.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/ConfirmPassword.jsx"
  },
  "resources/js/Pages/Auth/ForgotPassword.jsx": {
    file: "assets/ForgotPassword-186c747a.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-eed184ad.js",
      "_InputError-d819808c.js",
      "_PrimaryButton-15e1f725.js",
      "_TextInput-eb1932a1.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_useMemorable-4c077465.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/ForgotPassword.jsx"
  },
  "resources/js/Pages/Auth/Info.jsx": {
    file: "assets/Info-305ea728.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-eed184ad.js",
      "_InputError-d819808c.js",
      "_PrimaryButton-15e1f725.js",
      "_TextInput-eb1932a1.js",
      "_TextAreaInput-3915a84d.js",
      "_FileInput-2e9e4949.js",
      "_InputLabel-0000cb07.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_useMemorable-4c077465.js",
      "_Icon-fbdb9045.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Info.jsx"
  },
  "resources/js/Pages/Auth/Login.jsx": {
    file: "assets/Login-a9fe07ba.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-eed184ad.js",
      "_InputError-d819808c.js",
      "_InputLabel-0000cb07.js",
      "_PrimaryButton-15e1f725.js",
      "_TextInput-eb1932a1.js",
      "_CheckboxInput-62e99544.js",
      "_WarningButton-84602cc5.js",
      "_Icon-fbdb9045.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_useMemorable-4c077465.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Login.jsx"
  },
  "resources/js/Pages/Auth/Register.jsx": {
    file: "assets/Register-ec0c6db1.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-eed184ad.js",
      "_InputError-d819808c.js",
      "_PrimaryButton-15e1f725.js",
      "_TextInput-eb1932a1.js",
      "_SelectInput-a4bcb65f.js",
      "_IranStatesOptions-06764a25.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_useMemorable-4c077465.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Register.jsx"
  },
  "resources/js/Pages/Auth/ResetPassword.jsx": {
    file: "assets/ResetPassword-0c77dc63.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-eed184ad.js",
      "_InputError-d819808c.js",
      "_PrimaryButton-15e1f725.js",
      "_TextInput-eb1932a1.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_useMemorable-4c077465.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/ResetPassword.jsx"
  },
  "resources/js/Pages/Auth/VerifyEmail.jsx": {
    file: "assets/VerifyEmail-d900184b.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-eed184ad.js",
      "_PrimaryButton-15e1f725.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_useMemorable-4c077465.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/VerifyEmail.jsx"
  },
  "resources/js/Pages/Auth/WaitForVerify.jsx": {
    file: "assets/WaitForVerify-a7bc40ca.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-eed184ad.js",
      "_lottie-react.esm-fab63579.js",
      "_PrimaryButton-15e1f725.js",
      "_DangerButton-76ab6699.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_useMemorable-4c077465.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/WaitForVerify.jsx"
  },
  "resources/js/Pages/Dashboards/Admin.jsx": {
    file: "assets/Admin-9b4df737.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-91f361bd.js",
      "_ArrowLink-613cb697.js",
      "_useMemorable-4c077465.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_Icon-fbdb9045.js",
      "__commonjs-dynamic-modules-302442b1.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Dashboards/Admin.jsx"
  },
  "resources/js/Pages/Dashboards/User.jsx": {
    file: "assets/User-020ea3c1.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-91f361bd.js",
      "_ArrowLink-613cb697.js",
      "_useMemorable-4c077465.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_Icon-fbdb9045.js",
      "__commonjs-dynamic-modules-302442b1.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Dashboards/User.jsx"
  },
  "resources/js/Pages/Download/Accessory.jsx": {
    file: "assets/Accessory-c89df506.js",
    imports: [
      "resources/js/app.jsx",
      "_manifest-2a57ceab.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Download/Accessory.jsx"
  },
  "resources/js/Pages/Download/Record.jsx": {
    file: "assets/Record-d5a2edf1.js",
    imports: [
      "resources/js/app.jsx",
      "_manifest-2a57ceab.js",
      "__commonjs-dynamic-modules-302442b1.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Download/Record.jsx"
  },
  "resources/js/Pages/Patients/Create.jsx": {
    file: "assets/Create-3b34c9cb.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-91f361bd.js",
      "_TextInput-eb1932a1.js",
      "_InputError-d819808c.js",
      "_TextAreaInput-3915a84d.js",
      "_PrimaryButton-15e1f725.js",
      "_SelectInput-a4bcb65f.js",
      "_IranStatesOptions-06764a25.js",
      "_DangerButton-76ab6699.js",
      "_useMemorable-4c077465.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_Icon-fbdb9045.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Create.jsx"
  },
  "resources/js/Pages/Patients/Edit.jsx": {
    file: "assets/Edit-03735e2a.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-91f361bd.js",
      "_TextInput-eb1932a1.js",
      "_InputError-d819808c.js",
      "_TextAreaInput-3915a84d.js",
      "_PrimaryButton-15e1f725.js",
      "_SelectInput-a4bcb65f.js",
      "_IranStatesOptions-06764a25.js",
      "_DangerButton-76ab6699.js",
      "_useMemorable-4c077465.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_Icon-fbdb9045.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Edit.jsx"
  },
  "resources/js/Pages/Patients/Index.jsx": {
    file: "assets/Index-5ac76191.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-91f361bd.js",
      "_SecondaryButton-0597d2b2.js",
      "_DangerButton-76ab6699.js",
      "_Modal-5409478e.js",
      "_Pagination-fafa5d58.js",
      "_useMemorable-4c077465.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_Icon-fbdb9045.js",
      "_transition-70017498.js",
      "_useFirstRender-4c1fa5a4.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Index.jsx"
  },
  "resources/js/Pages/Patients/Partials/DeleteUserForm.jsx": {
    file: "assets/DeleteUserForm-586c1e5a.js",
    imports: [
      "resources/js/app.jsx",
      "_DangerButton-76ab6699.js",
      "_InputError-d819808c.js",
      "_InputLabel-0000cb07.js",
      "_Modal-5409478e.js",
      "_SecondaryButton-0597d2b2.js",
      "_TextInput-eb1932a1.js",
      "_transition-70017498.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Partials/DeleteUserForm.jsx"
  },
  "resources/js/Pages/Patients/Partials/UpdatePasswordForm.jsx": {
    file: "assets/UpdatePasswordForm-b9ec501b.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-d819808c.js",
      "_InputLabel-0000cb07.js",
      "_PrimaryButton-15e1f725.js",
      "_TextInput-eb1932a1.js",
      "_transition-70017498.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Partials/UpdatePasswordForm.jsx"
  },
  "resources/js/Pages/Patients/Partials/UpdateProfileInformationForm.jsx": {
    file: "assets/UpdateProfileInformationForm-2f7dc25c.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-d819808c.js",
      "_InputLabel-0000cb07.js",
      "_PrimaryButton-15e1f725.js",
      "_TextInput-eb1932a1.js",
      "_transition-70017498.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Partials/UpdateProfileInformationForm.jsx"
  },
  "resources/js/Pages/Products/CreateOrEdit.jsx": {
    file: "assets/CreateOrEdit-e1236e6e.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-91f361bd.js",
      "_TextInput-eb1932a1.js",
      "_InputError-d819808c.js",
      "_PrimaryButton-15e1f725.js",
      "_SelectInput-a4bcb65f.js",
      "_DangerButton-76ab6699.js",
      "_Icon-fbdb9045.js",
      "_CheckboxInput-62e99544.js",
      "_InputLabel-0000cb07.js",
      "_useMemorable-4c077465.js",
      "_ApplicationLogo-0a6ae78f.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Products/CreateOrEdit.jsx"
  },
  "resources/js/Pages/Products/Index.jsx": {
    file: "assets/Index-af74b836.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-91f361bd.js",
      "_SecondaryButton-0597d2b2.js",
      "_DangerButton-76ab6699.js",
      "_Modal-5409478e.js",
      "_PrimaryButton-15e1f725.js",
      "_Pagination-fafa5d58.js",
      "_TextInput-eb1932a1.js",
      "_useFirstRender-4c1fa5a4.js",
      "_useMemorable-4c077465.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_Icon-fbdb9045.js",
      "_transition-70017498.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Products/Index.jsx"
  },
  "resources/js/Pages/Profile/Edit.jsx": {
    file: "assets/Edit-359f1cb4.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-91f361bd.js",
      "_GuestLayout-eed184ad.js",
      "_TextInput-eb1932a1.js",
      "_InputError-d819808c.js",
      "_TextAreaInput-3915a84d.js",
      "_PrimaryButton-15e1f725.js",
      "_DangerButton-76ab6699.js",
      "_SelectInput-a4bcb65f.js",
      "_IranStatesOptions-06764a25.js",
      "_FileInput-2e9e4949.js",
      "_RadioInput-5e9441ef.js",
      "_InputLabel-0000cb07.js",
      "_Icon-fbdb9045.js",
      "_useMemorable-4c077465.js",
      "_ApplicationLogo-0a6ae78f.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Profile/Edit.jsx"
  },
  "resources/js/Pages/Profile/Index.jsx": {
    file: "assets/Index-3482d4a5.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-91f361bd.js",
      "_WarningButton-84602cc5.js",
      "_useMemorable-4c077465.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_Icon-fbdb9045.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Profile/Index.jsx"
  },
  "resources/js/Pages/Records/Components/ProductsSlider.jsx": {
    file: "assets/ProductsSlider-3f210819.js",
    imports: [
      "resources/js/app.jsx",
      "_pagination-f0cee491.js",
      "_RadioInput-5e9441ef.js",
      "_InputLabel-0000cb07.js",
      "_CheckboxInput-62e99544.js",
      "_Icon-fbdb9045.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Components/ProductsSlider.jsx"
  },
  "resources/js/Pages/Records/Components/Steps.jsx": {
    file: "assets/Steps-8d4c0560.js",
    imports: [
      "resources/js/app.jsx",
      "resources/js/Pages/Records/Partials/Step.jsx",
      "_Icon-fbdb9045.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Components/Steps.jsx"
  },
  "resources/js/Pages/Records/Index.jsx": {
    file: "assets/Index-0dd4f051.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-91f361bd.js",
      "_SecondaryButton-0597d2b2.js",
      "_DangerButton-76ab6699.js",
      "_Modal-5409478e.js",
      "_PrimaryButton-15e1f725.js",
      "_Pagination-fafa5d58.js",
      "_useMemorable-4c077465.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_Icon-fbdb9045.js",
      "_transition-70017498.js",
      "_useFirstRender-4c1fa5a4.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Index.jsx"
  },
  "resources/js/Pages/Records/Partials/Step.jsx": {
    file: "assets/Step-f7f14089.js",
    imports: [
      "resources/js/app.jsx"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Partials/Step.jsx"
  },
  "resources/js/Pages/Records/Show.jsx": {
    file: "assets/Show-03a97c41.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-91f361bd.js",
      "_WarningButton-84602cc5.js",
      "_PrimaryButton-15e1f725.js",
      "_SecondaryButton-0597d2b2.js",
      "_useMemorable-4c077465.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_Icon-fbdb9045.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Show.jsx"
  },
  "resources/js/Pages/Settings/CreateOrEdit.jsx": {
    file: "assets/CreateOrEdit-3baeb71d.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-91f361bd.js",
      "_TextInput-eb1932a1.js",
      "_InputError-d819808c.js",
      "_PrimaryButton-15e1f725.js",
      "_DangerButton-76ab6699.js",
      "_useMemorable-4c077465.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_Icon-fbdb9045.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/CreateOrEdit.jsx"
  },
  "resources/js/Pages/Settings/Index.jsx": {
    file: "assets/Index-824dea86.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-91f361bd.js",
      "_SecondaryButton-0597d2b2.js",
      "_DangerButton-76ab6699.js",
      "_Modal-5409478e.js",
      "_PrimaryButton-15e1f725.js",
      "_Pagination-fafa5d58.js",
      "_TextInput-eb1932a1.js",
      "_useFirstRender-4c1fa5a4.js",
      "_useMemorable-4c077465.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_Icon-fbdb9045.js",
      "_transition-70017498.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/Index.jsx"
  },
  "resources/js/Pages/Settings/OffLimits.jsx": {
    file: "assets/OffLimits-e2131462.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-91f361bd.js",
      "_PrimaryButton-15e1f725.js",
      "_lottie-react.esm-fab63579.js",
      "_useMemorable-4c077465.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_Icon-fbdb9045.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/OffLimits.jsx"
  },
  "resources/js/Pages/Settings/OutOfSchedule.jsx": {
    file: "assets/OutOfSchedule-9ecf5e0a.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-91f361bd.js",
      "_PrimaryButton-15e1f725.js",
      "_lottie-react.esm-fab63579.js",
      "_useMemorable-4c077465.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_Icon-fbdb9045.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/OutOfSchedule.jsx"
  },
  "resources/js/Pages/Terms.jsx": {
    file: "assets/Terms-88603fa5.js",
    imports: [
      "resources/js/app.jsx",
      "_ApplicationLogo-0a6ae78f.js",
      "_Icon-fbdb9045.js",
      "_PrimaryButton-15e1f725.js",
      "_index-4e3bb690.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Terms.jsx"
  },
  "resources/js/Pages/Users/Create.jsx": {
    file: "assets/Create-e7cad353.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-91f361bd.js",
      "_TextInput-eb1932a1.js",
      "_InputError-d819808c.js",
      "_TextAreaInput-3915a84d.js",
      "_PrimaryButton-15e1f725.js",
      "_SelectInput-a4bcb65f.js",
      "_IranStatesOptions-06764a25.js",
      "_DangerButton-76ab6699.js",
      "_useMemorable-4c077465.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_Icon-fbdb9045.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Create.jsx"
  },
  "resources/js/Pages/Users/Edit.jsx": {
    file: "assets/Edit-3c77054b.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-91f361bd.js",
      "_TextAreaInput-3915a84d.js",
      "_TextInput-eb1932a1.js",
      "_InputError-d819808c.js",
      "_PrimaryButton-15e1f725.js",
      "_DangerButton-76ab6699.js",
      "_SelectInput-a4bcb65f.js",
      "_WarningButton-84602cc5.js",
      "_Modal-5409478e.js",
      "_CheckboxInput-62e99544.js",
      "_InputLabel-0000cb07.js",
      "_useMemorable-4c077465.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_Icon-fbdb9045.js",
      "_transition-70017498.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Edit.jsx"
  },
  "resources/js/Pages/Users/Index.jsx": {
    file: "assets/Index-6a91c0cd.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-91f361bd.js",
      "_Pagination-fafa5d58.js",
      "_TextInput-eb1932a1.js",
      "_useFirstRender-4c1fa5a4.js",
      "_SelectInput-a4bcb65f.js",
      "_useMemorable-4c077465.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_Icon-fbdb9045.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Index.jsx"
  },
  "resources/js/Pages/Users/NotCompleted.jsx": {
    file: "assets/NotCompleted-222c10ce.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-91f361bd.js",
      "_Pagination-fafa5d58.js",
      "_SecondaryButton-0597d2b2.js",
      "_DangerButton-76ab6699.js",
      "_Modal-5409478e.js",
      "_TextInput-eb1932a1.js",
      "_useFirstRender-4c1fa5a4.js",
      "_useMemorable-4c077465.js",
      "_ApplicationLogo-0a6ae78f.js",
      "_Icon-fbdb9045.js",
      "_transition-70017498.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/NotCompleted.jsx"
  },
  "resources/js/Pages/Users/Partials/DeleteUserForm.jsx": {
    file: "assets/DeleteUserForm-591d15db.js",
    imports: [
      "resources/js/app.jsx",
      "_DangerButton-76ab6699.js",
      "_InputError-d819808c.js",
      "_InputLabel-0000cb07.js",
      "_Modal-5409478e.js",
      "_SecondaryButton-0597d2b2.js",
      "_TextInput-eb1932a1.js",
      "_transition-70017498.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Partials/DeleteUserForm.jsx"
  },
  "resources/js/Pages/Users/Partials/UpdatePasswordForm.jsx": {
    file: "assets/UpdatePasswordForm-f835b8c2.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-d819808c.js",
      "_InputLabel-0000cb07.js",
      "_PrimaryButton-15e1f725.js",
      "_TextInput-eb1932a1.js",
      "_transition-70017498.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Partials/UpdatePasswordForm.jsx"
  },
  "resources/js/Pages/Users/Partials/UpdateProfileInformationForm.jsx": {
    file: "assets/UpdateProfileInformationForm-2692c5b6.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-d819808c.js",
      "_InputLabel-0000cb07.js",
      "_PrimaryButton-15e1f725.js",
      "_TextInput-eb1932a1.js",
      "_transition-70017498.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Partials/UpdateProfileInformationForm.jsx"
  },
  "resources/js/Pages/Welcome.jsx": {
    file: "assets/Welcome-272e221b.js",
    imports: [
      "resources/js/app.jsx",
      "_ApplicationLogo-0a6ae78f.js",
      "_Icon-fbdb9045.js",
      "_PrimaryButton-15e1f725.js",
      "_index-4e3bb690.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Welcome.jsx"
  },
  "resources/js/app.css": {
    file: "assets/app-de08c80b.css",
    src: "resources/js/app.css"
  },
  "resources/js/app.jsx": {
    assets: [
      "assets/Dana-Hairline-7712cf11.woff2",
      "assets/Dana-Hairline-6d7bb084.woff",
      "assets/Dana-Thin-bec2bd8a.woff2",
      "assets/Dana-Thin-56dc1e1f.woff",
      "assets/Dana-UltraLight-24615a03.woff2",
      "assets/Dana-UltraLight-a025f30e.woff",
      "assets/Dana-Light-e07a4868.woff2",
      "assets/Dana-Light-eeed4155.woff",
      "assets/Dana-Medium-d623f857.woff2",
      "assets/Dana-Medium-d0241b30.woff",
      "assets/Dana-DemiBold-34870445.woff2",
      "assets/Dana-DemiBold-fa427dcf.woff",
      "assets/Dana-ExtraBold-08dea612.woff2",
      "assets/Dana-ExtraBold-0d7888d7.woff",
      "assets/Dana-Black-cdfe2203.woff2",
      "assets/Dana-Black-575de1e5.woff",
      "assets/Dana-ExtraBlack-3208afe0.woff2",
      "assets/Dana-ExtraBlack-6c729c23.woff",
      "assets/Dana-Heavy-091eb261.woff2",
      "assets/Dana-Heavy-e159608a.woff",
      "assets/Dana-Fat-1f7b7061.woff2",
      "assets/Dana-Fat-8831a7f0.woff",
      "assets/Dana-Regular-43506011.woff2",
      "assets/Dana-Regular-eee25c04.woff"
    ],
    css: [
      "assets/app-de08c80b.css"
    ],
    dynamicImports: [
      "resources/js/Pages/Accessories/Components/ProductsSlider.jsx",
      "_Create-2d1cd55c.js",
      "resources/js/Pages/Accessories/Index.jsx",
      "resources/js/Pages/Accessories/Show.jsx",
      "_Create-2d1cd55c.js",
      "_Create-2d1cd55c.js",
      "resources/js/Pages/Admin/Accessories.jsx",
      "resources/js/Pages/Admin/Records.jsx",
      "resources/js/Pages/Auth/Address.jsx",
      "resources/js/Pages/Auth/ConfirmPassword.jsx",
      "resources/js/Pages/Auth/ForgotPassword.jsx",
      "resources/js/Pages/Auth/Info.jsx",
      "resources/js/Pages/Auth/Login.jsx",
      "resources/js/Pages/Auth/Register.jsx",
      "resources/js/Pages/Auth/ResetPassword.jsx",
      "resources/js/Pages/Auth/VerifyEmail.jsx",
      "resources/js/Pages/Auth/WaitForVerify.jsx",
      "resources/js/Pages/Dashboards/Admin.jsx",
      "resources/js/Pages/Dashboards/User.jsx",
      "resources/js/Pages/Download/Accessory.jsx",
      "resources/js/Pages/Download/Record.jsx",
      "resources/js/Pages/Patients/Create.jsx",
      "resources/js/Pages/Patients/Edit.jsx",
      "resources/js/Pages/Patients/Index.jsx",
      "resources/js/Pages/Patients/Partials/DeleteUserForm.jsx",
      "resources/js/Pages/Patients/Partials/UpdatePasswordForm.jsx",
      "resources/js/Pages/Patients/Partials/UpdateProfileInformationForm.jsx",
      "resources/js/Pages/Products/CreateOrEdit.jsx",
      "resources/js/Pages/Products/Index.jsx",
      "resources/js/Pages/Profile/Edit.jsx",
      "resources/js/Pages/Profile/Index.jsx",
      "_AidInputs-7d83a21d.js",
      "resources/js/Pages/Records/Components/ProductsSlider.jsx",
      "resources/js/Pages/Records/Components/Steps.jsx",
      "_AidInputs-7d83a21d.js",
      "resources/js/Pages/Records/Index.jsx",
      "resources/js/Pages/Records/Partials/Step.jsx",
      "resources/js/Pages/Records/Show.jsx",
      "_AidInputs-7d83a21d.js",
      "_AidInputs-7d83a21d.js",
      "_AidInputs-7d83a21d.js",
      "_AidInputs-7d83a21d.js",
      "_AidInputs-7d83a21d.js",
      "resources/js/Pages/Settings/CreateOrEdit.jsx",
      "resources/js/Pages/Settings/Index.jsx",
      "resources/js/Pages/Settings/OffLimits.jsx",
      "resources/js/Pages/Settings/OutOfSchedule.jsx",
      "resources/js/Pages/Terms.jsx",
      "resources/js/Pages/Users/Create.jsx",
      "resources/js/Pages/Users/Edit.jsx",
      "resources/js/Pages/Users/Index.jsx",
      "resources/js/Pages/Users/NotCompleted.jsx",
      "resources/js/Pages/Users/Partials/DeleteUserForm.jsx",
      "resources/js/Pages/Users/Partials/UpdatePasswordForm.jsx",
      "resources/js/Pages/Users/Partials/UpdateProfileInformationForm.jsx",
      "resources/js/Pages/Welcome.jsx"
    ],
    file: "assets/app-0b5bb07e.js",
    isEntry: true,
    src: "resources/js/app.jsx"
  }
};
export {
  manifest as m
};
