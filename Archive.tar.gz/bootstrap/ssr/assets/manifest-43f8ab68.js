const manifest = {
  "AuthenticatedLayout.css": {
    file: "assets/AuthenticatedLayout-3a83175c.css",
    src: "AuthenticatedLayout.css"
  },
  "_AidInputs-fa479c6d.js": {
    file: "assets/AidInputs-fa479c6d.js",
    imports: [
      "resources/js/app.jsx",
      "_SelectInput-f53d1795.js",
      "_InputError-31af6c75.js",
      "_PrimaryButton-9af796e2.js",
      "_DangerButton-dbdeca01.js",
      "_AuthenticatedLayout-bbe377af.js",
      "resources/js/Pages/Records/Components/Steps.jsx",
      "_TextInput-ecc365ed.js",
      "_TextAreaInput-4e2542b0.js",
      "_IranStatesOptions-ac5320bc.js",
      "_FileInput-1aaed77b.js",
      "_RadioInput-2db15d02.js",
      "_InputLabel-0210d3ef.js",
      "resources/js/Pages/Records/Components/ProductsSlider.jsx",
      "_CheckboxInput-cd5573f1.js"
    ],
    isDynamicEntry: true
  },
  "_ApplicationLogo-11d7c1ac.js": {
    file: "assets/ApplicationLogo-11d7c1ac.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_ArrowLink-76c7a2f9.js": {
    file: "assets/ArrowLink-76c7a2f9.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_AuthenticatedLayout-bbe377af.js": {
    css: [
      "assets/AuthenticatedLayout-3a83175c.css"
    ],
    file: "assets/AuthenticatedLayout-bbe377af.js",
    imports: [
      "resources/js/app.jsx",
      "_useMemorable-60c867db.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_Icon-c058f063.js"
    ]
  },
  "_CheckboxInput-cd5573f1.js": {
    file: "assets/CheckboxInput-cd5573f1.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_Create-99eb5a9e.js": {
    file: "assets/Create-99eb5a9e.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bbe377af.js",
      "_TextInput-ecc365ed.js",
      "_InputError-31af6c75.js",
      "_TextAreaInput-4e2542b0.js",
      "_PrimaryButton-9af796e2.js",
      "_SelectInput-f53d1795.js",
      "_RadioInput-2db15d02.js",
      "_InputLabel-0210d3ef.js",
      "resources/js/Pages/Accessories/Components/ProductsSlider.jsx",
      "_CheckboxInput-cd5573f1.js",
      "_DangerButton-dbdeca01.js"
    ],
    isDynamicEntry: true
  },
  "_DangerButton-dbdeca01.js": {
    file: "assets/DangerButton-dbdeca01.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_FileInput-1aaed77b.js": {
    file: "assets/FileInput-1aaed77b.js",
    imports: [
      "resources/js/app.jsx",
      "_Icon-c058f063.js",
      "_PrimaryButton-9af796e2.js"
    ]
  },
  "_GuestLayout-5ec5b624.js": {
    file: "assets/GuestLayout-5ec5b624.js",
    imports: [
      "resources/js/app.jsx",
      "_ApplicationLogo-11d7c1ac.js",
      "_useMemorable-60c867db.js"
    ]
  },
  "_Icon-c058f063.js": {
    file: "assets/Icon-c058f063.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_InputError-31af6c75.js": {
    file: "assets/InputError-31af6c75.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_InputLabel-0210d3ef.js": {
    file: "assets/InputLabel-0210d3ef.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_IranStatesOptions-ac5320bc.js": {
    file: "assets/IranStatesOptions-ac5320bc.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_Modal-a9b1f5bb.js": {
    file: "assets/Modal-a9b1f5bb.js",
    imports: [
      "resources/js/app.jsx",
      "_transition-2fe1e5c3.js"
    ]
  },
  "_Pagination-11223612.js": {
    file: "assets/Pagination-11223612.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_PrimaryButton-9af796e2.js": {
    file: "assets/PrimaryButton-9af796e2.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_RadioInput-2db15d02.js": {
    file: "assets/RadioInput-2db15d02.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_SecondaryButton-9256dc99.js": {
    file: "assets/SecondaryButton-9256dc99.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_SelectInput-f53d1795.js": {
    file: "assets/SelectInput-f53d1795.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_TextAreaInput-4e2542b0.js": {
    file: "assets/TextAreaInput-4e2542b0.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_TextInput-ecc365ed.js": {
    file: "assets/TextInput-ecc365ed.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_WarningButton-452bc730.js": {
    file: "assets/WarningButton-452bc730.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_index-b178287a.js": {
    file: "assets/index-b178287a.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_lottie-react.esm-ab17165f.js": {
    file: "assets/lottie-react.esm-ab17165f.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_manifest-2be7582b.js": {
    file: "assets/manifest-2be7582b.js"
  },
  "_pagination-934ce237.js": {
    css: [
      "assets/pagination-58c369bc.css"
    ],
    file: "assets/pagination-934ce237.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_transition-2fe1e5c3.js": {
    file: "assets/transition-2fe1e5c3.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_useMemorable-60c867db.js": {
    file: "assets/useMemorable-60c867db.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "pagination.css": {
    file: "assets/pagination-58c369bc.css",
    src: "pagination.css"
  },
  "resources/fonts/woff/Dana-Black.woff": {
    file: "assets/Dana-Black-575de1e5.woff",
    src: "resources/fonts/woff/Dana-Black.woff"
  },
  "resources/fonts/woff/Dana-DemiBold.woff": {
    file: "assets/Dana-DemiBold-fa427dcf.woff",
    src: "resources/fonts/woff/Dana-DemiBold.woff"
  },
  "resources/fonts/woff/Dana-ExtraBlack.woff": {
    file: "assets/Dana-ExtraBlack-6c729c23.woff",
    src: "resources/fonts/woff/Dana-ExtraBlack.woff"
  },
  "resources/fonts/woff/Dana-ExtraBold.woff": {
    file: "assets/Dana-ExtraBold-0d7888d7.woff",
    src: "resources/fonts/woff/Dana-ExtraBold.woff"
  },
  "resources/fonts/woff/Dana-Fat.woff": {
    file: "assets/Dana-Fat-8831a7f0.woff",
    src: "resources/fonts/woff/Dana-Fat.woff"
  },
  "resources/fonts/woff/Dana-Hairline.woff": {
    file: "assets/Dana-Hairline-6d7bb084.woff",
    src: "resources/fonts/woff/Dana-Hairline.woff"
  },
  "resources/fonts/woff/Dana-Heavy.woff": {
    file: "assets/Dana-Heavy-e159608a.woff",
    src: "resources/fonts/woff/Dana-Heavy.woff"
  },
  "resources/fonts/woff/Dana-Light.woff": {
    file: "assets/Dana-Light-eeed4155.woff",
    src: "resources/fonts/woff/Dana-Light.woff"
  },
  "resources/fonts/woff/Dana-Medium.woff": {
    file: "assets/Dana-Medium-d0241b30.woff",
    src: "resources/fonts/woff/Dana-Medium.woff"
  },
  "resources/fonts/woff/Dana-Regular.woff": {
    file: "assets/Dana-Regular-eee25c04.woff",
    src: "resources/fonts/woff/Dana-Regular.woff"
  },
  "resources/fonts/woff/Dana-Thin.woff": {
    file: "assets/Dana-Thin-56dc1e1f.woff",
    src: "resources/fonts/woff/Dana-Thin.woff"
  },
  "resources/fonts/woff/Dana-UltraLight.woff": {
    file: "assets/Dana-UltraLight-a025f30e.woff",
    src: "resources/fonts/woff/Dana-UltraLight.woff"
  },
  "resources/fonts/woff2/Dana-Black.woff2": {
    file: "assets/Dana-Black-cdfe2203.woff2",
    src: "resources/fonts/woff2/Dana-Black.woff2"
  },
  "resources/fonts/woff2/Dana-DemiBold.woff2": {
    file: "assets/Dana-DemiBold-34870445.woff2",
    src: "resources/fonts/woff2/Dana-DemiBold.woff2"
  },
  "resources/fonts/woff2/Dana-ExtraBlack.woff2": {
    file: "assets/Dana-ExtraBlack-3208afe0.woff2",
    src: "resources/fonts/woff2/Dana-ExtraBlack.woff2"
  },
  "resources/fonts/woff2/Dana-ExtraBold.woff2": {
    file: "assets/Dana-ExtraBold-08dea612.woff2",
    src: "resources/fonts/woff2/Dana-ExtraBold.woff2"
  },
  "resources/fonts/woff2/Dana-Fat.woff2": {
    file: "assets/Dana-Fat-1f7b7061.woff2",
    src: "resources/fonts/woff2/Dana-Fat.woff2"
  },
  "resources/fonts/woff2/Dana-Hairline.woff2": {
    file: "assets/Dana-Hairline-7712cf11.woff2",
    src: "resources/fonts/woff2/Dana-Hairline.woff2"
  },
  "resources/fonts/woff2/Dana-Heavy.woff2": {
    file: "assets/Dana-Heavy-091eb261.woff2",
    src: "resources/fonts/woff2/Dana-Heavy.woff2"
  },
  "resources/fonts/woff2/Dana-Light.woff2": {
    file: "assets/Dana-Light-e07a4868.woff2",
    src: "resources/fonts/woff2/Dana-Light.woff2"
  },
  "resources/fonts/woff2/Dana-Medium.woff2": {
    file: "assets/Dana-Medium-d623f857.woff2",
    src: "resources/fonts/woff2/Dana-Medium.woff2"
  },
  "resources/fonts/woff2/Dana-Regular.woff2": {
    file: "assets/Dana-Regular-43506011.woff2",
    src: "resources/fonts/woff2/Dana-Regular.woff2"
  },
  "resources/fonts/woff2/Dana-Thin.woff2": {
    file: "assets/Dana-Thin-bec2bd8a.woff2",
    src: "resources/fonts/woff2/Dana-Thin.woff2"
  },
  "resources/fonts/woff2/Dana-UltraLight.woff2": {
    file: "assets/Dana-UltraLight-24615a03.woff2",
    src: "resources/fonts/woff2/Dana-UltraLight.woff2"
  },
  "resources/js/Pages/Accessories/Components/ProductsSlider.jsx": {
    file: "assets/ProductsSlider-095d7a94.js",
    imports: [
      "resources/js/app.jsx",
      "_pagination-934ce237.js",
      "_RadioInput-2db15d02.js",
      "_InputLabel-0210d3ef.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Accessories/Components/ProductsSlider.jsx"
  },
  "resources/js/Pages/Accessories/Index.jsx": {
    file: "assets/Index-9d396369.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bbe377af.js",
      "_SecondaryButton-9256dc99.js",
      "_DangerButton-dbdeca01.js",
      "_Modal-a9b1f5bb.js",
      "_PrimaryButton-9af796e2.js",
      "_Pagination-11223612.js",
      "_useMemorable-60c867db.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_Icon-c058f063.js",
      "_transition-2fe1e5c3.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Accessories/Index.jsx"
  },
  "resources/js/Pages/Accessories/Show.jsx": {
    file: "assets/Show-33d34a53.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bbe377af.js",
      "_WarningButton-452bc730.js",
      "_PrimaryButton-9af796e2.js",
      "_useMemorable-60c867db.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_Icon-c058f063.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Accessories/Show.jsx"
  },
  "resources/js/Pages/Admin/Accessories.jsx": {
    file: "assets/Accessories-1d13c984.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bbe377af.js",
      "_Pagination-11223612.js",
      "_useMemorable-60c867db.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_Icon-c058f063.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Admin/Accessories.jsx"
  },
  "resources/js/Pages/Admin/Records.jsx": {
    file: "assets/Records-e514411e.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bbe377af.js",
      "_Pagination-11223612.js",
      "_useMemorable-60c867db.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_Icon-c058f063.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Admin/Records.jsx"
  },
  "resources/js/Pages/Auth/Address.jsx": {
    file: "assets/Address-d8dc2511.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-5ec5b624.js",
      "_InputError-31af6c75.js",
      "_PrimaryButton-9af796e2.js",
      "_TextInput-ecc365ed.js",
      "_TextAreaInput-4e2542b0.js",
      "_RadioInput-2db15d02.js",
      "_InputLabel-0210d3ef.js",
      "_Icon-c058f063.js",
      "_DangerButton-dbdeca01.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_useMemorable-60c867db.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Address.jsx"
  },
  "resources/js/Pages/Auth/ConfirmPassword.jsx": {
    file: "assets/ConfirmPassword-0dffb96b.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-5ec5b624.js",
      "_InputError-31af6c75.js",
      "_InputLabel-0210d3ef.js",
      "_PrimaryButton-9af796e2.js",
      "_TextInput-ecc365ed.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_useMemorable-60c867db.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/ConfirmPassword.jsx"
  },
  "resources/js/Pages/Auth/ForgotPassword.jsx": {
    file: "assets/ForgotPassword-2e007acb.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-5ec5b624.js",
      "_InputError-31af6c75.js",
      "_PrimaryButton-9af796e2.js",
      "_TextInput-ecc365ed.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_useMemorable-60c867db.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/ForgotPassword.jsx"
  },
  "resources/js/Pages/Auth/Info.jsx": {
    file: "assets/Info-0f65b458.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-5ec5b624.js",
      "_InputError-31af6c75.js",
      "_PrimaryButton-9af796e2.js",
      "_TextInput-ecc365ed.js",
      "_TextAreaInput-4e2542b0.js",
      "_FileInput-1aaed77b.js",
      "_InputLabel-0210d3ef.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_useMemorable-60c867db.js",
      "_Icon-c058f063.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Info.jsx"
  },
  "resources/js/Pages/Auth/Login.jsx": {
    file: "assets/Login-fc43ba52.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-5ec5b624.js",
      "_InputError-31af6c75.js",
      "_InputLabel-0210d3ef.js",
      "_PrimaryButton-9af796e2.js",
      "_TextInput-ecc365ed.js",
      "_CheckboxInput-cd5573f1.js",
      "_WarningButton-452bc730.js",
      "_Icon-c058f063.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_useMemorable-60c867db.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Login.jsx"
  },
  "resources/js/Pages/Auth/Register.jsx": {
    file: "assets/Register-f56bb45e.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-5ec5b624.js",
      "_InputError-31af6c75.js",
      "_PrimaryButton-9af796e2.js",
      "_TextInput-ecc365ed.js",
      "_SelectInput-f53d1795.js",
      "_IranStatesOptions-ac5320bc.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_useMemorable-60c867db.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Register.jsx"
  },
  "resources/js/Pages/Auth/ResetPassword.jsx": {
    file: "assets/ResetPassword-34213af1.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-5ec5b624.js",
      "_InputError-31af6c75.js",
      "_PrimaryButton-9af796e2.js",
      "_TextInput-ecc365ed.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_useMemorable-60c867db.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/ResetPassword.jsx"
  },
  "resources/js/Pages/Auth/VerifyEmail.jsx": {
    file: "assets/VerifyEmail-a2f8983c.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-5ec5b624.js",
      "_PrimaryButton-9af796e2.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_useMemorable-60c867db.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/VerifyEmail.jsx"
  },
  "resources/js/Pages/Auth/WaitForVerify.jsx": {
    file: "assets/WaitForVerify-8dcb823b.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-5ec5b624.js",
      "_lottie-react.esm-ab17165f.js",
      "_PrimaryButton-9af796e2.js",
      "_DangerButton-dbdeca01.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_useMemorable-60c867db.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/WaitForVerify.jsx"
  },
  "resources/js/Pages/Dashboards/Admin.jsx": {
    file: "assets/Admin-7853042c.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bbe377af.js",
      "_ArrowLink-76c7a2f9.js",
      "_useMemorable-60c867db.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_Icon-c058f063.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Dashboards/Admin.jsx"
  },
  "resources/js/Pages/Dashboards/User.jsx": {
    file: "assets/User-d73381e0.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bbe377af.js",
      "_ArrowLink-76c7a2f9.js",
      "_useMemorable-60c867db.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_Icon-c058f063.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Dashboards/User.jsx"
  },
  "resources/js/Pages/Download/Accessory.jsx": {
    file: "assets/Accessory-fe0f1089.js",
    imports: [
      "resources/js/app.jsx",
      "_manifest-2be7582b.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Download/Accessory.jsx"
  },
  "resources/js/Pages/Download/Record.jsx": {
    file: "assets/Record-cb4d6b1e.js",
    imports: [
      "resources/js/app.jsx",
      "_manifest-2be7582b.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Download/Record.jsx"
  },
  "resources/js/Pages/Patients/Create.jsx": {
    file: "assets/Create-4f515a0a.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bbe377af.js",
      "_TextInput-ecc365ed.js",
      "_InputError-31af6c75.js",
      "_TextAreaInput-4e2542b0.js",
      "_PrimaryButton-9af796e2.js",
      "_SelectInput-f53d1795.js",
      "_IranStatesOptions-ac5320bc.js",
      "_DangerButton-dbdeca01.js",
      "_useMemorable-60c867db.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_Icon-c058f063.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Create.jsx"
  },
  "resources/js/Pages/Patients/Edit.jsx": {
    file: "assets/Edit-a0823404.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bbe377af.js",
      "_TextInput-ecc365ed.js",
      "_InputError-31af6c75.js",
      "_TextAreaInput-4e2542b0.js",
      "_PrimaryButton-9af796e2.js",
      "_SelectInput-f53d1795.js",
      "_IranStatesOptions-ac5320bc.js",
      "_DangerButton-dbdeca01.js",
      "_useMemorable-60c867db.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_Icon-c058f063.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Edit.jsx"
  },
  "resources/js/Pages/Patients/Index.jsx": {
    file: "assets/Index-33f921f5.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bbe377af.js",
      "_SecondaryButton-9256dc99.js",
      "_DangerButton-dbdeca01.js",
      "_Modal-a9b1f5bb.js",
      "_Pagination-11223612.js",
      "_useMemorable-60c867db.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_Icon-c058f063.js",
      "_transition-2fe1e5c3.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Index.jsx"
  },
  "resources/js/Pages/Patients/Partials/DeleteUserForm.jsx": {
    file: "assets/DeleteUserForm-9b3249ad.js",
    imports: [
      "resources/js/app.jsx",
      "_DangerButton-dbdeca01.js",
      "_InputError-31af6c75.js",
      "_InputLabel-0210d3ef.js",
      "_Modal-a9b1f5bb.js",
      "_SecondaryButton-9256dc99.js",
      "_TextInput-ecc365ed.js",
      "_transition-2fe1e5c3.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Partials/DeleteUserForm.jsx"
  },
  "resources/js/Pages/Patients/Partials/UpdatePasswordForm.jsx": {
    file: "assets/UpdatePasswordForm-d6045304.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-31af6c75.js",
      "_InputLabel-0210d3ef.js",
      "_PrimaryButton-9af796e2.js",
      "_TextInput-ecc365ed.js",
      "_transition-2fe1e5c3.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Partials/UpdatePasswordForm.jsx"
  },
  "resources/js/Pages/Patients/Partials/UpdateProfileInformationForm.jsx": {
    file: "assets/UpdateProfileInformationForm-12f48c86.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-31af6c75.js",
      "_InputLabel-0210d3ef.js",
      "_PrimaryButton-9af796e2.js",
      "_TextInput-ecc365ed.js",
      "_transition-2fe1e5c3.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Partials/UpdateProfileInformationForm.jsx"
  },
  "resources/js/Pages/Products/CreateOrEdit.jsx": {
    file: "assets/CreateOrEdit-9fabbc2b.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bbe377af.js",
      "_TextInput-ecc365ed.js",
      "_InputError-31af6c75.js",
      "_PrimaryButton-9af796e2.js",
      "_SelectInput-f53d1795.js",
      "_DangerButton-dbdeca01.js",
      "_Icon-c058f063.js",
      "_CheckboxInput-cd5573f1.js",
      "_InputLabel-0210d3ef.js",
      "_useMemorable-60c867db.js",
      "_ApplicationLogo-11d7c1ac.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Products/CreateOrEdit.jsx"
  },
  "resources/js/Pages/Products/Index.jsx": {
    file: "assets/Index-1822e66c.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bbe377af.js",
      "_SecondaryButton-9256dc99.js",
      "_DangerButton-dbdeca01.js",
      "_Modal-a9b1f5bb.js",
      "_PrimaryButton-9af796e2.js",
      "_Pagination-11223612.js",
      "_TextInput-ecc365ed.js",
      "_useMemorable-60c867db.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_Icon-c058f063.js",
      "_transition-2fe1e5c3.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Products/Index.jsx"
  },
  "resources/js/Pages/Profile/Edit.jsx": {
    file: "assets/Edit-5dceccef.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bbe377af.js",
      "_GuestLayout-5ec5b624.js",
      "_TextInput-ecc365ed.js",
      "_InputError-31af6c75.js",
      "_TextAreaInput-4e2542b0.js",
      "_PrimaryButton-9af796e2.js",
      "_DangerButton-dbdeca01.js",
      "_SelectInput-f53d1795.js",
      "_IranStatesOptions-ac5320bc.js",
      "_FileInput-1aaed77b.js",
      "_RadioInput-2db15d02.js",
      "_InputLabel-0210d3ef.js",
      "_useMemorable-60c867db.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_Icon-c058f063.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Profile/Edit.jsx"
  },
  "resources/js/Pages/Profile/Index.jsx": {
    file: "assets/Index-528e2901.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bbe377af.js",
      "_WarningButton-452bc730.js",
      "_useMemorable-60c867db.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_Icon-c058f063.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Profile/Index.jsx"
  },
  "resources/js/Pages/Records/Components/ProductsSlider.jsx": {
    file: "assets/ProductsSlider-dc09a347.js",
    imports: [
      "resources/js/app.jsx",
      "_pagination-934ce237.js",
      "_RadioInput-2db15d02.js",
      "_InputLabel-0210d3ef.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Components/ProductsSlider.jsx"
  },
  "resources/js/Pages/Records/Components/Steps.jsx": {
    file: "assets/Steps-9e12a90c.js",
    imports: [
      "resources/js/app.jsx",
      "resources/js/Pages/Records/Partials/Step.jsx",
      "_Icon-c058f063.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Components/Steps.jsx"
  },
  "resources/js/Pages/Records/Index.jsx": {
    file: "assets/Index-c06817a3.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bbe377af.js",
      "_SecondaryButton-9256dc99.js",
      "_DangerButton-dbdeca01.js",
      "_Modal-a9b1f5bb.js",
      "_PrimaryButton-9af796e2.js",
      "_Pagination-11223612.js",
      "_useMemorable-60c867db.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_Icon-c058f063.js",
      "_transition-2fe1e5c3.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Index.jsx"
  },
  "resources/js/Pages/Records/Partials/Step.jsx": {
    file: "assets/Step-4c140dae.js",
    imports: [
      "resources/js/app.jsx"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Partials/Step.jsx"
  },
  "resources/js/Pages/Records/Show.jsx": {
    file: "assets/Show-6382e599.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bbe377af.js",
      "_WarningButton-452bc730.js",
      "_PrimaryButton-9af796e2.js",
      "_useMemorable-60c867db.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_Icon-c058f063.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Show.jsx"
  },
  "resources/js/Pages/Settings/CreateOrEdit.jsx": {
    file: "assets/CreateOrEdit-d26f0d7d.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bbe377af.js",
      "_TextInput-ecc365ed.js",
      "_InputError-31af6c75.js",
      "_PrimaryButton-9af796e2.js",
      "_DangerButton-dbdeca01.js",
      "_useMemorable-60c867db.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_Icon-c058f063.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/CreateOrEdit.jsx"
  },
  "resources/js/Pages/Settings/Index.jsx": {
    file: "assets/Index-eb573f6e.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bbe377af.js",
      "_SecondaryButton-9256dc99.js",
      "_DangerButton-dbdeca01.js",
      "_Modal-a9b1f5bb.js",
      "_PrimaryButton-9af796e2.js",
      "_Pagination-11223612.js",
      "_useMemorable-60c867db.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_Icon-c058f063.js",
      "_transition-2fe1e5c3.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/Index.jsx"
  },
  "resources/js/Pages/Settings/OffLimits.jsx": {
    file: "assets/OffLimits-7c5430e8.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bbe377af.js",
      "_PrimaryButton-9af796e2.js",
      "_lottie-react.esm-ab17165f.js",
      "_useMemorable-60c867db.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_Icon-c058f063.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/OffLimits.jsx"
  },
  "resources/js/Pages/Settings/OutOfSchedule.jsx": {
    file: "assets/OutOfSchedule-2ad4ef6a.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bbe377af.js",
      "_PrimaryButton-9af796e2.js",
      "_lottie-react.esm-ab17165f.js",
      "_useMemorable-60c867db.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_Icon-c058f063.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/OutOfSchedule.jsx"
  },
  "resources/js/Pages/Terms.jsx": {
    file: "assets/Terms-d23434e3.js",
    imports: [
      "resources/js/app.jsx",
      "_ApplicationLogo-11d7c1ac.js",
      "_Icon-c058f063.js",
      "_PrimaryButton-9af796e2.js",
      "_index-b178287a.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Terms.jsx"
  },
  "resources/js/Pages/Users/Create.jsx": {
    file: "assets/Create-4f2c743c.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bbe377af.js",
      "_TextInput-ecc365ed.js",
      "_InputError-31af6c75.js",
      "_TextAreaInput-4e2542b0.js",
      "_PrimaryButton-9af796e2.js",
      "_SelectInput-f53d1795.js",
      "_IranStatesOptions-ac5320bc.js",
      "_DangerButton-dbdeca01.js",
      "_useMemorable-60c867db.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_Icon-c058f063.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Create.jsx"
  },
  "resources/js/Pages/Users/Edit.jsx": {
    file: "assets/Edit-16edc38a.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bbe377af.js",
      "_TextAreaInput-4e2542b0.js",
      "_TextInput-ecc365ed.js",
      "_InputError-31af6c75.js",
      "_PrimaryButton-9af796e2.js",
      "_DangerButton-dbdeca01.js",
      "_SelectInput-f53d1795.js",
      "_WarningButton-452bc730.js",
      "_Modal-a9b1f5bb.js",
      "_useMemorable-60c867db.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_Icon-c058f063.js",
      "_transition-2fe1e5c3.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Edit.jsx"
  },
  "resources/js/Pages/Users/Index.jsx": {
    file: "assets/Index-93a072da.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bbe377af.js",
      "_Pagination-11223612.js",
      "_TextInput-ecc365ed.js",
      "_useMemorable-60c867db.js",
      "_ApplicationLogo-11d7c1ac.js",
      "_Icon-c058f063.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Index.jsx"
  },
  "resources/js/Pages/Users/Partials/DeleteUserForm.jsx": {
    file: "assets/DeleteUserForm-445c1b91.js",
    imports: [
      "resources/js/app.jsx",
      "_DangerButton-dbdeca01.js",
      "_InputError-31af6c75.js",
      "_InputLabel-0210d3ef.js",
      "_Modal-a9b1f5bb.js",
      "_SecondaryButton-9256dc99.js",
      "_TextInput-ecc365ed.js",
      "_transition-2fe1e5c3.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Partials/DeleteUserForm.jsx"
  },
  "resources/js/Pages/Users/Partials/UpdatePasswordForm.jsx": {
    file: "assets/UpdatePasswordForm-b484c735.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-31af6c75.js",
      "_InputLabel-0210d3ef.js",
      "_PrimaryButton-9af796e2.js",
      "_TextInput-ecc365ed.js",
      "_transition-2fe1e5c3.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Partials/UpdatePasswordForm.jsx"
  },
  "resources/js/Pages/Users/Partials/UpdateProfileInformationForm.jsx": {
    file: "assets/UpdateProfileInformationForm-b95a09cd.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-31af6c75.js",
      "_InputLabel-0210d3ef.js",
      "_PrimaryButton-9af796e2.js",
      "_TextInput-ecc365ed.js",
      "_transition-2fe1e5c3.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Partials/UpdateProfileInformationForm.jsx"
  },
  "resources/js/Pages/Welcome.jsx": {
    file: "assets/Welcome-0efcec9d.js",
    imports: [
      "resources/js/app.jsx",
      "_ApplicationLogo-11d7c1ac.js",
      "_Icon-c058f063.js",
      "_PrimaryButton-9af796e2.js",
      "_index-b178287a.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Welcome.jsx"
  },
  "resources/js/app.css": {
    file: "assets/app-22606b18.css",
    src: "resources/js/app.css"
  },
  "resources/js/app.jsx": {
    assets: [
      "assets/Dana-Hairline-7712cf11.woff2",
      "assets/Dana-Hairline-6d7bb084.woff",
      "assets/Dana-Thin-bec2bd8a.woff2",
      "assets/Dana-Thin-56dc1e1f.woff",
      "assets/Dana-UltraLight-24615a03.woff2",
      "assets/Dana-UltraLight-a025f30e.woff",
      "assets/Dana-Light-e07a4868.woff2",
      "assets/Dana-Light-eeed4155.woff",
      "assets/Dana-Medium-d623f857.woff2",
      "assets/Dana-Medium-d0241b30.woff",
      "assets/Dana-DemiBold-34870445.woff2",
      "assets/Dana-DemiBold-fa427dcf.woff",
      "assets/Dana-ExtraBold-08dea612.woff2",
      "assets/Dana-ExtraBold-0d7888d7.woff",
      "assets/Dana-Black-cdfe2203.woff2",
      "assets/Dana-Black-575de1e5.woff",
      "assets/Dana-ExtraBlack-3208afe0.woff2",
      "assets/Dana-ExtraBlack-6c729c23.woff",
      "assets/Dana-Heavy-091eb261.woff2",
      "assets/Dana-Heavy-e159608a.woff",
      "assets/Dana-Fat-1f7b7061.woff2",
      "assets/Dana-Fat-8831a7f0.woff",
      "assets/Dana-Regular-43506011.woff2",
      "assets/Dana-Regular-eee25c04.woff"
    ],
    css: [
      "assets/app-22606b18.css"
    ],
    dynamicImports: [
      "resources/js/Pages/Accessories/Components/ProductsSlider.jsx",
      "_Create-99eb5a9e.js",
      "resources/js/Pages/Accessories/Index.jsx",
      "resources/js/Pages/Accessories/Show.jsx",
      "_Create-99eb5a9e.js",
      "_Create-99eb5a9e.js",
      "resources/js/Pages/Admin/Accessories.jsx",
      "resources/js/Pages/Admin/Records.jsx",
      "resources/js/Pages/Auth/Address.jsx",
      "resources/js/Pages/Auth/ConfirmPassword.jsx",
      "resources/js/Pages/Auth/ForgotPassword.jsx",
      "resources/js/Pages/Auth/Info.jsx",
      "resources/js/Pages/Auth/Login.jsx",
      "resources/js/Pages/Auth/Register.jsx",
      "resources/js/Pages/Auth/ResetPassword.jsx",
      "resources/js/Pages/Auth/VerifyEmail.jsx",
      "resources/js/Pages/Auth/WaitForVerify.jsx",
      "resources/js/Pages/Dashboards/Admin.jsx",
      "resources/js/Pages/Dashboards/User.jsx",
      "resources/js/Pages/Download/Accessory.jsx",
      "resources/js/Pages/Download/Record.jsx",
      "resources/js/Pages/Patients/Create.jsx",
      "resources/js/Pages/Patients/Edit.jsx",
      "resources/js/Pages/Patients/Index.jsx",
      "resources/js/Pages/Patients/Partials/DeleteUserForm.jsx",
      "resources/js/Pages/Patients/Partials/UpdatePasswordForm.jsx",
      "resources/js/Pages/Patients/Partials/UpdateProfileInformationForm.jsx",
      "resources/js/Pages/Products/CreateOrEdit.jsx",
      "resources/js/Pages/Products/Index.jsx",
      "resources/js/Pages/Profile/Edit.jsx",
      "resources/js/Pages/Profile/Index.jsx",
      "_AidInputs-fa479c6d.js",
      "resources/js/Pages/Records/Components/ProductsSlider.jsx",
      "resources/js/Pages/Records/Components/Steps.jsx",
      "_AidInputs-fa479c6d.js",
      "resources/js/Pages/Records/Index.jsx",
      "resources/js/Pages/Records/Partials/Step.jsx",
      "resources/js/Pages/Records/Show.jsx",
      "_AidInputs-fa479c6d.js",
      "_AidInputs-fa479c6d.js",
      "_AidInputs-fa479c6d.js",
      "_AidInputs-fa479c6d.js",
      "_AidInputs-fa479c6d.js",
      "resources/js/Pages/Settings/CreateOrEdit.jsx",
      "resources/js/Pages/Settings/Index.jsx",
      "resources/js/Pages/Settings/OffLimits.jsx",
      "resources/js/Pages/Settings/OutOfSchedule.jsx",
      "resources/js/Pages/Terms.jsx",
      "resources/js/Pages/Users/Create.jsx",
      "resources/js/Pages/Users/Edit.jsx",
      "resources/js/Pages/Users/Index.jsx",
      "resources/js/Pages/Users/Partials/DeleteUserForm.jsx",
      "resources/js/Pages/Users/Partials/UpdatePasswordForm.jsx",
      "resources/js/Pages/Users/Partials/UpdateProfileInformationForm.jsx",
      "resources/js/Pages/Welcome.jsx"
    ],
    file: "assets/app-d2fe3a09.js",
    isEntry: true,
    src: "resources/js/app.jsx"
  }
};
export {
  manifest as m
};
