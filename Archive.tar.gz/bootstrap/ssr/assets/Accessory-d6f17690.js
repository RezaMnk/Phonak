import { j as jsxs, a as jsx } from "../ssr.js";
import { Head } from "@inertiajs/react";
import { useState, useEffect } from "react";
import { m as manifest } from "./manifest-4c270512.js";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
function Record({ accessory }) {
  const [first, setFirst] = useState(true);
  useEffect(() => {
    if (first) {
      let inlineExternalScriptsAndStyles = function() {
        const modulePreloadTags = Array.from(document.querySelectorAll('link[rel="modulepreload"][href]'));
        const scriptTags = Array.from(document.querySelectorAll("script[src]"));
        modulePreloadTags.forEach((modulePreloadTag) => modulePreloadTag.remove());
        scriptTags.forEach((scriptTag) => scriptTag.remove());
        const cssFilename = manifest["resources/js/app.jsx"].css[0];
        const cssUrl = `${document.location.origin}/build/${cssFilename}`;
        fetch(cssUrl).then((response) => response.text()).then((cssData) => {
          document.getElementById("local-css").innerHTML = cssData;
          const modifiedHtml = document.documentElement.outerHTML;
          const blob = new Blob([modifiedHtml], { type: "text/html" });
          const url = URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = url;
          a.download = "سفارش لوازم جانبی شماره " + accessory.id + ".html";
          a.click();
          window.close();
        }).catch((error) => {
          console.error("Error fetching CSS:", error);
        });
      };
      inlineExternalScriptsAndStyles();
    }
    return setFirst(false);
  }, []);
  const shipping_types = {
    "terminal": "ترمینالی",
    "air": "هوایی",
    "tipax": "تیپاکس",
    "post": "پست",
    "co-worker delivery": "تحویل به پیک همکار",
    "company delivery": "ارسال با پیک شرکت",
    "etc": "سایر"
  };
  const brands = {
    "phonak": "فوناک",
    "hansaton": "هنزاتون",
    "unitron": "یونیترون",
    "rayovac": "ریوواک",
    "detax": "دیتاکس",
    "etc": "سایر"
  };
  return /* @__PURE__ */ jsxs("div", { className: "min-h-screen items-center flex bg-gray-100 p-24 print:p-4", children: [
    /* @__PURE__ */ jsx(Head, { title: "نمایش سفارش" }),
    /* @__PURE__ */ jsx("style", { type: "text/css", id: "local-css" }),
    /* @__PURE__ */ jsx("div", { className: "w-full flex flex-col sm:justify-center items-center", children: /* @__PURE__ */ jsx("div", { className: "w-full px-6 py-4 bg-white dark:bg-slate-800 border border-white dark:border-slate-600 sm:rounded-lg", children: /* @__PURE__ */ jsxs("div", { className: "w-full text-gray-700 dark:text-slate-200", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("h5", { children: "محصول مورد سفارش" }),
        /* @__PURE__ */ jsx("hr", { className: "dark:border-slate-600" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-5 xl:mt-8", children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: "inline-block print:hidden min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
            "برند"
          ] }),
          /* @__PURE__ */ jsxs("p", { className: "mt-2", children: [
            brands[accessory.product.brand],
            accessory.product.brand === "etc" && " - " + accessory.product.etc_brand
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: "inline-block print:hidden min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
            "نام محصول"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: accessory.product.name })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: "inline-block print:hidden min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
            "کد IRC"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: accessory.product.irc ? accessory.product.irc : "-" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mt-12", children: [
        /* @__PURE__ */ jsx("h5", { children: "نحوه ارسال" }),
        /* @__PURE__ */ jsx("hr", { className: "dark:border-slate-600" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-6", children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
            "تلفن همراه شنوایی شناس جهت ارسال صورتحساب"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: accessory.shipping.expert_phone })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
            "شیوه ارسال"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: shipping_types[accessory.shipping.type] })
        ] }),
        accessory.shipping.type === "etc" && /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-2/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
            "توضیحات شیوه ارسال"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: accessory.shipping.etc_delivery })
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "flex mt-6", children: /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3", children: [
        /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
          /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
          "آدرس ارسال محصول"
        ] }),
        /* @__PURE__ */ jsxs("p", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-5 xl:mt-2", children: [
          /* @__PURE__ */ jsx("span", { className: "inline-block", children: accessory.shipping.address.address }),
          /* @__PURE__ */ jsxs("span", { className: "inline-block xl:mr-5 xl:pr-5 xl:border-r border-gray-300 dark:border-slate-600", children: [
            "کدپستی: ",
            accessory.shipping.address.post_code
          ] }),
          accessory.shipping.address.phone && /* @__PURE__ */ jsxs(
            "span",
            {
              className: "inline-block xl:mr-5 xl:pr-5 xl:border-r border-gray-300 dark:border-slate-600",
              children: [
                "تلفن: ",
                accessory.shipping.address.phone
              ]
            }
          )
        ] })
      ] }) }),
      accessory.shipping.description && /* @__PURE__ */ jsx("div", { className: "flex mt-6", children: /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3", children: [
        /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
          /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-sky-400 dark:bg-sky-600" }),
          "توضیحات"
        ] }),
        /* @__PURE__ */ jsx("p", { className: "mt-2", children: accessory.shipping.description })
      ] }) })
    ] }) }) })
  ] });
}
export {
  Record as default
};
