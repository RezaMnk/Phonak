import { j as jsxs, a as jsx } from "../ssr.js";
import { A as Authenticated } from "./AuthenticatedLayout-5fd2cf47.js";
import { Head } from "@inertiajs/react";
import { P as PrimaryButton } from "./PrimaryButton-6a55fe23.js";
import { Player } from "@lottiefiles/react-lottie-player";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "react-toastify";
import "./useMemorable-ea291d99.js";
import "react";
import "./ApplicationLogo-40648ed6.js";
import "./Icon-2f3a2698.js";
function OffLimits({ limit }) {
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      header: "تکمیل ظرفیت",
      children: [
        /* @__PURE__ */ jsx(Head, { title: "تکمیل ظرفیت" }),
        /* @__PURE__ */ jsxs("div", { className: "w-full text-center text-gray-700 dark:text-slate-300", children: [
          /* @__PURE__ */ jsx(
            Player,
            {
              autoplay: true,
              loop: true,
              src: "/storage/animations/warning.json",
              style: { height: "300px" }
            }
          ),
          /* @__PURE__ */ jsx("h4", { className: "font-bold text-lg", children: "اتمام ظرفیت سفارش گذاری" }),
          /* @__PURE__ */ jsx("p", { className: "px-40 mt-5 mb-12", children: "ظرفیت سفارش گذاری شما به اتمام رسیده است. لطفا جهت سفارش گذاری، از دوره بعدی اقدام نمایید." }),
          /* @__PURE__ */ jsxs("p", { className: "px-40 mt-5 mb-12 font-semibold", children: [
            "تعداد سفارشات شما:",
            /* @__PURE__ */ jsx("span", { className: "mr-2", children: limit })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "flex justify-center", children: /* @__PURE__ */ jsx(
            PrimaryButton,
            {
              className: "w-3/12 ml-5 !px-4 !py-2",
              link: true,
              href: route("records.index"),
              children: "بازگشت به صفحه سفارشات"
            }
          ) })
        ] })
      ]
    }
  );
}
export {
  OffLimits as default
};
