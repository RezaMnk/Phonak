import { j as jsxs, a as jsx, F as Fragment } from "../ssr.js";
import { Link } from "@inertiajs/react";
function Pagination({ data, search = "" }) {
  const { links, from, to, total } = data;
  return links.length > 3 && /* @__PURE__ */ jsxs("div", { className: "mb-4 mt-8", children: [
    /* @__PURE__ */ jsxs("p", { className: "text-xs text-gray-500 dark:text-slate-300", children: [
      "نمایش",
      /* @__PURE__ */ jsx("span", { className: "mx-1", children: from }),
      "تا",
      /* @__PURE__ */ jsx("span", { className: "mx-1", children: to }),
      "از",
      /* @__PURE__ */ jsx("span", { className: "mx-1", children: total })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "flex flex-wrap gap-2 mt-2", children: links.map((link, key) => {
      const is_prev_next = () => [0, Object.keys(links).length - 1].includes(key);
      return /* @__PURE__ */ jsx("div", { children: link.url === null ? /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx(
          "div",
          {
            className: `${is_prev_next() ? "px-4 flex" : "w-8 hidden xl:flex"} h-8 cursor-default items-center justify-center text-sm leading-4 bg-gray-200 dark:bg-slate-900 text-gray-400 dark:text-slate-500 rounded`,
            children: link.label
          }
        ),
        /* @__PURE__ */ jsx("div", { className: `${is_prev_next() ? "hidden" : "block xl:hidden"} h-8 w-[2px] bg-gray-200 dark:bg-slate-900 rounded-lg` })
      ] }) : link.active ? /* @__PURE__ */ jsx(
        "div",
        {
          className: "w-8 h-8 flex items-center justify-center text-sm cursor-pointer leading-4 bg-sky-500 dark:bg-sky-700 rounded text-white",
          children: link.label
        }
      ) : /* @__PURE__ */ jsx(
        Link,
        {
          className: `${is_prev_next() ? "px-4" : "w-8"} h-8 flex items-center justify-center text-sm leading-4 bg-white dark:bg-slate-700 dark:text-slate-100 rounded hover:bg-gray-200/70 dark:hover:bg-slate-600 focus:outline-none focus:ring-sky-500 focus:ring-2`,
          href: search ? link.url + "&search=" + search : link.url,
          children: link.label
        }
      ) }, key);
    }) })
  ] });
}
export {
  Pagination as P
};
