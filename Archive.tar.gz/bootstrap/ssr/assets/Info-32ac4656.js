import { j as jsxs, a as jsx } from "../ssr.js";
import { G as Guest } from "./GuestLayout-ceec5b24.js";
import { I as InputError } from "./InputError-0c916dba.js";
import { P as PrimaryButton } from "./PrimaryButton-6a55fe23.js";
import { T as TextInput } from "./TextInput-ca1f9780.js";
import { useForm, Head } from "@inertiajs/react";
import { T as TextAreaInput } from "./TextAreaInput-7c309df0.js";
import { F as FileInput } from "./FileInput-f4444771.js";
import { I as InputLabel } from "./InputLabel-b9d20af6.js";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "./ApplicationLogo-40648ed6.js";
import "./useMemorable-ea291d99.js";
import "react";
import "./Icon-2f3a2698.js";
function Info() {
  const { data, setData, post, processing, errors } = useForm({
    phone: "",
    landline: "",
    whatsapp_phone: "",
    referral_name: "",
    referral_phone: "",
    second_referral_name: "",
    second_referral_phone: "",
    history_description: "",
    conditions_description: "",
    id_card_image: "",
    med_card_image: "",
    license_image: ""
  });
  const submit = (e) => {
    e.preventDefault();
    post(route("info"));
  };
  return /* @__PURE__ */ jsxs(Guest, { className: "!max-w-5xl", name: "اطلاعات تکمیلی", children: [
    /* @__PURE__ */ jsx(Head, { title: "اطلاعات تکمیلی" }),
    /* @__PURE__ */ jsxs("form", { className: "w-full h-1/2", onSubmit: submit, children: [
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0", children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-3/4 ml-12", children: [
          /* @__PURE__ */ jsxs("div", { className: "text-gray-700 dark:text-slate-200", children: [
            /* @__PURE__ */ jsx("h5", { children: "اطلاعات تماس" }),
            /* @__PURE__ */ jsx("hr", { className: "border-gray-300 dark:border-slate-600" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-3", children: [
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3 ml-5", children: [
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  id: "phone",
                  type: "number",
                  name: "phone",
                  value: data.phone,
                  label: "شماره تلفن همراه",
                  svgIcon: /* @__PURE__ */ jsxs("g", { children: [
                    /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M10 3L8 21" }),
                    /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M16 3L14 21" }),
                    /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M3.5 9H21.5" }),
                    /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M2.5 15H20.5" })
                  ] }),
                  autoComplete: "phone",
                  isFocused: true,
                  onChange: (e) => setData("phone", e.target.value),
                  error: errors.phone
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.phone, className: "mt-2" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3 ml-5", children: [
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  id: "landline",
                  type: "number",
                  name: "landline",
                  value: data.landline,
                  label: "شماره تلفن ثابت (به همراه کد شهر)",
                  svgIcon: /* @__PURE__ */ jsxs("g", { children: [
                    /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M10 3L8 21" }),
                    /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M16 3L14 21" }),
                    /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M3.5 9H21.5" }),
                    /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M2.5 15H20.5" })
                  ] }),
                  autoComplete: "landline",
                  onChange: (e) => setData("landline", e.target.value),
                  error: errors.landline
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.landline, className: "mt-2" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3", children: [
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  id: "whatsapp_phone",
                  type: "number",
                  name: "whatsapp_phone",
                  value: data.whatsapp_phone,
                  label: "شماره تلفن واتساپ",
                  svgIcon: /* @__PURE__ */ jsxs("g", { children: [
                    /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M10 3L8 21" }),
                    /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M16 3L14 21" }),
                    /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M3.5 9H21.5" }),
                    /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M2.5 15H20.5" })
                  ] }),
                  autoComplete: "whatsapp_phone",
                  onChange: (e) => setData("whatsapp_phone", e.target.value),
                  error: errors.whatsapp_phone
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.whatsapp_phone, className: "mt-2" })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "mt-16 text-gray-700 dark:text-slate-200", children: [
            /* @__PURE__ */ jsx("h5", { children: "مشخصات معرف ها" }),
            /* @__PURE__ */ jsx("hr", { className: "border-gray-300 dark:border-slate-600" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-3", children: [
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/2 ml-5", children: [
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  id: "referral_name",
                  name: "referral_name",
                  value: data.referral_name,
                  label: "نام معرف اول",
                  svgIcon: /* @__PURE__ */ jsxs("g", { children: [
                    /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M10 3L8 21" }),
                    /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M16 3L14 21" }),
                    /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M3.5 9H21.5" }),
                    /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M2.5 15H20.5" })
                  ] }),
                  autoComplete: "referral_name",
                  onChange: (e) => setData("referral_name", e.target.value),
                  error: errors.referral_name
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.referral_name, className: "mt-2" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/2", children: [
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  id: "referral_phone",
                  type: "number",
                  name: "referral_phone",
                  value: data.referral_phone,
                  label: "شماره تلفن معرف اول",
                  svgIcon: /* @__PURE__ */ jsxs("g", { children: [
                    /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M10 3L8 21" }),
                    /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M16 3L14 21" }),
                    /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M3.5 9H21.5" }),
                    /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M2.5 15H20.5" })
                  ] }),
                  autoComplete: "referral_phone",
                  onChange: (e) => setData("referral_phone", e.target.value),
                  error: errors.referral_phone
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.referral_phone, className: "mt-2" })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-3", children: [
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/2 ml-5", children: [
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  id: "second_referral_name",
                  name: "second_referral_name",
                  value: data.second_referral_name,
                  label: "نام معرف دوم",
                  svgIcon: /* @__PURE__ */ jsxs("g", { children: [
                    /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M10 3L8 21" }),
                    /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M16 3L14 21" }),
                    /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M3.5 9H21.5" }),
                    /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M2.5 15H20.5" })
                  ] }),
                  autoComplete: "second_referral_name",
                  onChange: (e) => setData("second_referral_name", e.target.value),
                  error: errors.second_referral_name
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.second_referral_name, className: "mt-2" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/2", children: [
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  id: "second_referral_phone",
                  type: "number",
                  name: "second_referral_phone",
                  value: data.second_referral_phone,
                  label: "شماره تلفن معرف دوم",
                  svgIcon: /* @__PURE__ */ jsxs("g", { children: [
                    /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M10 3L8 21" }),
                    /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M16 3L14 21" }),
                    /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M3.5 9H21.5" }),
                    /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M2.5 15H20.5" })
                  ] }),
                  autoComplete: "second_referral_phone",
                  onChange: (e) => setData("second_referral_phone", e.target.value),
                  error: errors.second_referral_phone
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.second_referral_phone, className: "mt-2" })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "mt-16 text-gray-700 dark:text-slate-200", children: [
            /* @__PURE__ */ jsx("h5", { children: "توضیحات" }),
            /* @__PURE__ */ jsx("hr", { className: "border-gray-300 dark:border-slate-600" })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "flex mt-3", children: /* @__PURE__ */ jsxs("div", { className: "w-full", children: [
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                htmlFor: "history_description",
                value: "در صورتیکه سابقه همکاری با فوناک را داشته اید، ‌لطفا شرح مختصری از آن بنویسید",
                className: "text-gray-500 dark:text-slate-400"
              }
            ),
            /* @__PURE__ */ jsx(
              TextAreaInput,
              {
                id: "history_description",
                name: "history_description",
                value: data.history_description,
                rows: "3",
                onChange: (e) => setData("history_description", e.target.value),
                error: errors.history_description
              }
            ),
            /* @__PURE__ */ jsx(InputError, { message: errors.history_description, className: "mt-2" })
          ] }) }),
          /* @__PURE__ */ jsx("div", { className: "flex mt-3", children: /* @__PURE__ */ jsxs("div", { className: "w-full", children: [
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                htmlFor: "conditions_description",
                value: "چنانچه مرکز شما دارای شرایط خاصی است که نیاز به توضیح دارد،‌خیلی مختصر اینجا مرقوم بفرمایید",
                className: "text-gray-500 dark:text-slate-400"
              }
            ),
            /* @__PURE__ */ jsx(
              TextAreaInput,
              {
                id: "conditions_description",
                name: "conditions_description",
                value: data.conditions_description,
                rows: "3",
                onChange: (e) => setData("conditions_description", e.target.value),
                error: errors.conditions_description
              }
            ),
            /* @__PURE__ */ jsx(InputError, { message: errors.conditions_description, className: "mt-2" })
          ] }) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4", children: [
          /* @__PURE__ */ jsxs("div", { className: "text-gray-700 dark:text-slate-200", children: [
            /* @__PURE__ */ jsx("h5", { children: "فایل مدارک" }),
            /* @__PURE__ */ jsx("hr", { className: "border-gray-300 dark:border-slate-600" })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "flex mt-3 w-full [&>div]:w-full", children: /* @__PURE__ */ jsx(
            FileInput,
            {
              className: "!p-4",
              name: "id_card_image",
              fileName: data.id_card_image,
              label: "تصویر واضح کارت ملی جدید (یا قدیم به همراه رسید تعویض)",
              accept: ".jpg, .jpeg",
              setData: (e) => setData("id_card_image", e.target.files[0]),
              error: errors.id_card_image
            }
          ) }),
          /* @__PURE__ */ jsx("div", { className: "flex mt-3 w-full [&>div]:w-full", children: /* @__PURE__ */ jsx(
            FileInput,
            {
              className: "!p-4",
              name: "med_card_image",
              fileName: data.med_card_image,
              label: "تصویر واضح کارت نظام پزشکی",
              accept: ".jpg, .jpeg",
              setData: (e) => setData("med_card_image", e.target.files[0]),
              error: errors.med_card_image
            }
          ) }),
          /* @__PURE__ */ jsx("div", { className: "flex mt-3 w-full [&>div]:w-full", children: /* @__PURE__ */ jsx(
            FileInput,
            {
              className: "!p-4",
              name: "license_image",
              fileName: data.license_image,
              label: "تصویر واضح مجوز فعالیت با تاریخ معتبر که هم نام دو مدرك اول باشد.",
              accept: ".jpg, .jpeg",
              setData: (e) => setData("license_image", e.target.files[0]),
              error: errors.license_image
            }
          ) })
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "mt-6", children: /* @__PURE__ */ jsx(PrimaryButton, { className: "w-full", disabled: processing, children: "ثبت آدرس" }) })
    ] })
  ] });
}
export {
  Info as default
};
