import { j as jsxs, F as Fragment, a as jsx } from "../ssr.js";
import { A as Authenticated } from "./AuthenticatedLayout-c3b08c0f.js";
import { useForm, Head } from "@inertiajs/react";
import { T as TextInput } from "./TextInput-ca1f9780.js";
import { I as InputError } from "./InputError-0c916dba.js";
import { P as PrimaryButton } from "./PrimaryButton-6a55fe23.js";
import { D as DangerButton } from "./DangerButton-d6ee3472.js";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "react-toastify";
import "./useMemorable-ea291d99.js";
import "react";
import "./ApplicationLogo-40648ed6.js";
import "./Icon-2f3a2698.js";
function CreateOrEdit({ setting }) {
  const { data, setData, patch, post, processing, errors } = useForm({
    group: (setting == null ? void 0 : setting.group) || "",
    max_record_order: (setting == null ? void 0 : setting.max_record_order) || "",
    max_accessory_order: (setting == null ? void 0 : setting.max_accessory_order) || "",
    start_time: (setting == null ? void 0 : setting.start_time_formatted) || "",
    end_time: (setting == null ? void 0 : setting.end_time_formatted) || ""
  });
  const submit = (e) => {
    e.preventDefault();
    if (setting)
      patch(route("settings.update", setting.id));
    else
      post(route("settings.store"));
  };
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      header: setting ? /* @__PURE__ */ jsxs(Fragment, { children: [
        "ویرایش تنظیم گروه بندی برای گروه ",
        setting.group
      ] }) : /* @__PURE__ */ jsx(Fragment, { children: "تنظیم جدید" }),
      breadcrumbs: {
        "تنظیمات": route("settings.index"),
        [setting ? "ویرایش تنظیم گروه بندی" : "تنظیم جدید"]: "#"
      },
      children: [
        /* @__PURE__ */ jsx(Head, { title: setting ? "ویرایش تنظیم گروه بندی" : "تنظیم جدید" }),
        /* @__PURE__ */ jsx("div", { className: "flex flex-col sm:justify-center items-center", children: /* @__PURE__ */ jsx("div", { className: "w-full px-6 py-4 bg-white dark:bg-slate-800 border border-white dark:border-slate-600 sm:rounded-lg", children: /* @__PURE__ */ jsxs("form", { className: "w-full", onSubmit: submit, children: [
          /* @__PURE__ */ jsxs("div", { className: "mt-5 text-gray-700 dark:text-slate-200", children: [
            /* @__PURE__ */ jsx("h5", { children: "اطلاعات تنظیم" }),
            /* @__PURE__ */ jsx("hr", { className: "dark:border-slate-600" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col space-y-5 mt-6 mb-5", children: [
            /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-col xl:flex-row space-y-5 xl:space-y-0 xl:space-x-5 xl:space-x-reverse", children: [
              /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/5", children: [
                /* @__PURE__ */ jsx(
                  TextInput,
                  {
                    id: "group",
                    name: "group",
                    type: "number",
                    value: data.group,
                    label: "شماره گروه",
                    svgIcon: /* @__PURE__ */ jsx("path", { d: "M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L6.832 19.82a4.5 4.5 0 01-1.897 1.13l-2.685.8.8-2.685a4.5 4.5 0 011.13-1.897L16.863 4.487zm0 0L19.5 7.125" }),
                    onChange: (e) => setData("group", e.target.value),
                    error: errors.group
                  }
                ),
                /* @__PURE__ */ jsx(InputError, { message: errors.group, className: "mt-2" })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-2/5", children: [
                /* @__PURE__ */ jsx(
                  TextInput,
                  {
                    id: "start_time",
                    name: "start_time",
                    type: "datetime-local",
                    value: data.start_time,
                    label: "شروع تاریخ سفارش گذاری",
                    onChange: (e) => setData("start_time", e.target.value),
                    error: errors.start_time
                  }
                ),
                /* @__PURE__ */ jsx(InputError, { message: errors.start_time, className: "mt-2" })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-2/5", children: [
                /* @__PURE__ */ jsx(
                  TextInput,
                  {
                    id: "end_time",
                    name: "end_time",
                    type: "datetime-local",
                    value: data.end_time,
                    label: "پایان تاریخ سفارش گذاری",
                    onChange: (e) => setData("end_time", e.target.value),
                    error: errors.end_time
                  }
                ),
                /* @__PURE__ */ jsx(InputError, { message: errors.end_time, className: "mt-2" })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-col xl:flex-row space-y-5 xl:space-y-0 xl:space-x-5 xl:space-x-reverse", children: [
              /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4", children: [
                /* @__PURE__ */ jsx(
                  TextInput,
                  {
                    id: "max_record_order",
                    name: "max_record_order",
                    type: "number",
                    value: data.max_record_order,
                    label: "حداکثر سفارش سمعک",
                    svgIcon: /* @__PURE__ */ jsx("path", { d: "M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L6.832 19.82a4.5 4.5 0 01-1.897 1.13l-2.685.8.8-2.685a4.5 4.5 0 011.13-1.897L16.863 4.487zm0 0L19.5 7.125" }),
                    onChange: (e) => setData("max_record_order", e.target.value),
                    error: errors.max_record_order
                  }
                ),
                /* @__PURE__ */ jsx(InputError, { message: errors.max_record_order, className: "mt-2" })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4", children: [
                /* @__PURE__ */ jsx(
                  TextInput,
                  {
                    id: "max_accessory_order",
                    name: "max_accessory_order",
                    type: "number",
                    value: data.max_accessory_order,
                    label: "حداکثر سفارش لوازم جانبی",
                    svgIcon: /* @__PURE__ */ jsx("path", { d: "M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L6.832 19.82a4.5 4.5 0 01-1.897 1.13l-2.685.8.8-2.685a4.5 4.5 0 011.13-1.897L16.863 4.487zm0 0L19.5 7.125" }),
                    onChange: (e) => setData("max_accessory_order", e.target.value),
                    error: errors.max_accessory_order
                  }
                ),
                /* @__PURE__ */ jsx(InputError, { message: errors.max_accessory_order, className: "mt-2" })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-6 mb-5" }),
          /* @__PURE__ */ jsxs("div", { className: "flex justify-between mt-8", children: [
            /* @__PURE__ */ jsx(
              DangerButton,
              {
                className: "!px-4 !py-2",
                link: true,
                href: route("settings.index"),
                children: "لغو"
              }
            ),
            /* @__PURE__ */ jsx(
              PrimaryButton,
              {
                className: "!px-4 !py-2",
                disabled: processing,
                children: setting ? "ثبت تغییرات" : "ذخیره تنظیم"
              }
            )
          ] })
        ] }) }) })
      ]
    }
  );
}
export {
  CreateOrEdit as default
};
