import { j as jsxs, a as jsx, F as Fragment } from "../ssr.js";
import { A as Authenticated } from "./AuthenticatedLayout-0977ce1d.js";
import { Head } from "@inertiajs/react";
import { W as WarningButton } from "./WarningButton-ea0dcf3d.js";
import { P as PrimaryButton } from "./PrimaryButton-6a55fe23.js";
import { S as SecondaryButton } from "./SecondaryButton-5e4fee1b.js";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "react-toastify";
import "./useMemorable-ea291d99.js";
import "react";
import "./ApplicationLogo-40648ed6.js";
import "./Icon-2f3a2698.js";
function Show({ accessory, user }) {
  const shipping_types = {
    "terminal": "ترمینالی",
    "air": "هوایی",
    "tipax": "تیپاکس",
    "post": "پست",
    "co-worker delivery": "تحویل به پیک همکار",
    "company delivery": "ارسال با پیک شرکت",
    "etc": "سایر"
  };
  const brands = {
    "phonak": "فوناک",
    "hansaton": "هنزاتون",
    "unitron": "یونیترون",
    "rayovac": "ریوواک",
    "detax": "دیتاکس",
    "etc": "سایر"
  };
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      header: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxs("p", { children: [
          "نمایش سفارش لوازم جانبی شماره ",
          /* @__PURE__ */ jsx("span", { children: accessory.id })
        ] }),
        /* @__PURE__ */ jsxs("span", { className: "text-lg xl:mr-3", children: [
          "شنوایی شناس: ",
          accessory.user.name
        ] }),
        accessory.status === "completed" && /* @__PURE__ */ jsx("span", { className: "text-lg text-yellow-600 dark:text-yellow-400", children: "(پرداخت نشده)" }),
        accessory.status === "paid" && /* @__PURE__ */ jsx("span", { className: "text-lg text-sky-600 dark:text-sky-400", children: "(پرداخت شده)" }),
        accessory.status === "approved" && /* @__PURE__ */ jsx("span", { className: "text-lg text-green-600 dark:text-green-400", children: "(تایید شده)" })
      ] }),
      breadcrumbs: {
        "سفارشات لوازم جانی": route("accessories.index"),
        "نمایش سفارش لوازم جانبی": "#"
      },
      headerExtra: /* @__PURE__ */ jsxs("div", { className: "flex xl:flex-row flex-col gap-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex gap-4", children: [
          /* @__PURE__ */ jsx(
            SecondaryButton,
            {
              onClick: print,
              className: "w-full xl:w-fit !px-4 !py-2 text-xs",
              children: "پرینت سفارش"
            }
          ),
          user.is_admin && /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsx(
            WarningButton,
            {
              link: true,
              href: route("admin.download_accessory", accessory.id),
              target: "_blank",
              className: "!px-4 !py-2 text-xs",
              children: "دریافت فایل سفارش"
            }
          ) })
        ] }),
        user.is_admin && accessory.status === "paid" && /* @__PURE__ */ jsx(
          PrimaryButton,
          {
            link: true,
            href: route("admin.approve_accessory", accessory.id),
            className: "!px-4 !py-2 text-xs",
            children: "تایید سفارش"
          }
        )
      ] }),
      children: [
        /* @__PURE__ */ jsx(Head, { title: "نمایش سفارش" }),
        /* @__PURE__ */ jsx("div", { className: "flex flex-col sm:justify-center items-center", children: /* @__PURE__ */ jsx("div", { className: "w-full print:h-screen px-6 py-4 bg-white dark:bg-slate-800 border border-white dark:border-slate-600 sm:rounded-lg", children: /* @__PURE__ */ jsxs("div", { className: "w-full text-gray-700 dark:text-slate-200", children: [
          /* @__PURE__ */ jsxs("div", { className: "hidden print:flex gap-2 items-center text-lg font-semibold mb-12", children: [
            /* @__PURE__ */ jsxs("p", { children: [
              "سفارش لوازم جانبی شماره ",
              /* @__PURE__ */ jsx("span", { children: accessory.id })
            ] }),
            /* @__PURE__ */ jsxs("span", { className: "text-lg xl:mr-3", children: [
              "- شنوایی شناس: ",
              accessory.user.name
            ] }),
            accessory.status === "completed" ? /* @__PURE__ */ jsx("span", { children: "(پرداخت نشده)" }) : /* @__PURE__ */ jsx("span", { children: "(پرداخت شده)" })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("h5", { children: "محصول مورد سفارش" }),
            /* @__PURE__ */ jsx("hr", { className: "dark:border-slate-600" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col print:flex-row xl:flex-row space-y-5 items-center print:space-y-0 xl:space-y-0 mt-5 xl:mt-8", children: [
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg print:px-2 print:py-1 p-3 ml-5", children: [
              /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
                /* @__PURE__ */ jsx("span", { className: "inline-block print:hidden min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
                "برند"
              ] }),
              /* @__PURE__ */ jsxs("p", { className: "mt-2", children: [
                brands[accessory.product.brand],
                accessory.product.brand === "etc" && " - " + accessory.product.etc_brand
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg print:px-2 print:py-1 p-3 ml-5", children: [
              /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
                /* @__PURE__ */ jsx("span", { className: "inline-block print:hidden min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
                "نام محصول"
              ] }),
              /* @__PURE__ */ jsx("p", { className: "mt-2", children: accessory.product.name })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg print:px-2 print:py-1 p-3", children: [
              /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
                /* @__PURE__ */ jsx("span", { className: "inline-block print:hidden min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
                "کد IRC"
              ] }),
              /* @__PURE__ */ jsx("p", { className: "mt-2", children: accessory.product.irc })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "mt-12", children: [
            /* @__PURE__ */ jsx("h5", { children: "نحوه ارسال" }),
            /* @__PURE__ */ jsx("hr", { className: "dark:border-slate-600" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col print:flex-row xl:flex-row space-y-5 items-center print:space-y-0 xl:space-y-0 mt-6", children: [
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 print:px-2 print:py-1 ml-5", children: [
              /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
                /* @__PURE__ */ jsx("span", { className: "inline-block print:hidden min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
                "تلفن همراه کارشناس جهت ارسال صورتحساب"
              ] }),
              /* @__PURE__ */ jsx("p", { className: "mt-2 print:mt-1 print:text-xs", children: accessory.shipping.expert_phone })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg print:px-2 print:py-1 p-3 ml-5", children: [
              /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
                /* @__PURE__ */ jsx("span", { className: "inline-block print:hidden min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
                "شیوه ارسال"
              ] }),
              /* @__PURE__ */ jsx("p", { className: "mt-2", children: shipping_types[accessory.shipping.type] })
            ] }),
            accessory.shipping.type === "etc" && /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-2/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg print:px-2 print:py-1 p-3", children: [
              /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
                /* @__PURE__ */ jsx("span", { className: "inline-block print:hidden min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
                "توضیحات شیوه ارسال"
              ] }),
              /* @__PURE__ */ jsx("p", { className: "mt-2", children: accessory.shipping.etc_delivery })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col print:flex-row xl:flex-row space-y-5 items-center print:space-y-0 xl:space-y-0 mt-6", children: [
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg print:px-2 print:py-1 p-3 ml-5", children: [
              /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
                /* @__PURE__ */ jsx("span", { className: "inline-block print:hidden min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
                "بیمه سلامت دارد؟"
              ] }),
              /* @__PURE__ */ jsx("p", { className: "mt-2", children: accessory.shipping.has_health_insurance ? "بله" : "خیر" })
            ] }),
            accessory.shipping.has_health_insurance === 1 && /* @__PURE__ */ jsxs(Fragment, { children: [
              /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg print:px-2 print:py-1 p-3 ml-5", children: [
                /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
                  /* @__PURE__ */ jsx("span", { className: "inline-block print:hidden min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
                  "تلفن همراه کاربر"
                ] }),
                /* @__PURE__ */ jsx("p", { className: "mt-2", children: accessory.shipping.phone })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg print:px-2 print:py-1 p-3 ml-5", children: [
                /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
                  /* @__PURE__ */ jsx("span", { className: "inline-block print:hidden min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
                  "شماره نظام پزشکی شنوایی شناس"
                ] }),
                /* @__PURE__ */ jsx("p", { className: "mt-2", children: accessory.shipping.audiologist_med_number })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg print:px-2 print:py-1 p-3 ml-5", children: [
                /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
                  /* @__PURE__ */ jsx("span", { className: "inline-block print:hidden min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
                  "شماره نظام پزشکی پزشک گوش و حلق و بینی"
                ] }),
                /* @__PURE__ */ jsx("p", { className: "mt-2", children: accessory.shipping.otolaryngologist_med_number })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg print:px-2 print:py-1 p-3", children: [
                /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
                  /* @__PURE__ */ jsx("span", { className: "inline-block print:hidden min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
                  "نوع بیمه تکمیلی"
                ] }),
                /* @__PURE__ */ jsx("p", { className: "mt-2", children: accessory.shipping.supplementary_insurance })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "flex mt-6", children: /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 print:px-2 print:py-1", children: [
            /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
              /* @__PURE__ */ jsx("span", { className: "inline-block print:hidden min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
              "آدرس ارسال محصول"
            ] }),
            /* @__PURE__ */ jsxs("p", { className: "flex flex-col print:flex-row xl:flex-row space-y-5 items-center print:space-y-0 xl:space-y-0 mt-5 xl:mt-2", children: [
              /* @__PURE__ */ jsx("span", { className: "inline-block", children: accessory.shipping.address.address }),
              /* @__PURE__ */ jsxs("span", { className: "inline-block xl:mr-5 xl:pr-5 xl:border-r print:mr-5 print:pr-5 print:border-r border-gray-300 dark:border-slate-600", children: [
                "کدپستی: ",
                accessory.shipping.address.post_code
              ] }),
              accessory.shipping.address.phone && /* @__PURE__ */ jsxs(
                "span",
                {
                  className: "inline-block xl:mr-5 xl:pr-5 xl:border-r print:mr-5 print:pr-5 print:border-r border-gray-300 dark:border-slate-600",
                  children: [
                    "تلفن: ",
                    accessory.shipping.address.phone
                  ]
                }
              )
            ] })
          ] }) }),
          accessory.shipping.description && /* @__PURE__ */ jsx("div", { className: "flex mt-6", children: /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg print:px-2 print:py-1 p-3", children: [
            /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
              /* @__PURE__ */ jsx("span", { className: "inline-block print:hidden min-h-[10px] ml-2 w-[2px] h-full bg-sky-400 dark:bg-sky-600" }),
              "توضیحات"
            ] }),
            /* @__PURE__ */ jsx("p", { className: "mt-2", children: accessory.shipping.description })
          ] }) })
        ] }) }) })
      ]
    }
  );
}
export {
  Show as default
};
