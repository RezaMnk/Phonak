import { a as jsx } from "../ssr.js";
function InputError({ message, className = "", ...props }) {
  return message ? /* @__PURE__ */ jsx("p", { ...props, className: "mt-3 text-xs text-red-400 " + className, children: message }) : null;
}
export {
  InputError as I
};
