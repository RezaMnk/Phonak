import { j as jsxs, a as jsx } from "../ssr.js";
import { G as Guest } from "./GuestLayout-ceec5b24.js";
import { I as InputError } from "./InputError-0c916dba.js";
import { P as PrimaryButton } from "./PrimaryButton-6a55fe23.js";
import { T as TextInput } from "./TextInput-ca1f9780.js";
import { useForm, Head, Link } from "@inertiajs/react";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "./ApplicationLogo-40648ed6.js";
import "./useMemorable-ea291d99.js";
import "react";
function ForgotPassword({ status }) {
  const { data, setData, post, processing, errors } = useForm({
    email: ""
  });
  const submit = (e) => {
    e.preventDefault();
    post(route("password.email"));
  };
  return /* @__PURE__ */ jsxs(Guest, { name: "بازیابی کلمه عبور", children: [
    /* @__PURE__ */ jsx(Head, { title: "بازیابی کلمه عبور" }),
    status && /* @__PURE__ */ jsx("div", { className: "mb-4 font-medium text-sm text-sky-600", children: status }),
    /* @__PURE__ */ jsxs("form", { onSubmit: submit, children: [
      /* @__PURE__ */ jsxs("div", { className: "block mt-5", children: [
        /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "email",
            name: "email",
            label: "ایمیل",
            value: data.email,
            svgIcon: /* @__PURE__ */ jsx("path", { d: "M21 8L17.4392 9.97822C15.454 11.0811 14.4614 11.6326 13.4102 11.8488C12.4798 12.0401 11.5202 12.0401 10.5898 11.8488C9.53864 11.6326 8.54603 11.0811 6.5608 9.97822L3 8M6.2 19H17.8C18.9201 19 19.4802 19 19.908 18.782C20.2843 18.5903 20.5903 18.2843 20.782 17.908C21 17.4802 21 16.9201 21 15.8V8.2C21 7.0799 21 6.51984 20.782 6.09202C20.5903 5.71569 20.2843 5.40973 19.908 5.21799C19.4802 5 18.9201 5 17.8 5H6.2C5.0799 5 4.51984 5 4.09202 5.21799C3.71569 5.40973 3.40973 5.71569 3.21799 6.09202C3 6.51984 3 7.07989 3 8.2V15.8C3 16.9201 3 17.4802 3.21799 17.908C3.40973 18.2843 3.71569 18.5903 4.09202 18.782C4.51984 19 5.07989 19 6.2 19Z" }),
            onChange: (e) => setData("email", e.target.value),
            error: errors.email
          }
        ),
        /* @__PURE__ */ jsx(InputError, { message: errors.email, className: "mt-2" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mt-6", children: [
        /* @__PURE__ */ jsx(PrimaryButton, { className: "w-full", disabled: processing, children: "ارسال لینک بازیابی" }),
        /* @__PURE__ */ jsx("div", { className: "mt-6 text-center", children: /* @__PURE__ */ jsx(
          Link,
          {
            href: route("login"),
            className: "text-sm text-blue-950 dark:text-blue-300 hover:underline",
            children: "بازگشت به ورود"
          }
        ) })
      ] })
    ] })
  ] });
}
export {
  ForgotPassword as default
};
