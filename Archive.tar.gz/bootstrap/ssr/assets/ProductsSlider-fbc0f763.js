import { a as jsx, j as jsxs } from "../ssr.js";
import { Pagination } from "swiper";
import { Swiper, SwiperSlide } from "swiper/react";
import { R as RadioInput } from "./RadioInput-a6c65c03.js";
import { I as InputLabel } from "./InputLabel-b9d20af6.js";
/* empty css                     */import { C as CheckboxInput } from "./CheckboxInput-b35e3493.js";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react";
import "@inertiajs/react/server";
import "react";
const ProductsSlider = ({ products, product: selected_product, setProduct, setProductItems, productItems, productsItems, error }) => {
  return /* @__PURE__ */ jsx(
    Swiper,
    {
      pagination: {
        dynamicBullets: true,
        bulletClass: "bg-gray-300 dark:bg-slate-200 swiper-pagination-bullet"
      },
      modules: [Pagination],
      spaceBetween: 30,
      breakpoints: {
        576: {
          slidesPerView: 3
        },
        768: {
          slidesPerView: 5
        }
      },
      initialSlide: selected_product - 3 || 0,
      children: Object.values(products).map((product, key) => /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsxs(SwiperSlide, { children: [
          /* @__PURE__ */ jsx(
            RadioInput,
            {
              id: `product-` + product.id,
              className: "hidden peer",
              name: "product",
              checked: selected_product === product.id,
              onChange: () => setProduct(product.id)
            }
          ),
          /* @__PURE__ */ jsx(
            InputLabel,
            {
              htmlFor: `product-` + product.id,
              className: `w-full bg-gray-100 dark:bg-slate-700 peer-checked:bg-sky-100 peer-checked:dark:bg-sky-900 cursor-pointer border ${error ? "border-red-200 dark:border-red-800" : "border-gray-200 dark:border-slate-500"} border-2 rounded-lg peer-checked:border-sky-400`,
              children: /* @__PURE__ */ jsxs("div", { className: "p-2", children: [
                /* @__PURE__ */ jsx("img", { src: product.image_url, loading: "lazy", alt: product.id, className: "rounded-lg h-full w-full object-cover" }),
                /* @__PURE__ */ jsx("hr", { className: "my-2 border-gray-200 dark:border-slate-500" }),
                /* @__PURE__ */ jsxs("p", { className: "text-center text-xs font-bold", children: [
                  product.price.toLocaleString(),
                  " ریال"
                ] }),
                /* @__PURE__ */ jsx("hr", { className: "my-2 border-gray-200 dark:border-slate-500" }),
                /* @__PURE__ */ jsx("p", { className: "text-center", children: product.name }),
                /* @__PURE__ */ jsx("hr", { className: "my-2 border-gray-200 dark:border-slate-500" }),
                /* @__PURE__ */ jsxs("p", { className: "text-center text-xs", children: [
                  /* @__PURE__ */ jsx("bdi", { className: "ml-1", children: "کد IRC:" }),
                  product.irc
                ] })
              ] })
            }
          )
        ] }, key),
        selected_product === product.id && product.has_package && /* @__PURE__ */ jsxs(SwiperSlide, { children: [
          /* @__PURE__ */ jsx(
            CheckboxInput,
            {
              id: `product-package-` + product.id,
              className: "hidden peer",
              name: "product_package",
              checked: productItems.includes("package"),
              onChange: (e) => {
                if (e.target.checked) {
                  setProductItems([...productItems, "package"]);
                } else {
                  setProductItems(productItems.filter((item) => item !== "package"));
                }
              }
            }
          ),
          /* @__PURE__ */ jsx(
            InputLabel,
            {
              htmlFor: `product-package-` + product.id,
              className: `w-full bg-yellow-50 dark:bg-yellow-800/20 peer-checked:bg-yellow-200 peer-checked:dark:bg-yellow-900 cursor-pointer border ${error ? "border-red-200 dark:border-red-800" : "border-yellow-200 dark:border-yellow-700"} border-2 rounded-lg peer-checked:border-yellow-400`,
              children: /* @__PURE__ */ jsxs("div", { className: "p-2", children: [
                /* @__PURE__ */ jsx("img", { src: product.image_url, loading: "lazy", alt: product.id, className: "rounded-lg h-full w-full object-cover" }),
                /* @__PURE__ */ jsx("hr", { className: "my-2 border-yellow-200 dark:border-yellow-700" }),
                /* @__PURE__ */ jsxs("p", { className: "text-center text-xs font-bold", children: [
                  product.package_price.toLocaleString(),
                  " ریال"
                ] }),
                /* @__PURE__ */ jsx("hr", { className: "my-2 border-yellow-200 dark:border-yellow-700" }),
                /* @__PURE__ */ jsxs("p", { className: "text-center", children: [
                  "پکیج سمعک ",
                  product.name
                ] })
              ] })
            }
          )
        ] }, "package-" + key),
        selected_product === product.id && product.has_mold && /* @__PURE__ */ jsxs(SwiperSlide, { children: [
          /* @__PURE__ */ jsx(
            CheckboxInput,
            {
              id: `product-mold-` + product.id,
              className: "hidden peer",
              name: "product_mold",
              checked: productItems.includes("mold"),
              onChange: (e) => {
                if (e.target.checked) {
                  setProductItems([...productItems, "mold"]);
                } else {
                  setProductItems(productItems.filter((item) => item !== "mold"));
                }
              }
            }
          ),
          /* @__PURE__ */ jsx(
            InputLabel,
            {
              htmlFor: `product-mold-` + product.id,
              className: `w-full bg-green-50 dark:bg-green-800/20 peer-checked:bg-green-200 peer-checked:dark:bg-green-900 cursor-pointer border ${error ? "border-red-200 dark:border-red-800" : "border-green-200 dark:border-green-700"} border-2 rounded-lg peer-checked:border-green-400`,
              children: /* @__PURE__ */ jsxs("div", { className: "p-2", children: [
                /* @__PURE__ */ jsx("img", { src: product.image_url, loading: "lazy", alt: product.id, className: "rounded-lg h-full w-full object-cover" }),
                /* @__PURE__ */ jsx("hr", { className: "my-2 border-green-200 dark:border-green-700" }),
                /* @__PURE__ */ jsxs("p", { className: "text-center text-xs font-bold", children: [
                  product.mold_price.toLocaleString(),
                  " ریال"
                ] }),
                /* @__PURE__ */ jsx("hr", { className: "my-2 border-green-200 dark:border-green-700" }),
                /* @__PURE__ */ jsxs("p", { className: "text-center", children: [
                  "قالب سمعک ",
                  product.name
                ] })
              ] })
            }
          )
        ] }, "mold-" + key),
        selected_product === product.id && product.has_charger && /* @__PURE__ */ jsxs(SwiperSlide, { children: [
          /* @__PURE__ */ jsx(
            CheckboxInput,
            {
              id: `product-charger-` + product.id,
              className: "hidden peer",
              name: "product_charger",
              checked: productItems.includes("charger"),
              onChange: (e) => {
                if (e.target.checked) {
                  setProductItems([...productItems, "charger"]);
                } else {
                  setProductItems(productItems.filter((item) => item !== "charger"));
                }
              }
            }
          ),
          /* @__PURE__ */ jsx(
            InputLabel,
            {
              htmlFor: `product-charger-` + product.id,
              className: `w-full bg-violet-50 dark:bg-violet-800/20 peer-checked:bg-violet-200 peer-checked:dark:bg-violet-900 cursor-pointer border ${error ? "border-red-200 dark:border-red-800" : "border-violet-200 dark:border-violet-700"} border-2 rounded-lg peer-checked:border-violet-400`,
              children: /* @__PURE__ */ jsxs("div", { className: "p-2", children: [
                /* @__PURE__ */ jsx("img", { src: product.image_url, loading: "lazy", alt: product.id, className: "rounded-lg h-full w-full object-cover" }),
                /* @__PURE__ */ jsx("hr", { className: "my-2 border-violet-200 dark:border-violet-700" }),
                /* @__PURE__ */ jsxs("p", { className: "text-center text-xs font-bold", children: [
                  product.charger_price.toLocaleString(),
                  " ریال"
                ] }),
                /* @__PURE__ */ jsx("hr", { className: "my-2 border-violet-200 dark:border-violet-700" }),
                /* @__PURE__ */ jsxs("p", { className: "text-center", children: [
                  "شارژر سمعک ",
                  product.name
                ] })
              ] })
            }
          )
        ] }, "charger-" + key)
      ] }, "div-" + key))
    }
  );
};
export {
  ProductsSlider as default
};
