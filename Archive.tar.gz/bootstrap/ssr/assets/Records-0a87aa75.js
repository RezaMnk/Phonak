import { j as jsxs, a as jsx } from "../ssr.js";
import { A as Authenticated } from "./AuthenticatedLayout-9f77c606.js";
import { router, Head, Link } from "@inertiajs/react";
import { P as Pagination } from "./Pagination-7f5980b7.js";
import { T as TextInput } from "./TextInput-ca1f9780.js";
import { useState, useEffect } from "react";
import { u as useFirstRender } from "./useFirstRender-5b0e5bdf.js";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "react-toastify";
import "./useMemorable-ea291d99.js";
import "./ApplicationLogo-40648ed6.js";
import "./Icon-2f3a2698.js";
function Index({ records }) {
  const [search, setSearch] = useState(new URLSearchParams(window.location.search).get("search") || "");
  const firstRender = useFirstRender();
  useEffect(() => {
    if (!firstRender) {
      const delayDebounceFn = setTimeout(() => {
        router.get(route("admin.records"), {
          search
        });
      }, 1500);
      return () => clearTimeout(delayDebounceFn);
    }
  }, [search]);
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      header: "سفارشات سمعک",
      breadcrumbs: {
        "سفارشات سمعک": route("admin.records")
      },
      headerExtra: /* @__PURE__ */ jsx("form", { id: "search", children: /* @__PURE__ */ jsx(
        TextInput,
        {
          id: "search-input",
          name: "search",
          value: search,
          label: "جستوجو...",
          className: "!py-2 !px-4",
          autoComplete: "name",
          onChange: (e) => setSearch(e.target.value),
          isFocused: !!search
        }
      ) }),
      children: [
        /* @__PURE__ */ jsx(Head, { title: "سفارشات سمعک" }),
        /* @__PURE__ */ jsx("div", { className: "relative overflow-x-auto rounded-lg", children: /* @__PURE__ */ jsxs("table", { className: "w-full text-right text-gray-500 dark:text-slate-400", children: [
          /* @__PURE__ */ jsx("thead", { className: "text-xs text-gray-700 dark:text-gray-300 bg-gray-50 dark:bg-slate-700", children: /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx("th", { scope: "col", className: "px-6 py-3", children: "شماره سفارش" }),
            /* @__PURE__ */ jsx("th", { scope: "col", className: "px-6 py-3", children: "همکار" }),
            /* @__PURE__ */ jsx("th", { scope: "col", className: "px-6 py-3", children: "کاربر" }),
            /* @__PURE__ */ jsx("th", { scope: "col", className: "px-6 py-3", children: "برند" }),
            /* @__PURE__ */ jsx("th", { scope: "col", className: "px-6 py-3", children: "نوع سفارش" }),
            /* @__PURE__ */ jsx("th", { scope: "col", className: "px-6 py-3", children: "وضعیت" }),
            /* @__PURE__ */ jsx("th", { scope: "col", className: "px-6 py-3", children: "عملیات" })
          ] }) }),
          /* @__PURE__ */ jsx("tbody", { children: Object.keys(records.data).length ? Object.values(records.data).map((record) => {
            const is_last = records.data[Object.keys(records.data).length - 1] === record;
            return /* @__PURE__ */ jsxs("tr", { className: `bg-white text-gray-700 dark:text-slate-300 dark:bg-slate-900 ${!is_last ? "border-b" : ""} border-gray-200 dark:border-slate-600`, children: [
              /* @__PURE__ */ jsx(
                "th",
                {
                  scope: "row",
                  className: "px-6 py-4",
                  children: record.id
                }
              ),
              /* @__PURE__ */ jsx("td", { className: "px-6 py-4 font-medium", children: record.user.name }),
              /* @__PURE__ */ jsx("td", { className: "px-6 py-4 font-medium", children: record.patient.name }),
              /* @__PURE__ */ jsx("td", { className: "px-6 py-4", children: record.brand }),
              /* @__PURE__ */ jsx("td", { className: "px-6 py-4", children: record.type }),
              /* @__PURE__ */ jsxs("td", { className: "px-6 py-4", children: [
                record.status === "completed" && /* @__PURE__ */ jsx("span", { className: "inline-flex whitespace-nowrap items-center rounded-md bg-yellow-50 dark:bg-yellow-500/30 px-2 py-1 text-sm font-medium text-yellow-800 dark:text-yellow-300/70 ring-1 ring-inset ring-yellow-600/20", children: "در انتظار پرداخت" }),
                record.status === "paid" && /* @__PURE__ */ jsx("span", { className: "inline-flex whitespace-nowrap items-center rounded-md bg-sky-50 dark:bg-sky-500/30 px-2 py-1 text-sm font-medium text-sky-800 dark:text-sky-300/70 ring-1 ring-inset ring-sky-600/20", children: "پرداخت شده" }),
                record.status === "approved" && /* @__PURE__ */ jsx("span", { className: "inline-flex whitespace-nowrap items-center rounded-md bg-green-50 dark:bg-green-500/30 px-2 py-1 text-sm font-medium text-green-800 dark:text-green-300/70 ring-1 ring-inset ring-green-600/20", children: "تایید شده" })
              ] }),
              /* @__PURE__ */ jsx("td", { className: "px-6 py-4", children: /* @__PURE__ */ jsx(
                Link,
                {
                  href: route("records.show", [record.id]),
                  className: "inline-flex px-2 py-1 text-xs text-center text-sky-900 dark:text-sky-200 transition-colors duration-300 bg-sky-100 dark:bg-sky-600/50 border border-sky-200 dark:border-sky-800 rounded-lg hover:bg-sky-200 dark:hover:bg-sky-600 focus:outline-none focus:ring-0 focus:border-sky-500",
                  children: "نمایش"
                }
              ) })
            ] }, record.id);
          }) : /* @__PURE__ */ jsx("tr", { className: "bg-white text-gray-700 dark:text-slate-300 dark:bg-slate-900", children: /* @__PURE__ */ jsx(
            "th",
            {
              scope: "row",
              colSpan: "7",
              className: "text-lg px-6 py-6",
              children: "هیچ سفارشی یافت نشد!"
            }
          ) }) })
        ] }) }),
        /* @__PURE__ */ jsx(Pagination, { data: records, search })
      ]
    }
  );
}
export {
  Index as default
};
