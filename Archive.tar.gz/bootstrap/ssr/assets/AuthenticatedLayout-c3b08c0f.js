import { j as jsxs, a as jsx, F as Fragment } from "../ssr.js";
import { toast, ToastContainer } from "react-toastify";
import { u as useMemorable } from "./useMemorable-ea291d99.js";
import { Children, isValidElement, cloneElement, useState, useEffect } from "react";
import { Link, usePage } from "@inertiajs/react";
import { A as ApplicationLogo } from "./ApplicationLogo-40648ed6.js";
import { I as Icon } from "./Icon-2f3a2698.js";
const main = "";
function NavLink({ className = "", name = "", minimize, icon = /* @__PURE__ */ jsx(Fragment, {}), active = false, ...props }) {
  const modifiedIcon = Children.map(icon, (child) => {
    if (isValidElement(child)) {
      return cloneElement(child, {
        className: icon.props.className + ` ${active ? "text-white" : ""}`
      });
    }
    return child;
  });
  return /* @__PURE__ */ jsxs(
    Link,
    {
      ...props,
      className: "flex items-center px-3 py-2 text-gray-600 transition-colors duration-300 transform rounded-lg " + (active ? "bg-sky-500 text-white text-semi-bold hover:bg-sky-600 hover:text-white font-semibold " : "dark:text-gray-300 hover:text-gray-700 hover:bg-gray-100 dark:hover:bg-slate-600 dark:hover:text-gray-100 ") + className,
      children: [
        modifiedIcon,
        /* @__PURE__ */ jsx("span", { className: `mx-2 text-sm ${minimize ? "hidden" : ""}`, children: name })
      ]
    }
  );
}
function UserSidebar({ minimize, changeMinimize, hamburgerMenu, dark }) {
  return /* @__PURE__ */ jsxs(
    "aside",
    {
      className: `fixed xl:flex hide-scrollbar flex-col transition-all ${hamburgerMenu ? "w-60 !flex z-50 px-8 py-6" : "w-0 !p-0 xl:!px-8 xl:!py-6"} ${minimize ? "xl:w-24" : "xl:w-60"} h-screen overflow-y-auto bg-white border-l dark:bg-slate-800 dark:border-slate-900 print:hidden`,
      children: [
        /* @__PURE__ */ jsx("a", { href: route("dashboard"), className: "-mx-2", children: /* @__PURE__ */ jsx(ApplicationLogo, { dark, small: minimize, className: `transition-all ${minimize ? "w-12 h-12" : "h-16"}` }) }),
        /* @__PURE__ */ jsx("div", { className: "flex flex-col justify-between flex-1 mt-6", children: /* @__PURE__ */ jsxs("nav", { className: `-mx-3 flex flex-col xl:justify-between ${minimize ? "items-center" : ""} flex-1`, children: [
          /* @__PURE__ */ jsxs("div", { className: !minimize ? "space-y-8" : "", children: [
            /* @__PURE__ */ jsx(
              NavLink,
              {
                className: "",
                href: route("dashboard"),
                active: route().current("dashboard"),
                icon: /* @__PURE__ */ jsx(Icon, { viewBox: "0 0 24 24", type: "stroke", children: /* @__PURE__ */ jsx(
                  "path",
                  {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    d: "M3.75 3v11.25A2.25 2.25 0 006 16.5h2.25M3.75 3h-1.5m1.5 0h16.5m0 0h1.5m-1.5 0v11.25A2.25 2.25 0 0118 16.5h-2.25m-7.5 0h7.5m-7.5 0l-1 3m8.5-3l1 3m0 0l.5 1.5m-.5-1.5h-9.5m0 0l-.5 1.5m.75-9l3-3 2.148 2.148A12.061 12.061 0 0116.5 7.605"
                  }
                ) }),
                name: "داشبورد",
                minimize
              }
            ),
            /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
              /* @__PURE__ */ jsxs("div", { className: `flex items-center ${minimize ? "my-5" : ""}`, children: [
                /* @__PURE__ */ jsx("span", { className: `px-3 text-xs text-gray-500 dark:text-slate-200 ${minimize ? "hidden" : ""}`, children: "کاربران" }),
                /* @__PURE__ */ jsx("div", { className: "flex-grow h-px bg-gray-300 dark:bg-gray-500" })
              ] }),
              /* @__PURE__ */ jsx(
                NavLink,
                {
                  href: route("patients.index"),
                  active: route().current("patients.index"),
                  icon: /* @__PURE__ */ jsx(Icon, { viewBox: "0 0 24 24", type: "stroke", width: "2", children: /* @__PURE__ */ jsx("path", { d: "M17 20C17 18.3431 14.7614 17 12 17C9.23858 17 7 18.3431 7 20M21 17.0004C21 15.7702 19.7659 14.7129 18 14.25M3 17.0004C3 15.7702 4.2341 14.7129 6 14.25M18 10.2361C18.6137 9.68679 19 8.8885 19 8C19 6.34315 17.6569 5 16 5C15.2316 5 14.5308 5.28885 14 5.76389M6 10.2361C5.38625 9.68679 5 8.8885 5 8C5 6.34315 6.34315 5 8 5C8.76835 5 9.46924 5.28885 10 5.76389M12 14C10.3431 14 9 12.6569 9 11C9 9.34315 10.3431 8 12 8C13.6569 8 15 9.34315 15 11C15 12.6569 13.6569 14 12 14Z" }) }),
                  name: "همه کاربران",
                  minimize
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
              /* @__PURE__ */ jsxs("div", { className: `flex items-center ${minimize ? "my-5" : ""}`, children: [
                /* @__PURE__ */ jsx("span", { className: `px-3 text-xs text-gray-500 dark:text-slate-200 ${minimize ? "hidden" : ""}`, children: "سفارش جدید" }),
                /* @__PURE__ */ jsx("div", { className: "flex-grow h-px bg-gray-300 dark:bg-gray-500" })
              ] }),
              /* @__PURE__ */ jsx(
                NavLink,
                {
                  href: route("records.create"),
                  active: route().current("records.create"),
                  icon: /* @__PURE__ */ jsx(Icon, { viewBox: "0 0 24 24", type: "fill", children: /* @__PURE__ */ jsx("path", { d: "M10 1C9.73478 1 9.48043 1.10536 9.29289 1.29289L3.29289 7.29289C3.10536 7.48043 3 7.73478 3 8V20C3 21.6569 4.34315 23 6 23H14C14.5523 23 15 22.5523 15 22C15 21.4477 14.5523 21 14 21H6C5.44772 21 5 20.5523 5 20V9H10C10.5523 9 11 8.55228 11 8V3H18C18.5523 3 19 3.44772 19 4V8C19 8.55228 19.4477 9 20 9C20.5523 9 21 8.55228 21 8V4C21 2.34315 19.6569 1 18 1H10ZM9 7H6.41421L9 4.41421V7ZM20 12C20 11.4477 19.5523 11 19 11C18.4477 11 18 11.4477 18 12V15H15C14.4477 15 14 15.4477 14 16C14 16.5523 14.4477 17 15 17H18V20C18 20.5523 18.4477 21 19 21C19.5523 21 20 20.5523 20 20V17H23C23.5523 17 24 16.5523 24 16C24 15.4477 23.5523 15 23 15H20V12Z" }) }),
                  name: "سفارش سمعک",
                  minimize
                }
              ),
              /* @__PURE__ */ jsx(
                NavLink,
                {
                  href: route("accessories.create"),
                  active: route().current("accessories.create"),
                  icon: /* @__PURE__ */ jsx(Icon, { viewBox: "0 0 24 24", type: "fill", children: /* @__PURE__ */ jsx("path", { d: "M10 1C9.73478 1 9.48043 1.10536 9.29289 1.29289L3.29289 7.29289C3.10536 7.48043 3 7.73478 3 8V20C3 21.6569 4.34315 23 6 23H14C14.5523 23 15 22.5523 15 22C15 21.4477 14.5523 21 14 21H6C5.44772 21 5 20.5523 5 20V9H10C10.5523 9 11 8.55228 11 8V3H18C18.5523 3 19 3.44772 19 4V8C19 8.55228 19.4477 9 20 9C20.5523 9 21 8.55228 21 8V4C21 2.34315 19.6569 1 18 1H10ZM9 7H6.41421L9 4.41421V7ZM20 12C20 11.4477 19.5523 11 19 11C18.4477 11 18 11.4477 18 12V15H15C14.4477 15 14 15.4477 14 16C14 16.5523 14.4477 17 15 17H18V20C18 20.5523 18.4477 21 19 21C19.5523 21 20 20.5523 20 20V17H23C23.5523 17 24 16.5523 24 16C24 15.4477 23.5523 15 23 15H20V12Z" }) }),
                  name: "سفارش لوازم جانبی",
                  minimize
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
              /* @__PURE__ */ jsxs("div", { className: `flex items-center ${minimize ? "my-5" : ""}`, children: [
                /* @__PURE__ */ jsx("span", { className: `px-3 text-xs text-gray-500 dark:text-slate-200 ${minimize ? "hidden" : ""}`, children: "آرشیو سفارشات" }),
                /* @__PURE__ */ jsx("div", { className: "flex-grow h-px bg-gray-300 dark:bg-gray-500" })
              ] }),
              /* @__PURE__ */ jsx(
                NavLink,
                {
                  href: route("records.index"),
                  active: route().current("records.index"),
                  icon: /* @__PURE__ */ jsx(Icon, { viewBox: "0 0 24 24", type: "fill", children: /* @__PURE__ */ jsx("path", { d: "M8.3931 9.85868C8.38638 10.2728 8.71667 10.614 9.13083 10.6208C9.54499 10.6275 9.88618 10.2972 9.8929 9.88303L8.3931 9.85868ZM12 7.10386L11.9882 7.85376C11.9961 7.85389 12.0039 7.85389 12.0118 7.85376L12 7.10386ZM14.857 9.87086L15.607 9.87398C15.607 9.86888 15.607 9.86378 15.6069 9.85868L14.857 9.87086ZM13.633 12.1419L14.043 12.7699L14.048 12.7666L13.633 12.1419ZM11.1306 14.0509C10.7297 14.1549 10.489 14.5643 10.593 14.9652C10.6971 15.3662 11.1064 15.6069 11.5074 15.5028L11.1306 14.0509ZM7 10.0039H7.75L7.75 10.0034L7 10.0039ZM10.9911 5.10335L11.1424 5.83793L10.9911 5.10335ZM16.5941 8.0272L15.905 8.32319V8.32319L16.5941 8.0272ZM14.857 14.1039L15.2755 14.7264L15.2856 14.7194L14.857 14.1039ZM10.808 18.8589L11.0019 19.5834L10.808 18.8589ZM7 16.6609H6.25C6.25 16.7169 6.25628 16.7728 6.26873 16.8274L7 16.6609ZM9.8929 9.88303C9.91139 8.74418 10.8493 7.8358 11.9882 7.85376L12.0118 6.35395C10.0449 6.32292 8.42502 7.89179 8.3931 9.85868L9.8929 9.88303ZM12.0118 7.85376C13.1507 7.8358 14.0886 8.74418 14.1071 9.88303L15.6069 9.85868C15.575 7.89179 13.9551 6.32292 11.9882 6.35395L12.0118 7.85376ZM14.107 9.86773C14.1042 10.5314 13.7708 11.1499 13.218 11.5171L14.048 12.7666C15.0174 12.1227 15.6021 11.0378 15.607 9.87398L14.107 9.86773ZM13.223 11.5139C12.1865 12.1906 11.7688 12.9152 11.4957 13.4681C11.1952 14.0765 11.2 14.0329 11.1306 14.0509L11.5074 15.5028C12.386 15.2748 12.6633 14.4913 12.8406 14.1324C13.0452 13.718 13.3105 13.2481 14.043 12.7699L13.223 11.5139ZM7.75 10.0034C7.74865 7.98563 9.16618 6.24508 11.1424 5.83793L10.8397 4.36878C8.16601 4.91964 6.24817 7.2745 6.25 10.0044L7.75 10.0034ZM11.1424 5.83793C13.1186 5.43077 15.1087 6.46926 15.905 8.32319L17.2833 7.7312C16.2059 5.22293 13.5134 3.81793 10.8397 4.36878L11.1424 5.83793ZM15.905 8.32319C16.7013 10.1771 16.0843 12.3354 14.4285 13.4884L15.2856 14.7194C17.5259 13.1595 18.3606 10.2395 17.2833 7.7312L15.905 8.32319ZM14.4386 13.4814C12.7369 14.6254 12.0653 15.8324 11.6155 16.7728C11.3827 17.2595 11.2593 17.5528 11.0926 17.7881C10.9604 17.9747 10.8318 18.0761 10.6141 18.1344L11.0019 19.5834C11.6137 19.4196 12.0184 19.0761 12.3166 18.6551C12.5803 18.2829 12.7841 17.8059 12.9687 17.4199C13.3537 16.6149 13.8771 15.6663 15.2754 14.7263L14.4386 13.4814ZM10.6141 18.1344C9.89164 18.3277 9.26349 18.3009 8.7965 18.0746C8.35861 17.8623 7.94128 17.4162 7.73127 16.4943L6.26873 16.8274C6.55872 18.1005 7.21589 18.9754 8.14225 19.4244C9.03951 19.8593 10.0654 19.834 11.0019 19.5834L10.6141 18.1344ZM7.75 16.6609V10.0039H6.25V16.6609H7.75Z" }) }),
                  name: "سفارشات سمعک",
                  minimize
                }
              ),
              /* @__PURE__ */ jsx(
                NavLink,
                {
                  href: route("accessories.index"),
                  active: route().current("accessories.index"),
                  icon: /* @__PURE__ */ jsxs(Icon, { viewBox: "0 0 24 24", type: "fill", children: [
                    /* @__PURE__ */ jsx("path", { d: "M12.0762 9.48014C12.3413 9.16193 12.2983 8.68901 11.9801 8.42384C11.6619 8.15867 11.189 8.20166 10.9238 8.51987L8.42383 11.5199C8.23753 11.7434 8.19737 12.0546 8.3208 12.3181C8.44424 12.5817 8.70898 12.75 8.99999 12.75H10.8987L9.42383 14.5199C9.15865 14.8381 9.20165 15.311 9.51986 15.5762C9.83806 15.8413 10.311 15.7983 10.5762 15.4801L13.0762 12.4801C13.2625 12.2566 13.3026 11.9454 13.1792 11.6819C13.0558 11.4183 12.791 11.25 12.5 11.25H10.6013L12.0762 9.48014Z" }),
                    /* @__PURE__ */ jsx("path", { d: "M9.94358 3.25H11.5564C13.3942 3.24998 14.8498 3.24997 15.989 3.40314C17.1614 3.56076 18.1104 3.89288 18.8588 4.64124C19.6071 5.38961 19.9392 6.33856 20.0969 7.51098C20.25 8.65018 20.25 10.1058 20.25 11.9435V12.0564C20.25 13.8942 20.25 15.3498 20.0969 16.489C19.9392 17.6614 19.6071 18.6104 18.8588 19.3588C18.1104 20.1071 17.1614 20.4392 15.989 20.5969C14.8498 20.75 13.3942 20.75 11.5565 20.75H9.94359C8.10585 20.75 6.65018 20.75 5.51098 20.5969C4.33856 20.4392 3.38961 20.1071 2.64124 19.3588C1.89288 18.6104 1.56076 17.6614 1.40314 16.489C1.24997 15.3498 1.24998 13.8942 1.25 12.0564V11.9436C1.24998 10.1058 1.24997 8.65019 1.40314 7.51098C1.56076 6.33856 1.89288 5.38961 2.64124 4.64124C3.38961 3.89288 4.33856 3.56076 5.51098 3.40314C6.65019 3.24997 8.10583 3.24998 9.94358 3.25ZM5.71085 4.88976C4.70476 5.02502 4.12511 5.27869 3.7019 5.7019C3.27869 6.12511 3.02502 6.70476 2.88976 7.71085C2.75159 8.73851 2.75 10.0932 2.75 12C2.75 13.9068 2.75159 15.2615 2.88976 16.2892C3.02502 17.2952 3.27869 17.8749 3.7019 18.2981C4.12511 18.7213 4.70476 18.975 5.71085 19.1102C6.73851 19.2484 8.09318 19.25 10 19.25H11.5C13.4068 19.25 14.7615 19.2484 15.7892 19.1102C16.7952 18.975 17.3749 18.7213 17.7981 18.2981C18.2213 17.8749 18.475 17.2952 18.6102 16.2892C18.7484 15.2615 18.75 13.9068 18.75 12C18.75 10.0932 18.7484 8.73851 18.6102 7.71085C18.475 6.70476 18.2213 6.12511 17.7981 5.7019C17.3749 5.27869 16.7952 5.02502 15.7892 4.88976C14.7615 4.75159 13.4068 4.75 11.5 4.75H10C8.09318 4.75 6.73851 4.75159 5.71085 4.88976Z" }),
                    /* @__PURE__ */ jsx("path", { d: "M22 14.75C21.5858 14.75 21.25 14.4142 21.25 14L21.25 10C21.25 9.58579 21.5858 9.25 22 9.25C22.4142 9.25 22.75 9.58579 22.75 10L22.75 14C22.75 14.4142 22.4142 14.75 22 14.75Z" })
                  ] }),
                  name: "سفارشات لوازم جانبی",
                  minimize
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-3 mt-6", children: [
            /* @__PURE__ */ jsx(
              NavLink,
              {
                href: route("profile.index"),
                active: route().current("profile.index"),
                icon: /* @__PURE__ */ jsxs(Icon, { viewBox: "0 0 24 24", type: "stroke", width: "2", children: [
                  /* @__PURE__ */ jsx("path", { d: "M12.1207 12.78C12.0507 12.77 11.9607 12.77 11.8807 12.78C10.1207 12.72 8.7207 11.28 8.7207 9.50998C8.7207 7.69998 10.1807 6.22998 12.0007 6.22998C13.8107 6.22998 15.2807 7.69998 15.2807 9.50998C15.2707 11.28 13.8807 12.72 12.1207 12.78Z" }),
                  /* @__PURE__ */ jsx("path", { d: "M18.7398 19.3801C16.9598 21.0101 14.5998 22.0001 11.9998 22.0001C9.39977 22.0001 7.03977 21.0101 5.25977 19.3801C5.35977 18.4401 5.95977 17.5201 7.02977 16.8001C9.76977 14.9801 14.2498 14.9801 16.9698 16.8001C18.0398 17.5201 18.6398 18.4401 18.7398 19.3801Z" }),
                  /* @__PURE__ */ jsx("path", { d: "M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" })
                ] }),
                name: "پروفایل",
                minimize
              }
            ),
            /* @__PURE__ */ jsx(
              NavLink,
              {
                className: "!mt-5",
                href: route("logout"),
                method: "POST",
                as: "button",
                icon: /* @__PURE__ */ jsx(Icon, { viewBox: "0 0 24 24", type: "fill", className: "text-red-500 dark:!text-red-700", children: /* @__PURE__ */ jsx("path", { d: "M2 6.5C2 4.01472 4.01472 2 6.5 2H12C14.2091 2 16 3.79086 16 6V7C16 7.55228 15.5523 8 15 8C14.4477 8 14 7.55228 14 7V6C14 4.89543 13.1046 4 12 4H6.5C5.11929 4 4 5.11929 4 6.5V17.5C4 18.8807 5.11929 20 6.5 20H12C13.1046 20 14 19.1046 14 18V17C14 16.4477 14.4477 16 15 16C15.5523 16 16 16.4477 16 17V18C16 20.2091 14.2091 22 12 22H6.5C4.01472 22 2 19.9853 2 17.5V6.5ZM18.2929 8.29289C18.6834 7.90237 19.3166 7.90237 19.7071 8.29289L22.7071 11.2929C23.0976 11.6834 23.0976 12.3166 22.7071 12.7071L19.7071 15.7071C19.3166 16.0976 18.6834 16.0976 18.2929 15.7071C17.9024 15.3166 17.9024 14.6834 18.2929 14.2929L19.5858 13L11 13C10.4477 13 10 12.5523 10 12C10 11.4477 10.4477 11 11 11L19.5858 11L18.2929 9.70711C17.9024 9.31658 17.9024 8.68342 18.2929 8.29289Z" }) }),
                name: "خروج از حساب کاربری",
                minimize
              }
            ),
            /* @__PURE__ */ jsx(
              NavLink,
              {
                className: "!mt-5 hidden xl:flex",
                role: "button",
                icon: /* @__PURE__ */ jsxs(Icon, { viewBox: "0 0 24 24", type: "stroke", width: "2", children: [
                  /* @__PURE__ */ jsx("polyline", { points: "9 3 9 9 3 9" }),
                  /* @__PURE__ */ jsx("polyline", { points: "15 21 15 15 21 15" }),
                  /* @__PURE__ */ jsx("polyline", { points: "3 15 9 15 9 21" }),
                  /* @__PURE__ */ jsx("polyline", { points: "21 9 15 9 15 3" })
                ] }),
                name: "بستن منو",
                minimize,
                onClick: changeMinimize
              }
            )
          ] })
        ] }) })
      ]
    }
  );
}
function AdminSidebar({ minimize, changeMinimize, hamburgerMenu, dark }) {
  return /* @__PURE__ */ jsxs(
    "aside",
    {
      className: `fixed xl:flex hide-scrollbar flex-col transition-all ${hamburgerMenu ? "w-60 !flex z-50 px-8 py-6" : "w-0 !p-0 xl:!px-8 xl:!py-6"} ${minimize ? "xl:w-24" : "xl:w-60"} h-screen overflow-y-auto bg-white border-l dark:bg-slate-800 dark:border-slate-900 print:hidden`,
      children: [
        /* @__PURE__ */ jsx(Link, { href: route("dashboard.admin"), children: /* @__PURE__ */ jsx(ApplicationLogo, { dark, small: minimize }) }),
        /* @__PURE__ */ jsx("div", { className: "flex flex-col justify-between flex-1 mt-6", children: /* @__PURE__ */ jsxs("nav", { className: `-mx-3 flex flex-col xl:justify-between ${minimize ? "items-center" : ""} flex-1`, children: [
          /* @__PURE__ */ jsxs("div", { className: !minimize ? "space-y-8" : "", children: [
            /* @__PURE__ */ jsx(
              NavLink,
              {
                className: "",
                href: route("dashboard.admin"),
                active: route().current("dashboard.admin"),
                icon: /* @__PURE__ */ jsx(Icon, { viewBox: "0 0 24 24", type: "stroke", children: /* @__PURE__ */ jsx(
                  "path",
                  {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    d: "M3.75 3v11.25A2.25 2.25 0 006 16.5h2.25M3.75 3h-1.5m1.5 0h16.5m0 0h1.5m-1.5 0v11.25A2.25 2.25 0 0118 16.5h-2.25m-7.5 0h7.5m-7.5 0l-1 3m8.5-3l1 3m0 0l.5 1.5m-.5-1.5h-9.5m0 0l-.5 1.5m.75-9l3-3 2.148 2.148A12.061 12.061 0 0116.5 7.605"
                  }
                ) }),
                name: "داشبورد",
                minimize
              }
            ),
            /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
              /* @__PURE__ */ jsxs("div", { className: `flex items-center ${minimize ? "my-5" : ""}`, children: [
                /* @__PURE__ */ jsx("span", { className: `px-3 text-xs text-gray-500 dark:text-slate-200 ${minimize ? "hidden" : ""}`, children: "محصولات" }),
                /* @__PURE__ */ jsx("div", { className: "flex-grow h-px bg-gray-300 dark:bg-gray-500" })
              ] }),
              /* @__PURE__ */ jsx(
                NavLink,
                {
                  href: route("products.index"),
                  active: route().current("products.index"),
                  icon: /* @__PURE__ */ jsx(Icon, { viewBox: "0 0 24 24", type: "fill", children: /* @__PURE__ */ jsx("path", { d: "M19,13 C20.6568542,13 22,14.3431458 22,16 L22,19 C22,20.6568542 20.6568542,22 19,22 L16,22 C14.3431458,22 13,20.6568542 13,19 L13,16 C13,14.3431458 14.3431458,13 16,13 L19,13 Z M8,13 C9.65685425,13 11,14.3431458 11,16 L11,19 C11,20.6568542 9.65685425,22 8,22 L5,22 C3.34314575,22 2,20.6568542 2,19 L2,16 C2,14.3431458 3.34314575,13 5,13 L8,13 Z M19,15 L16,15 C15.4477153,15 15,15.4477153 15,16 L15,19 C15,19.5522847 15.4477153,20 16,20 L19,20 C19.5522847,20 20,19.5522847 20,19 L20,16 C20,15.4477153 19.5522847,15 19,15 Z M8,15 L5,15 C4.44771525,15 4,15.4477153 4,16 L4,19 C4,19.5522847 4.44771525,20 5,20 L8,20 C8.55228475,20 9,19.5522847 9,19 L9,16 C9,15.4477153 8.55228475,15 8,15 Z M8,2 C9.65685425,2 11,3.34314575 11,5 L11,8 C11,9.65685425 9.65685425,11 8,11 L5,11 C3.34314575,11 2,9.65685425 2,8 L2,5 C2,3.34314575 3.34314575,2 5,2 L8,2 Z M19,2 C20.6568542,2 22,3.34314575 22,5 L22,8 C22,9.65685425 20.6568542,11 19,11 L16,11 C14.3431458,11 13,9.65685425 13,8 L13,5 C13,3.34314575 14.3431458,2 16,2 L19,2 Z M8,4 L5,4 C4.44771525,4 4,4.44771525 4,5 L4,8 C4,8.55228475 4.44771525,9 5,9 L8,9 C8.55228475,9 9,8.55228475 9,8 L9,5 C9,4.44771525 8.55228475,4 8,4 Z M19,4 L16,4 C15.4477153,4 15,4.44771525 15,5 L15,8 C15,8.55228475 15.4477153,9 16,9 L19,9 C19.5522847,9 20,8.55228475 20,8 L20,5 C20,4.44771525 19.5522847,4 19,4 Z" }) }),
                  name: "همه محصولات",
                  minimize
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
              /* @__PURE__ */ jsxs("div", { className: `flex items-center ${minimize ? "my-5" : ""}`, children: [
                /* @__PURE__ */ jsx("span", { className: `px-3 text-xs text-gray-500 dark:text-slate-200 ${minimize ? "hidden" : ""}`, children: "همکاران" }),
                /* @__PURE__ */ jsx("div", { className: "flex-grow h-px bg-gray-300 dark:bg-gray-500" })
              ] }),
              /* @__PURE__ */ jsx(
                NavLink,
                {
                  href: route("users.index"),
                  active: route().current("users.index"),
                  icon: /* @__PURE__ */ jsx(Icon, { viewBox: "0 0 24 24", type: "stroke", width: "2", children: /* @__PURE__ */ jsx("path", { d: "M17 20C17 18.3431 14.7614 17 12 17C9.23858 17 7 18.3431 7 20M21 17.0004C21 15.7702 19.7659 14.7129 18 14.25M3 17.0004C3 15.7702 4.2341 14.7129 6 14.25M18 10.2361C18.6137 9.68679 19 8.8885 19 8C19 6.34315 17.6569 5 16 5C15.2316 5 14.5308 5.28885 14 5.76389M6 10.2361C5.38625 9.68679 5 8.8885 5 8C5 6.34315 6.34315 5 8 5C8.76835 5 9.46924 5.28885 10 5.76389M12 14C10.3431 14 9 12.6569 9 11C9 9.34315 10.3431 8 12 8C13.6569 8 15 9.34315 15 11C15 12.6569 13.6569 14 12 14Z" }) }),
                  name: "همه همکاران",
                  minimize
                }
              ),
              /* @__PURE__ */ jsx(
                NavLink,
                {
                  href: route("users.not_verified"),
                  active: route().current("users.not_verified"),
                  icon: /* @__PURE__ */ jsx(Icon, { viewBox: "0 0 24 24", type: "stroke", width: "2", children: /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M16 18L18 20L22 16M12 15H8C6.13623 15 5.20435 15 4.46927 15.3045C3.48915 15.7105 2.71046 16.4892 2.30448 17.4693C2 18.2044 2 19.1362 2 21M15.5 3.29076C16.9659 3.88415 18 5.32131 18 7C18 8.67869 16.9659 10.1159 15.5 10.7092M13.5 7C13.5 9.20914 11.7091 11 9.5 11C7.29086 11 5.5 9.20914 5.5 7C5.5 4.79086 7.29086 3 9.5 3C11.7091 3 13.5 4.79086 13.5 7Z" }) }),
                  name: "همکاران تایید نشده",
                  minimize
                }
              ),
              /* @__PURE__ */ jsx(
                NavLink,
                {
                  href: route("users.not_completed"),
                  active: route().current("users.not_completed"),
                  icon: /* @__PURE__ */ jsx(Icon, { viewBox: "0 0 24 24", type: "stroke", width: "2", children: /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M16.5 16L21.5 21M21.5 16L16.5 21M15.5 3.29076C16.9659 3.88415 18 5.32131 18 7C18 8.67869 16.9659 10.1159 15.5 10.7092M12 15H8C6.13623 15 5.20435 15 4.46927 15.3045C3.48915 15.7105 2.71046 16.4892 2.30448 17.4693C2 18.2044 2 19.1362 2 21M13.5 7C13.5 9.20914 11.7091 11 9.5 11C7.29086 11 5.5 9.20914 5.5 7C5.5 4.79086 7.29086 3 9.5 3C11.7091 3 13.5 4.79086 13.5 7Z" }) }),
                  name: "همکاران ثبت نشده",
                  minimize
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
              /* @__PURE__ */ jsxs("div", { className: `flex items-center ${minimize ? "my-5" : ""}`, children: [
                /* @__PURE__ */ jsx("span", { className: `px-3 text-xs text-gray-500 dark:text-slate-200 ${minimize ? "hidden" : ""}`, children: "سفارشات" }),
                /* @__PURE__ */ jsx("div", { className: "flex-grow h-px bg-gray-300 dark:bg-gray-500" })
              ] }),
              /* @__PURE__ */ jsx(
                NavLink,
                {
                  href: route("admin.records"),
                  active: route().current("admin.records"),
                  icon: /* @__PURE__ */ jsx(Icon, { viewBox: "0 0 24 24", type: "fill", children: /* @__PURE__ */ jsx("path", { d: "M8.3931 9.85868C8.38638 10.2728 8.71667 10.614 9.13083 10.6208C9.54499 10.6275 9.88618 10.2972 9.8929 9.88303L8.3931 9.85868ZM12 7.10386L11.9882 7.85376C11.9961 7.85389 12.0039 7.85389 12.0118 7.85376L12 7.10386ZM14.857 9.87086L15.607 9.87398C15.607 9.86888 15.607 9.86378 15.6069 9.85868L14.857 9.87086ZM13.633 12.1419L14.043 12.7699L14.048 12.7666L13.633 12.1419ZM11.1306 14.0509C10.7297 14.1549 10.489 14.5643 10.593 14.9652C10.6971 15.3662 11.1064 15.6069 11.5074 15.5028L11.1306 14.0509ZM7 10.0039H7.75L7.75 10.0034L7 10.0039ZM10.9911 5.10335L11.1424 5.83793L10.9911 5.10335ZM16.5941 8.0272L15.905 8.32319V8.32319L16.5941 8.0272ZM14.857 14.1039L15.2755 14.7264L15.2856 14.7194L14.857 14.1039ZM10.808 18.8589L11.0019 19.5834L10.808 18.8589ZM7 16.6609H6.25C6.25 16.7169 6.25628 16.7728 6.26873 16.8274L7 16.6609ZM9.8929 9.88303C9.91139 8.74418 10.8493 7.8358 11.9882 7.85376L12.0118 6.35395C10.0449 6.32292 8.42502 7.89179 8.3931 9.85868L9.8929 9.88303ZM12.0118 7.85376C13.1507 7.8358 14.0886 8.74418 14.1071 9.88303L15.6069 9.85868C15.575 7.89179 13.9551 6.32292 11.9882 6.35395L12.0118 7.85376ZM14.107 9.86773C14.1042 10.5314 13.7708 11.1499 13.218 11.5171L14.048 12.7666C15.0174 12.1227 15.6021 11.0378 15.607 9.87398L14.107 9.86773ZM13.223 11.5139C12.1865 12.1906 11.7688 12.9152 11.4957 13.4681C11.1952 14.0765 11.2 14.0329 11.1306 14.0509L11.5074 15.5028C12.386 15.2748 12.6633 14.4913 12.8406 14.1324C13.0452 13.718 13.3105 13.2481 14.043 12.7699L13.223 11.5139ZM7.75 10.0034C7.74865 7.98563 9.16618 6.24508 11.1424 5.83793L10.8397 4.36878C8.16601 4.91964 6.24817 7.2745 6.25 10.0044L7.75 10.0034ZM11.1424 5.83793C13.1186 5.43077 15.1087 6.46926 15.905 8.32319L17.2833 7.7312C16.2059 5.22293 13.5134 3.81793 10.8397 4.36878L11.1424 5.83793ZM15.905 8.32319C16.7013 10.1771 16.0843 12.3354 14.4285 13.4884L15.2856 14.7194C17.5259 13.1595 18.3606 10.2395 17.2833 7.7312L15.905 8.32319ZM14.4386 13.4814C12.7369 14.6254 12.0653 15.8324 11.6155 16.7728C11.3827 17.2595 11.2593 17.5528 11.0926 17.7881C10.9604 17.9747 10.8318 18.0761 10.6141 18.1344L11.0019 19.5834C11.6137 19.4196 12.0184 19.0761 12.3166 18.6551C12.5803 18.2829 12.7841 17.8059 12.9687 17.4199C13.3537 16.6149 13.8771 15.6663 15.2754 14.7263L14.4386 13.4814ZM10.6141 18.1344C9.89164 18.3277 9.26349 18.3009 8.7965 18.0746C8.35861 17.8623 7.94128 17.4162 7.73127 16.4943L6.26873 16.8274C6.55872 18.1005 7.21589 18.9754 8.14225 19.4244C9.03951 19.8593 10.0654 19.834 11.0019 19.5834L10.6141 18.1344ZM7.75 16.6609V10.0039H6.25V16.6609H7.75Z" }) }),
                  name: "سفارشات سمعک",
                  minimize
                }
              ),
              /* @__PURE__ */ jsx(
                NavLink,
                {
                  href: route("admin.accessories"),
                  active: route().current("admin.accessories"),
                  icon: /* @__PURE__ */ jsxs(Icon, { viewBox: "0 0 24 24", type: "fill", children: [
                    /* @__PURE__ */ jsx("path", { d: "M12.0762 9.48014C12.3413 9.16193 12.2983 8.68901 11.9801 8.42384C11.6619 8.15867 11.189 8.20166 10.9238 8.51987L8.42383 11.5199C8.23753 11.7434 8.19737 12.0546 8.3208 12.3181C8.44424 12.5817 8.70898 12.75 8.99999 12.75H10.8987L9.42383 14.5199C9.15865 14.8381 9.20165 15.311 9.51986 15.5762C9.83806 15.8413 10.311 15.7983 10.5762 15.4801L13.0762 12.4801C13.2625 12.2566 13.3026 11.9454 13.1792 11.6819C13.0558 11.4183 12.791 11.25 12.5 11.25H10.6013L12.0762 9.48014Z" }),
                    /* @__PURE__ */ jsx("path", { d: "M9.94358 3.25H11.5564C13.3942 3.24998 14.8498 3.24997 15.989 3.40314C17.1614 3.56076 18.1104 3.89288 18.8588 4.64124C19.6071 5.38961 19.9392 6.33856 20.0969 7.51098C20.25 8.65018 20.25 10.1058 20.25 11.9435V12.0564C20.25 13.8942 20.25 15.3498 20.0969 16.489C19.9392 17.6614 19.6071 18.6104 18.8588 19.3588C18.1104 20.1071 17.1614 20.4392 15.989 20.5969C14.8498 20.75 13.3942 20.75 11.5565 20.75H9.94359C8.10585 20.75 6.65018 20.75 5.51098 20.5969C4.33856 20.4392 3.38961 20.1071 2.64124 19.3588C1.89288 18.6104 1.56076 17.6614 1.40314 16.489C1.24997 15.3498 1.24998 13.8942 1.25 12.0564V11.9436C1.24998 10.1058 1.24997 8.65019 1.40314 7.51098C1.56076 6.33856 1.89288 5.38961 2.64124 4.64124C3.38961 3.89288 4.33856 3.56076 5.51098 3.40314C6.65019 3.24997 8.10583 3.24998 9.94358 3.25ZM5.71085 4.88976C4.70476 5.02502 4.12511 5.27869 3.7019 5.7019C3.27869 6.12511 3.02502 6.70476 2.88976 7.71085C2.75159 8.73851 2.75 10.0932 2.75 12C2.75 13.9068 2.75159 15.2615 2.88976 16.2892C3.02502 17.2952 3.27869 17.8749 3.7019 18.2981C4.12511 18.7213 4.70476 18.975 5.71085 19.1102C6.73851 19.2484 8.09318 19.25 10 19.25H11.5C13.4068 19.25 14.7615 19.2484 15.7892 19.1102C16.7952 18.975 17.3749 18.7213 17.7981 18.2981C18.2213 17.8749 18.475 17.2952 18.6102 16.2892C18.7484 15.2615 18.75 13.9068 18.75 12C18.75 10.0932 18.7484 8.73851 18.6102 7.71085C18.475 6.70476 18.2213 6.12511 17.7981 5.7019C17.3749 5.27869 16.7952 5.02502 15.7892 4.88976C14.7615 4.75159 13.4068 4.75 11.5 4.75H10C8.09318 4.75 6.73851 4.75159 5.71085 4.88976Z" }),
                    /* @__PURE__ */ jsx("path", { d: "M22 14.75C21.5858 14.75 21.25 14.4142 21.25 14L21.25 10C21.25 9.58579 21.5858 9.25 22 9.25C22.4142 9.25 22.75 9.58579 22.75 10L22.75 14C22.75 14.4142 22.4142 14.75 22 14.75Z" })
                  ] }),
                  name: "سفارشات لوازم جانبی",
                  minimize
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
              /* @__PURE__ */ jsxs("div", { className: `flex items-center ${minimize ? "my-5" : ""}`, children: [
                /* @__PURE__ */ jsx("span", { className: `px-3 text-xs text-gray-500 dark:text-slate-200 ${minimize ? "hidden" : ""}`, children: "تنظیمات" }),
                /* @__PURE__ */ jsx("div", { className: "flex-grow h-px bg-gray-300 dark:bg-gray-500" })
              ] }),
              /* @__PURE__ */ jsx(
                NavLink,
                {
                  href: route("settings.index"),
                  active: route().current("settings.index"),
                  icon: /* @__PURE__ */ jsxs(Icon, { viewBox: "0 0 24 24", type: "stroke", width: "2", children: [
                    /* @__PURE__ */ jsx("path", { d: "M10.343 3.94c.09-.542.56-.94 1.11-.94h1.093c.55 0 1.02.398 1.11.94l.149.894c.07.424.384.764.78.93.398.164.855.142 1.205-.108l.737-.527a1.125 1.125 0 011.45.12l.773.774c.39.389.44 1.002.12 1.45l-.527.737c-.25.35-.272.806-.107 1.204.165.397.505.71.93.78l.893.15c.543.09.94.56.94 1.109v1.094c0 .55-.397 1.02-.94 1.11l-.893.149c-.425.07-.765.383-.93.78-.165.398-.143.854.107 1.204l.527.738c.32.447.269 1.06-.12 1.45l-.774.773a1.125 1.125 0 01-1.449.12l-.738-.527c-.35-.25-.806-.272-1.203-.107-.397.165-.71.505-.781.929l-.149.894c-.09.542-.56.94-1.11.94h-1.094c-.55 0-1.019-.398-1.11-.94l-.148-.894c-.071-.424-.384-.764-.781-.93-.398-.164-.854-.142-1.204.108l-.738.527c-.447.32-1.06.269-1.45-.12l-.773-.774a1.125 1.125 0 01-.12-1.45l.527-.737c.25-.35.273-.806.108-1.204-.165-.397-.505-.71-.93-.78l-.894-.15c-.542-.09-.94-.56-.94-1.109v-1.094c0-.55.398-1.02.94-1.11l.894-.149c.424-.07.765-.383.93-.78.165-.398.143-.854-.107-1.204l-.527-.738a1.125 1.125 0 01.12-1.45l.773-.773a1.125 1.125 0 011.45-.12l.737.527c.35.25.807.272 1.204.107.397-.165.71-.505.78-.929l.15-.894z" }),
                    /* @__PURE__ */ jsx("path", { d: "M15 12a3 3 0 11-6 0 3 3 0 016 0z" })
                  ] }),
                  name: "تنظیمات گروه بندی",
                  minimize
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-3 mt-6", children: [
            /* @__PURE__ */ jsx(
              NavLink,
              {
                href: route("logout"),
                method: "POST",
                as: "button",
                icon: /* @__PURE__ */ jsx(Icon, { viewBox: "0 0 24 24", type: "fill", className: "text-red-500 dark:!text-red-700", children: /* @__PURE__ */ jsx("path", { d: "M2 6.5C2 4.01472 4.01472 2 6.5 2H12C14.2091 2 16 3.79086 16 6V7C16 7.55228 15.5523 8 15 8C14.4477 8 14 7.55228 14 7V6C14 4.89543 13.1046 4 12 4H6.5C5.11929 4 4 5.11929 4 6.5V17.5C4 18.8807 5.11929 20 6.5 20H12C13.1046 20 14 19.1046 14 18V17C14 16.4477 14.4477 16 15 16C15.5523 16 16 16.4477 16 17V18C16 20.2091 14.2091 22 12 22H6.5C4.01472 22 2 19.9853 2 17.5V6.5ZM18.2929 8.29289C18.6834 7.90237 19.3166 7.90237 19.7071 8.29289L22.7071 11.2929C23.0976 11.6834 23.0976 12.3166 22.7071 12.7071L19.7071 15.7071C19.3166 16.0976 18.6834 16.0976 18.2929 15.7071C17.9024 15.3166 17.9024 14.6834 18.2929 14.2929L19.5858 13L11 13C10.4477 13 10 12.5523 10 12C10 11.4477 10.4477 11 11 11L19.5858 11L18.2929 9.70711C17.9024 9.31658 17.9024 8.68342 18.2929 8.29289Z" }) }),
                name: "خروج از حساب کاربری",
                minimize
              }
            ),
            /* @__PURE__ */ jsx(
              NavLink,
              {
                className: "!mt-5 hidden xl:flex",
                role: "button",
                icon: /* @__PURE__ */ jsxs(Icon, { viewBox: "0 0 24 24", type: "stroke", width: "2", children: [
                  /* @__PURE__ */ jsx("polyline", { points: "9 3 9 9 3 9" }),
                  /* @__PURE__ */ jsx("polyline", { points: "15 21 15 15 21 15" }),
                  /* @__PURE__ */ jsx("polyline", { points: "3 15 9 15 9 21" }),
                  /* @__PURE__ */ jsx("polyline", { points: "21 9 15 9 15 3" })
                ] }),
                name: "بستن منو",
                minimize,
                onClick: changeMinimize
              }
            )
          ] })
        ] }) })
      ]
    }
  );
}
function Authenticated({ header, breadcrumbs, headerExtra, children }) {
  const [minimize, setMinimize] = useMemorable(false, "minimize");
  const [dark, setDark] = useMemorable(false, "dark");
  const [hamburgerMenu, setHamburgerMenu] = useState(false);
  const { toast: toast$1, auth } = usePage().props;
  useEffect(() => {
    if (dark) {
      document.body.classList.add("dark");
    } else {
      document.body.classList.remove("dark");
    }
  }, [dark]);
  useEffect(() => {
    if (toast$1) {
      const type = Object.keys(toast$1)[0];
      const message = toast$1[type];
      toast(message, {
        type
      });
    }
  }, [toast$1]);
  window.onbeforeprint = (event) => {
    if (dark)
      document.body.classList.remove("dark");
  };
  window.onafterprint = (event) => {
    if (dark) {
      document.body.classList.add("dark");
    }
  };
  const toggleDarkMode = () => {
    setDark(!dark);
  };
  const changeMinimize = (e) => {
    e.preventDefault();
    setMinimize(!minimize);
  };
  return /* @__PURE__ */ jsxs("div", { children: [
    /* @__PURE__ */ jsx(
      ToastContainer,
      {
        position: "top-left",
        autoClose: 5e3,
        hideProgressBar: false,
        newestOnTop: true,
        closeOnClick: true,
        rtl: true,
        pauseOnFocusLoss: true,
        draggable: true,
        pauseOnHover: true,
        theme: dark ? "dark" : "light"
      }
    ),
    /* @__PURE__ */ jsxs("div", { className: "min-h-screen bg-gray-100 dark:bg-slate-800 print:bg-white", children: [
      /* @__PURE__ */ jsx("div", { className: `fixed w-full ${hamburgerMenu ? "block" : "hidden"} h-full z-40 bg-black/40`, onClick: () => setHamburgerMenu(false) }),
      auth.user.is_admin ? /* @__PURE__ */ jsx(AdminSidebar, { minimize, changeMinimize, hamburgerMenu, setHamburgerMenu, dark }) : /* @__PURE__ */ jsx(UserSidebar, { minimize, changeMinimize, hamburgerMenu, setHamburgerMenu, dark }),
      /* @__PURE__ */ jsxs("div", { className: `min-h-screen relative pb-24 xl:pb-12 print:p-0 transition-all ${minimize ? "xl:mr-24" : "xl:mr-60"}`, children: [
        header && /* @__PURE__ */ jsxs("header", { className: `bg-white dark:bg-slate-900 transition-all print:hidden`, children: [
          /* @__PURE__ */ jsx("div", { className: "container mx-auto py-6 px-4 sm:px-6 lg:px-8", children: /* @__PURE__ */ jsxs("div", { className: "flex gap-y-5 justify-between", children: [
            /* @__PURE__ */ jsx("h1", { className: "font-semibold text-xl text-gray-800 dark:text-slate-200 align-middle py-2", children: header }),
            /* @__PURE__ */ jsxs("div", { className: "flex", children: [
              /* @__PURE__ */ jsx("button", { className: "flex mr-auto bg-gray-100 dark:bg-slate-800 rounded-full w-10 h-10 ml-4 xl:ml-0 items-center justify-center", onClick: toggleDarkMode, children: /* @__PURE__ */ jsx("svg", { xmlns: "http://www.w3.org/2000/svg", className: "w-6 h-6 text-gray-500 dark:text-slate-300", viewBox: "0 0 24 24", fill: "none", children: dark ? /* @__PURE__ */ jsx("path", { d: "M20 14.12A7.78 7.78 0 019.88 4a7.782 7.782 0 002.9 15A7.782 7.782 0 0020 14.12z", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }) : /* @__PURE__ */ jsxs(Fragment, { children: [
                /* @__PURE__ */ jsx("circle", { cx: "12", cy: "12", r: "4.14113", stroke: "currentColor", strokeWidth: "1.91129" }),
                /* @__PURE__ */ jsx("path", { d: "M12.9556 3.08065C12.9556 2.55286 12.5277 2.125 12 2.125C11.4722 2.125 11.0443 2.55286 11.0443 3.08065L11.0443 5.64078C11.3561 5.59432 11.6753 5.57024 12 5.57024C12.3247 5.57024 12.6438 5.59431 12.9556 5.64076L12.9556 3.08065ZM12.9556 18.3594C12.6438 18.4059 12.3247 18.4299 12 18.4299C11.6753 18.4299 11.3561 18.4058 11.0443 18.3594L11.0443 20.9194C11.0443 21.4471 11.4722 21.875 12 21.875C12.5277 21.875 12.9556 21.4471 12.9556 20.9194L12.9556 18.3594Z", fill: "currentColor" }),
                /* @__PURE__ */ jsx("path", { d: "M20.9194 12.9556C21.4471 12.9556 21.875 12.5277 21.875 12C21.875 11.4722 21.4471 11.0443 20.9194 11.0443L18.3592 11.0443C18.4057 11.3561 18.4298 11.6753 18.4298 12C18.4298 12.3247 18.4057 12.6438 18.3592 12.9556L20.9194 12.9556ZM5.6406 12.9556C5.59415 12.6438 5.57008 12.3247 5.57008 12C5.57008 11.6753 5.59416 11.3561 5.64062 11.0443L3.08064 11.0443C2.55286 11.0443 2.125 11.4722 2.125 12C2.125 12.5277 2.55286 12.9556 3.08064 12.9556L5.6406 12.9556Z", fill: "currentColor" }),
                /* @__PURE__ */ jsx("path", { d: "M18.9828 6.36876C19.356 5.99555 19.356 5.39047 18.9828 5.01727C18.6096 4.64407 18.0045 4.64407 17.6313 5.01727L15.8209 6.82764C16.0743 7.01528 16.3169 7.22391 16.5466 7.45354C16.7762 7.68315 16.9848 7.92581 17.1724 8.17912L18.9828 6.36876ZM8.17898 17.1725C7.92567 16.9849 7.68302 16.7763 7.45341 16.5467C7.22378 16.3171 7.01514 16.0744 6.82751 15.8211L5.01742 17.6311C4.64422 18.0043 4.64422 18.6094 5.01742 18.9826C5.39062 19.3558 5.9957 19.3558 6.36891 18.9826L8.17898 17.1725Z", fill: "currentColor" }),
                /* @__PURE__ */ jsx("path", { d: "M6.36888 5.01722C5.99568 4.64402 5.3906 4.64402 5.01739 5.01722C4.64419 5.39043 4.64419 5.99551 5.01739 6.36871L6.82776 8.17908C7.0154 7.92574 7.22403 7.68306 7.45366 7.45342C7.68327 7.22381 7.92593 7.0152 8.17924 6.82758L6.36888 5.01722ZM17.1727 15.821C16.9851 16.0743 16.7764 16.317 16.5468 16.5466C16.3172 16.7762 16.0745 16.9849 15.8212 17.1725L17.6313 18.9826C18.0045 19.3558 18.6095 19.3558 18.9828 18.9826C19.356 18.6094 19.356 18.0043 18.9828 17.6311L17.1727 15.821Z", fill: "currentColor" })
              ] }) }) }),
              /* @__PURE__ */ jsx("button", { className: "xl:hidden flex bg-gray-100 dark:bg-slate-800 rounded-full w-10 h-10 items-center justify-center", onClick: () => setHamburgerMenu(true), children: /* @__PURE__ */ jsx(Icon, { viewBox: "0 0 24 24", type: "stroke", children: /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" }) }) })
            ] })
          ] }) }),
          (breadcrumbs || headerExtra) && /* @__PURE__ */ jsxs(Fragment, { children: [
            /* @__PURE__ */ jsx("hr", { className: "w-fulll border-gray-300 dark:border-slate-600" }),
            /* @__PURE__ */ jsxs("div", { className: `container mx-auto py-6 px-4 sm:px-6 lg:px-8 flex ${breadcrumbs && headerExtra ? "flex-col xl:flex-row space-y-5 xl:space-y-0" : ""} justify-between py-4 overflow-x-auto whitespace-nowrap`, children: [
              breadcrumbs && /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row xl:items-center gap-x-5 gap-y-2", children: [
                /* @__PURE__ */ jsxs("a", { href: route("dashboard"), className: "flex gap-4 text-gray-600 dark:text-slate-200", children: [
                  /* @__PURE__ */ jsx("svg", { xmlns: "http://www.w3.org/2000/svg", className: "w-5 h-5", viewBox: "0 0 20 20", fill: "currentColor", children: /* @__PURE__ */ jsx(
                    "path",
                    {
                      d: "M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"
                    }
                  ) }),
                  /* @__PURE__ */ jsx("span", { className: "inline-block xl:hidden", children: "داشبورد" })
                ] }),
                Object.keys(breadcrumbs).map((sectionName, i) => {
                  const keys = Object.keys(breadcrumbs);
                  return /* @__PURE__ */ jsxs("div", { className: "flex gap-5 mr-1 xl:mr-0 items-center", children: [
                    /* @__PURE__ */ jsx("span", { className: "text-gray-500  dark:text-slate-100", children: /* @__PURE__ */ jsx("svg", { xmlns: "http://www.w3.org/2000/svg", className: "w-3 h-3", viewBox: "0 0 20 20", stroke: "currentColor", fill: "currentColor", children: /* @__PURE__ */ jsx(
                      "path",
                      {
                        d: "M15.7071 4.29289C16.0976 4.68342 16.0976 5.31658 15.7071 5.70711L9.41421 12L15.7071 18.2929C16.0976 18.6834 16.0976 19.3166 15.7071 19.7071C15.3166 20.0976 14.6834 20.0976 14.2929 19.7071L7.29289 12.7071C7.10536 12.5196 7 12.2652 7 12C7 11.7348 7.10536 11.4804 7.29289 11.2929L14.2929 4.29289C14.6834 3.90237 15.3166 3.90237 15.7071 4.29289Z"
                      }
                    ) }) }),
                    /* @__PURE__ */ jsx("a", { href: breadcrumbs[sectionName], className: `${keys[keys.length - 1] === sectionName ? "text-sky-500 font-semibold" : "text-gray-600 dark:text-slate-200"} hover:underline`, children: sectionName })
                  ] }, i);
                })
              ] }),
              headerExtra && headerExtra
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsx("main", { className: "container mx-auto px-4 sm:px-6 lg:px-8 py-8 xl:py-12 print:p-0 print:h-full", children }),
        /* @__PURE__ */ jsx("div", { className: "absolute bottom-0 right-0 w-full border-t border-gray-200 dark:border-slate-700 print:hidden", children: /* @__PURE__ */ jsxs("footer", { className: "container mx-auto flex flex-col xl:flex-row space-y-5 xl:space-y-0 items-center px-4 sm:px-6 lg:px-8 py-4 text-gray-500 dark:text-slate-400", children: [
          /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/2 text-center xl:text-right", children: [
            "طراحی و توسعه توسط ",
            /* @__PURE__ */ jsx("a", { href: "https://rahamteam.com", className: "text-sm text-blue-500 font-semibold", children: "رهام" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/2 flex items-center justify-center xl:justify-start text-xs font-semibold eng-num", dir: "ltr", children: [
            /* @__PURE__ */ jsxs(Icon, { viewBox: "0 0 24 24", type: "stroke", width: "2", className: "!w-4 !h-4 inline mr-1", children: [
              /* @__PURE__ */ jsx("path", { d: "M14 15.6672C13.475 15.8812 12.8952 16 12.2857 16C9.91878 16 8 14.2091 8 12C8 9.79086 9.91878 8 12.2857 8C12.8952 8 13.475 8.11876 14 8.33283" }),
              /* @__PURE__ */ jsx("path", { d: "M7 3.33782C8.47087 2.48697 10.1786 2 12 2C17.5228 2 22 6.47715 22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 10.1786 2.48697 8.47087 3.33782 7" })
            ] }),
            /* @__PURE__ */ jsxs("span", { className: "mt-1", children: [
              (/* @__PURE__ */ new Date()).getFullYear(),
              " Neda Samak Ashena. All Rights Reserved."
            ] })
          ] })
        ] }) })
      ] })
    ] })
  ] });
}
export {
  Authenticated as A
};
