const manifest = {
  "AuthenticatedLayout.css": {
    file: "assets/AuthenticatedLayout-b7bb1ac5.css",
    src: "AuthenticatedLayout.css"
  },
  "_AidInputs-b1365da7.js": {
    file: "assets/AidInputs-b1365da7.js",
    imports: [
      "resources/js/app.jsx",
      "_SelectInput-caea256b.js",
      "_InputError-384f6daa.js",
      "_PrimaryButton-ee44eafd.js",
      "_DangerButton-43405439.js",
      "_AuthenticatedLayout-d7a8707f.js",
      "resources/js/Pages/Records/Components/Steps.jsx",
      "_TextInput-b8dc6570.js",
      "_TextAreaInput-fd3cc2e6.js",
      "_IranStatesOptions-4f288355.js",
      "_FileInput-49ddbbb1.js",
      "_RadioInput-5848c680.js",
      "_InputLabel-11f6ccef.js",
      "resources/js/Pages/Records/Components/ProductsSlider.jsx",
      "_useFirstRender-cb9651eb.js",
      "_CheckboxInput-f7da3931.js",
      "_Icon-253babe4.js"
    ],
    isDynamicEntry: true
  },
  "_ApplicationLogo-ebb08f88.js": {
    file: "assets/ApplicationLogo-ebb08f88.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_ArrowLink-82e0ea36.js": {
    file: "assets/ArrowLink-82e0ea36.js",
    imports: [
      "resources/js/app.jsx",
      "__commonjs-dynamic-modules-302442b1.js"
    ]
  },
  "_AuthenticatedLayout-d7a8707f.js": {
    css: [
      "assets/AuthenticatedLayout-b7bb1ac5.css"
    ],
    file: "assets/AuthenticatedLayout-d7a8707f.js",
    imports: [
      "resources/js/app.jsx",
      "_useMemorable-ea60ceee.js",
      "_ApplicationLogo-ebb08f88.js",
      "_Icon-253babe4.js"
    ]
  },
  "_CheckboxInput-f7da3931.js": {
    file: "assets/CheckboxInput-f7da3931.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_Create-5948842b.js": {
    file: "assets/Create-5948842b.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-d7a8707f.js",
      "_TextInput-b8dc6570.js",
      "_InputError-384f6daa.js",
      "_TextAreaInput-fd3cc2e6.js",
      "_PrimaryButton-ee44eafd.js",
      "_SelectInput-caea256b.js",
      "_RadioInput-5848c680.js",
      "_InputLabel-11f6ccef.js",
      "resources/js/Pages/Accessories/Components/ProductsSlider.jsx",
      "_DangerButton-43405439.js",
      "_Icon-253babe4.js"
    ],
    isDynamicEntry: true
  },
  "_DangerButton-43405439.js": {
    file: "assets/DangerButton-43405439.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_FileInput-49ddbbb1.js": {
    file: "assets/FileInput-49ddbbb1.js",
    imports: [
      "resources/js/app.jsx",
      "_Icon-253babe4.js",
      "_PrimaryButton-ee44eafd.js"
    ]
  },
  "_GuestLayout-3a5ec77e.js": {
    file: "assets/GuestLayout-3a5ec77e.js",
    imports: [
      "resources/js/app.jsx",
      "_ApplicationLogo-ebb08f88.js",
      "_useMemorable-ea60ceee.js"
    ]
  },
  "_Icon-253babe4.js": {
    file: "assets/Icon-253babe4.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_InputError-384f6daa.js": {
    file: "assets/InputError-384f6daa.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_InputLabel-11f6ccef.js": {
    file: "assets/InputLabel-11f6ccef.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_IranStatesOptions-4f288355.js": {
    file: "assets/IranStatesOptions-4f288355.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_Modal-9e67a04f.js": {
    file: "assets/Modal-9e67a04f.js",
    imports: [
      "resources/js/app.jsx",
      "_transition-e2ecc6df.js"
    ]
  },
  "_Pagination-b8efb202.js": {
    file: "assets/Pagination-b8efb202.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_PrimaryButton-ee44eafd.js": {
    file: "assets/PrimaryButton-ee44eafd.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_RadioInput-5848c680.js": {
    file: "assets/RadioInput-5848c680.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_SecondaryButton-98de84e1.js": {
    file: "assets/SecondaryButton-98de84e1.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_SelectInput-caea256b.js": {
    file: "assets/SelectInput-caea256b.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_TextAreaInput-fd3cc2e6.js": {
    file: "assets/TextAreaInput-fd3cc2e6.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_TextInput-b8dc6570.js": {
    file: "assets/TextInput-b8dc6570.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_WarningButton-e19063db.js": {
    file: "assets/WarningButton-e19063db.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "__commonjs-dynamic-modules-302442b1.js": {
    file: "assets/_commonjs-dynamic-modules-302442b1.js"
  },
  "_index-b81602a2.js": {
    file: "assets/index-b81602a2.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_lottie-react.esm-7c6844e2.js": {
    file: "assets/lottie-react.esm-7c6844e2.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_manifest-b9d303ad.js": {
    file: "assets/manifest-b9d303ad.js"
  },
  "_pagination-c0e670c7.js": {
    css: [
      "assets/pagination-211b41b8.css"
    ],
    file: "assets/pagination-c0e670c7.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_transition-e2ecc6df.js": {
    file: "assets/transition-e2ecc6df.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_useFirstRender-cb9651eb.js": {
    file: "assets/useFirstRender-cb9651eb.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_useMemorable-ea60ceee.js": {
    file: "assets/useMemorable-ea60ceee.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "pagination.css": {
    file: "assets/pagination-211b41b8.css",
    src: "pagination.css"
  },
  "resources/fonts/woff/Dana-Black.woff": {
    file: "assets/Dana-Black-575de1e5.woff",
    src: "resources/fonts/woff/Dana-Black.woff"
  },
  "resources/fonts/woff/Dana-DemiBold.woff": {
    file: "assets/Dana-DemiBold-fa427dcf.woff",
    src: "resources/fonts/woff/Dana-DemiBold.woff"
  },
  "resources/fonts/woff/Dana-ExtraBlack.woff": {
    file: "assets/Dana-ExtraBlack-6c729c23.woff",
    src: "resources/fonts/woff/Dana-ExtraBlack.woff"
  },
  "resources/fonts/woff/Dana-ExtraBold.woff": {
    file: "assets/Dana-ExtraBold-0d7888d7.woff",
    src: "resources/fonts/woff/Dana-ExtraBold.woff"
  },
  "resources/fonts/woff/Dana-Fat.woff": {
    file: "assets/Dana-Fat-8831a7f0.woff",
    src: "resources/fonts/woff/Dana-Fat.woff"
  },
  "resources/fonts/woff/Dana-Hairline.woff": {
    file: "assets/Dana-Hairline-6d7bb084.woff",
    src: "resources/fonts/woff/Dana-Hairline.woff"
  },
  "resources/fonts/woff/Dana-Heavy.woff": {
    file: "assets/Dana-Heavy-e159608a.woff",
    src: "resources/fonts/woff/Dana-Heavy.woff"
  },
  "resources/fonts/woff/Dana-Light.woff": {
    file: "assets/Dana-Light-eeed4155.woff",
    src: "resources/fonts/woff/Dana-Light.woff"
  },
  "resources/fonts/woff/Dana-Medium.woff": {
    file: "assets/Dana-Medium-d0241b30.woff",
    src: "resources/fonts/woff/Dana-Medium.woff"
  },
  "resources/fonts/woff/Dana-Regular.woff": {
    file: "assets/Dana-Regular-eee25c04.woff",
    src: "resources/fonts/woff/Dana-Regular.woff"
  },
  "resources/fonts/woff/Dana-Thin.woff": {
    file: "assets/Dana-Thin-56dc1e1f.woff",
    src: "resources/fonts/woff/Dana-Thin.woff"
  },
  "resources/fonts/woff/Dana-UltraLight.woff": {
    file: "assets/Dana-UltraLight-a025f30e.woff",
    src: "resources/fonts/woff/Dana-UltraLight.woff"
  },
  "resources/fonts/woff2/Dana-Black.woff2": {
    file: "assets/Dana-Black-cdfe2203.woff2",
    src: "resources/fonts/woff2/Dana-Black.woff2"
  },
  "resources/fonts/woff2/Dana-DemiBold.woff2": {
    file: "assets/Dana-DemiBold-34870445.woff2",
    src: "resources/fonts/woff2/Dana-DemiBold.woff2"
  },
  "resources/fonts/woff2/Dana-ExtraBlack.woff2": {
    file: "assets/Dana-ExtraBlack-3208afe0.woff2",
    src: "resources/fonts/woff2/Dana-ExtraBlack.woff2"
  },
  "resources/fonts/woff2/Dana-ExtraBold.woff2": {
    file: "assets/Dana-ExtraBold-08dea612.woff2",
    src: "resources/fonts/woff2/Dana-ExtraBold.woff2"
  },
  "resources/fonts/woff2/Dana-Fat.woff2": {
    file: "assets/Dana-Fat-1f7b7061.woff2",
    src: "resources/fonts/woff2/Dana-Fat.woff2"
  },
  "resources/fonts/woff2/Dana-Hairline.woff2": {
    file: "assets/Dana-Hairline-7712cf11.woff2",
    src: "resources/fonts/woff2/Dana-Hairline.woff2"
  },
  "resources/fonts/woff2/Dana-Heavy.woff2": {
    file: "assets/Dana-Heavy-091eb261.woff2",
    src: "resources/fonts/woff2/Dana-Heavy.woff2"
  },
  "resources/fonts/woff2/Dana-Light.woff2": {
    file: "assets/Dana-Light-e07a4868.woff2",
    src: "resources/fonts/woff2/Dana-Light.woff2"
  },
  "resources/fonts/woff2/Dana-Medium.woff2": {
    file: "assets/Dana-Medium-d623f857.woff2",
    src: "resources/fonts/woff2/Dana-Medium.woff2"
  },
  "resources/fonts/woff2/Dana-Regular.woff2": {
    file: "assets/Dana-Regular-43506011.woff2",
    src: "resources/fonts/woff2/Dana-Regular.woff2"
  },
  "resources/fonts/woff2/Dana-Thin.woff2": {
    file: "assets/Dana-Thin-bec2bd8a.woff2",
    src: "resources/fonts/woff2/Dana-Thin.woff2"
  },
  "resources/fonts/woff2/Dana-UltraLight.woff2": {
    file: "assets/Dana-UltraLight-24615a03.woff2",
    src: "resources/fonts/woff2/Dana-UltraLight.woff2"
  },
  "resources/js/Pages/Accessories/Components/ProductsSlider.jsx": {
    file: "assets/ProductsSlider-ab8a9e83.js",
    imports: [
      "resources/js/app.jsx",
      "_pagination-c0e670c7.js",
      "_RadioInput-5848c680.js",
      "_InputLabel-11f6ccef.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Accessories/Components/ProductsSlider.jsx"
  },
  "resources/js/Pages/Accessories/Index.jsx": {
    file: "assets/Index-069428f0.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-d7a8707f.js",
      "_SecondaryButton-98de84e1.js",
      "_DangerButton-43405439.js",
      "_Modal-9e67a04f.js",
      "_PrimaryButton-ee44eafd.js",
      "_Pagination-b8efb202.js",
      "_useMemorable-ea60ceee.js",
      "_ApplicationLogo-ebb08f88.js",
      "_Icon-253babe4.js",
      "_transition-e2ecc6df.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Accessories/Index.jsx"
  },
  "resources/js/Pages/Accessories/Show.jsx": {
    file: "assets/Show-5c51c42a.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-d7a8707f.js",
      "_WarningButton-e19063db.js",
      "_PrimaryButton-ee44eafd.js",
      "_SecondaryButton-98de84e1.js",
      "_useMemorable-ea60ceee.js",
      "_ApplicationLogo-ebb08f88.js",
      "_Icon-253babe4.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Accessories/Show.jsx"
  },
  "resources/js/Pages/Admin/Accessories.jsx": {
    file: "assets/Accessories-7175e037.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-d7a8707f.js",
      "_Pagination-b8efb202.js",
      "_useFirstRender-cb9651eb.js",
      "_TextInput-b8dc6570.js",
      "_useMemorable-ea60ceee.js",
      "_ApplicationLogo-ebb08f88.js",
      "_Icon-253babe4.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Admin/Accessories.jsx"
  },
  "resources/js/Pages/Admin/Records.jsx": {
    file: "assets/Records-16abf5fe.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-d7a8707f.js",
      "_Pagination-b8efb202.js",
      "_TextInput-b8dc6570.js",
      "_useFirstRender-cb9651eb.js",
      "_useMemorable-ea60ceee.js",
      "_ApplicationLogo-ebb08f88.js",
      "_Icon-253babe4.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Admin/Records.jsx"
  },
  "resources/js/Pages/Auth/Address.jsx": {
    file: "assets/Address-0d3f5642.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-3a5ec77e.js",
      "_InputError-384f6daa.js",
      "_PrimaryButton-ee44eafd.js",
      "_TextInput-b8dc6570.js",
      "_TextAreaInput-fd3cc2e6.js",
      "_RadioInput-5848c680.js",
      "_InputLabel-11f6ccef.js",
      "_Icon-253babe4.js",
      "_DangerButton-43405439.js",
      "_ApplicationLogo-ebb08f88.js",
      "_useMemorable-ea60ceee.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Address.jsx"
  },
  "resources/js/Pages/Auth/ConfirmPassword.jsx": {
    file: "assets/ConfirmPassword-9e51b708.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-3a5ec77e.js",
      "_InputError-384f6daa.js",
      "_InputLabel-11f6ccef.js",
      "_PrimaryButton-ee44eafd.js",
      "_TextInput-b8dc6570.js",
      "_ApplicationLogo-ebb08f88.js",
      "_useMemorable-ea60ceee.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/ConfirmPassword.jsx"
  },
  "resources/js/Pages/Auth/ForgotPassword.jsx": {
    file: "assets/ForgotPassword-08d540e1.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-3a5ec77e.js",
      "_InputError-384f6daa.js",
      "_PrimaryButton-ee44eafd.js",
      "_TextInput-b8dc6570.js",
      "_ApplicationLogo-ebb08f88.js",
      "_useMemorable-ea60ceee.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/ForgotPassword.jsx"
  },
  "resources/js/Pages/Auth/Info.jsx": {
    file: "assets/Info-a163f105.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-3a5ec77e.js",
      "_InputError-384f6daa.js",
      "_PrimaryButton-ee44eafd.js",
      "_TextInput-b8dc6570.js",
      "_TextAreaInput-fd3cc2e6.js",
      "_FileInput-49ddbbb1.js",
      "_InputLabel-11f6ccef.js",
      "_ApplicationLogo-ebb08f88.js",
      "_useMemorable-ea60ceee.js",
      "_Icon-253babe4.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Info.jsx"
  },
  "resources/js/Pages/Auth/Login.jsx": {
    file: "assets/Login-76d3985c.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-3a5ec77e.js",
      "_InputError-384f6daa.js",
      "_InputLabel-11f6ccef.js",
      "_PrimaryButton-ee44eafd.js",
      "_TextInput-b8dc6570.js",
      "_CheckboxInput-f7da3931.js",
      "_WarningButton-e19063db.js",
      "_Icon-253babe4.js",
      "_ApplicationLogo-ebb08f88.js",
      "_useMemorable-ea60ceee.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Login.jsx"
  },
  "resources/js/Pages/Auth/Register.jsx": {
    file: "assets/Register-bbed0294.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-3a5ec77e.js",
      "_InputError-384f6daa.js",
      "_PrimaryButton-ee44eafd.js",
      "_TextInput-b8dc6570.js",
      "_SelectInput-caea256b.js",
      "_IranStatesOptions-4f288355.js",
      "_ApplicationLogo-ebb08f88.js",
      "_useMemorable-ea60ceee.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Register.jsx"
  },
  "resources/js/Pages/Auth/ResetPassword.jsx": {
    file: "assets/ResetPassword-a66078fd.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-3a5ec77e.js",
      "_InputError-384f6daa.js",
      "_PrimaryButton-ee44eafd.js",
      "_TextInput-b8dc6570.js",
      "_ApplicationLogo-ebb08f88.js",
      "_useMemorable-ea60ceee.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/ResetPassword.jsx"
  },
  "resources/js/Pages/Auth/VerifyEmail.jsx": {
    file: "assets/VerifyEmail-32379f25.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-3a5ec77e.js",
      "_PrimaryButton-ee44eafd.js",
      "_ApplicationLogo-ebb08f88.js",
      "_useMemorable-ea60ceee.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/VerifyEmail.jsx"
  },
  "resources/js/Pages/Auth/WaitForVerify.jsx": {
    file: "assets/WaitForVerify-a5ce0e0e.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-3a5ec77e.js",
      "_lottie-react.esm-7c6844e2.js",
      "_PrimaryButton-ee44eafd.js",
      "_DangerButton-43405439.js",
      "_ApplicationLogo-ebb08f88.js",
      "_useMemorable-ea60ceee.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/WaitForVerify.jsx"
  },
  "resources/js/Pages/Dashboards/Admin.jsx": {
    file: "assets/Admin-79851154.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-d7a8707f.js",
      "_ArrowLink-82e0ea36.js",
      "_useMemorable-ea60ceee.js",
      "_ApplicationLogo-ebb08f88.js",
      "_Icon-253babe4.js",
      "__commonjs-dynamic-modules-302442b1.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Dashboards/Admin.jsx"
  },
  "resources/js/Pages/Dashboards/User.jsx": {
    file: "assets/User-08ecea5c.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-d7a8707f.js",
      "_ArrowLink-82e0ea36.js",
      "_useMemorable-ea60ceee.js",
      "_ApplicationLogo-ebb08f88.js",
      "_Icon-253babe4.js",
      "__commonjs-dynamic-modules-302442b1.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Dashboards/User.jsx"
  },
  "resources/js/Pages/Download/Accessory.jsx": {
    file: "assets/Accessory-13f5f0f2.js",
    imports: [
      "resources/js/app.jsx",
      "_manifest-b9d303ad.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Download/Accessory.jsx"
  },
  "resources/js/Pages/Download/Record.jsx": {
    file: "assets/Record-c27b5794.js",
    imports: [
      "resources/js/app.jsx",
      "_manifest-b9d303ad.js",
      "__commonjs-dynamic-modules-302442b1.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Download/Record.jsx"
  },
  "resources/js/Pages/Patients/Create.jsx": {
    file: "assets/Create-3b9f17a2.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-d7a8707f.js",
      "_TextInput-b8dc6570.js",
      "_InputError-384f6daa.js",
      "_TextAreaInput-fd3cc2e6.js",
      "_PrimaryButton-ee44eafd.js",
      "_SelectInput-caea256b.js",
      "_IranStatesOptions-4f288355.js",
      "_DangerButton-43405439.js",
      "_useMemorable-ea60ceee.js",
      "_ApplicationLogo-ebb08f88.js",
      "_Icon-253babe4.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Create.jsx"
  },
  "resources/js/Pages/Patients/Edit.jsx": {
    file: "assets/Edit-5e99c500.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-d7a8707f.js",
      "_TextInput-b8dc6570.js",
      "_InputError-384f6daa.js",
      "_TextAreaInput-fd3cc2e6.js",
      "_PrimaryButton-ee44eafd.js",
      "_SelectInput-caea256b.js",
      "_IranStatesOptions-4f288355.js",
      "_DangerButton-43405439.js",
      "_useMemorable-ea60ceee.js",
      "_ApplicationLogo-ebb08f88.js",
      "_Icon-253babe4.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Edit.jsx"
  },
  "resources/js/Pages/Patients/Index.jsx": {
    file: "assets/Index-8ee2c605.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-d7a8707f.js",
      "_SecondaryButton-98de84e1.js",
      "_DangerButton-43405439.js",
      "_Modal-9e67a04f.js",
      "_Pagination-b8efb202.js",
      "_useMemorable-ea60ceee.js",
      "_ApplicationLogo-ebb08f88.js",
      "_Icon-253babe4.js",
      "_transition-e2ecc6df.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Index.jsx"
  },
  "resources/js/Pages/Patients/Partials/DeleteUserForm.jsx": {
    file: "assets/DeleteUserForm-07e76751.js",
    imports: [
      "resources/js/app.jsx",
      "_DangerButton-43405439.js",
      "_InputError-384f6daa.js",
      "_InputLabel-11f6ccef.js",
      "_Modal-9e67a04f.js",
      "_SecondaryButton-98de84e1.js",
      "_TextInput-b8dc6570.js",
      "_transition-e2ecc6df.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Partials/DeleteUserForm.jsx"
  },
  "resources/js/Pages/Patients/Partials/UpdatePasswordForm.jsx": {
    file: "assets/UpdatePasswordForm-1591f402.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-384f6daa.js",
      "_InputLabel-11f6ccef.js",
      "_PrimaryButton-ee44eafd.js",
      "_TextInput-b8dc6570.js",
      "_transition-e2ecc6df.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Partials/UpdatePasswordForm.jsx"
  },
  "resources/js/Pages/Patients/Partials/UpdateProfileInformationForm.jsx": {
    file: "assets/UpdateProfileInformationForm-9cc8adac.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-384f6daa.js",
      "_InputLabel-11f6ccef.js",
      "_PrimaryButton-ee44eafd.js",
      "_TextInput-b8dc6570.js",
      "_transition-e2ecc6df.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Partials/UpdateProfileInformationForm.jsx"
  },
  "resources/js/Pages/Products/CreateOrEdit.jsx": {
    file: "assets/CreateOrEdit-9089af52.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-d7a8707f.js",
      "_TextInput-b8dc6570.js",
      "_InputError-384f6daa.js",
      "_PrimaryButton-ee44eafd.js",
      "_SelectInput-caea256b.js",
      "_DangerButton-43405439.js",
      "_Icon-253babe4.js",
      "_CheckboxInput-f7da3931.js",
      "_InputLabel-11f6ccef.js",
      "_useMemorable-ea60ceee.js",
      "_ApplicationLogo-ebb08f88.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Products/CreateOrEdit.jsx"
  },
  "resources/js/Pages/Products/Index.jsx": {
    file: "assets/Index-69d037e0.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-d7a8707f.js",
      "_SecondaryButton-98de84e1.js",
      "_DangerButton-43405439.js",
      "_Modal-9e67a04f.js",
      "_PrimaryButton-ee44eafd.js",
      "_Pagination-b8efb202.js",
      "_TextInput-b8dc6570.js",
      "_useMemorable-ea60ceee.js",
      "_ApplicationLogo-ebb08f88.js",
      "_Icon-253babe4.js",
      "_transition-e2ecc6df.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Products/Index.jsx"
  },
  "resources/js/Pages/Profile/Edit.jsx": {
    file: "assets/Edit-3f456da5.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-d7a8707f.js",
      "_GuestLayout-3a5ec77e.js",
      "_TextInput-b8dc6570.js",
      "_InputError-384f6daa.js",
      "_TextAreaInput-fd3cc2e6.js",
      "_PrimaryButton-ee44eafd.js",
      "_DangerButton-43405439.js",
      "_SelectInput-caea256b.js",
      "_IranStatesOptions-4f288355.js",
      "_FileInput-49ddbbb1.js",
      "_RadioInput-5848c680.js",
      "_InputLabel-11f6ccef.js",
      "_useMemorable-ea60ceee.js",
      "_ApplicationLogo-ebb08f88.js",
      "_Icon-253babe4.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Profile/Edit.jsx"
  },
  "resources/js/Pages/Profile/Index.jsx": {
    file: "assets/Index-010db6fe.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-d7a8707f.js",
      "_WarningButton-e19063db.js",
      "_useMemorable-ea60ceee.js",
      "_ApplicationLogo-ebb08f88.js",
      "_Icon-253babe4.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Profile/Index.jsx"
  },
  "resources/js/Pages/Records/Components/ProductsSlider.jsx": {
    file: "assets/ProductsSlider-6925823a.js",
    imports: [
      "resources/js/app.jsx",
      "_pagination-c0e670c7.js",
      "_RadioInput-5848c680.js",
      "_InputLabel-11f6ccef.js",
      "_CheckboxInput-f7da3931.js",
      "_Icon-253babe4.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Components/ProductsSlider.jsx"
  },
  "resources/js/Pages/Records/Components/Steps.jsx": {
    file: "assets/Steps-b4617f08.js",
    imports: [
      "resources/js/app.jsx",
      "resources/js/Pages/Records/Partials/Step.jsx",
      "_Icon-253babe4.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Components/Steps.jsx"
  },
  "resources/js/Pages/Records/Index.jsx": {
    file: "assets/Index-e9ace0eb.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-d7a8707f.js",
      "_SecondaryButton-98de84e1.js",
      "_DangerButton-43405439.js",
      "_Modal-9e67a04f.js",
      "_PrimaryButton-ee44eafd.js",
      "_Pagination-b8efb202.js",
      "_useMemorable-ea60ceee.js",
      "_ApplicationLogo-ebb08f88.js",
      "_Icon-253babe4.js",
      "_transition-e2ecc6df.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Index.jsx"
  },
  "resources/js/Pages/Records/Partials/Step.jsx": {
    file: "assets/Step-4843bfa0.js",
    imports: [
      "resources/js/app.jsx"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Partials/Step.jsx"
  },
  "resources/js/Pages/Records/Show.jsx": {
    file: "assets/Show-05b3e86a.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-d7a8707f.js",
      "_WarningButton-e19063db.js",
      "_PrimaryButton-ee44eafd.js",
      "_SecondaryButton-98de84e1.js",
      "_useMemorable-ea60ceee.js",
      "_ApplicationLogo-ebb08f88.js",
      "_Icon-253babe4.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Show.jsx"
  },
  "resources/js/Pages/Settings/CreateOrEdit.jsx": {
    file: "assets/CreateOrEdit-8f8aa7a6.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-d7a8707f.js",
      "_TextInput-b8dc6570.js",
      "_InputError-384f6daa.js",
      "_PrimaryButton-ee44eafd.js",
      "_DangerButton-43405439.js",
      "_useMemorable-ea60ceee.js",
      "_ApplicationLogo-ebb08f88.js",
      "_Icon-253babe4.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/CreateOrEdit.jsx"
  },
  "resources/js/Pages/Settings/Index.jsx": {
    file: "assets/Index-9820f58d.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-d7a8707f.js",
      "_SecondaryButton-98de84e1.js",
      "_DangerButton-43405439.js",
      "_Modal-9e67a04f.js",
      "_PrimaryButton-ee44eafd.js",
      "_Pagination-b8efb202.js",
      "_useMemorable-ea60ceee.js",
      "_ApplicationLogo-ebb08f88.js",
      "_Icon-253babe4.js",
      "_transition-e2ecc6df.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/Index.jsx"
  },
  "resources/js/Pages/Settings/OffLimits.jsx": {
    file: "assets/OffLimits-5854d3b1.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-d7a8707f.js",
      "_PrimaryButton-ee44eafd.js",
      "_lottie-react.esm-7c6844e2.js",
      "_useMemorable-ea60ceee.js",
      "_ApplicationLogo-ebb08f88.js",
      "_Icon-253babe4.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/OffLimits.jsx"
  },
  "resources/js/Pages/Settings/OutOfSchedule.jsx": {
    file: "assets/OutOfSchedule-a1694f73.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-d7a8707f.js",
      "_PrimaryButton-ee44eafd.js",
      "_lottie-react.esm-7c6844e2.js",
      "_useMemorable-ea60ceee.js",
      "_ApplicationLogo-ebb08f88.js",
      "_Icon-253babe4.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/OutOfSchedule.jsx"
  },
  "resources/js/Pages/Terms.jsx": {
    file: "assets/Terms-ac731961.js",
    imports: [
      "resources/js/app.jsx",
      "_ApplicationLogo-ebb08f88.js",
      "_Icon-253babe4.js",
      "_PrimaryButton-ee44eafd.js",
      "_index-b81602a2.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Terms.jsx"
  },
  "resources/js/Pages/Users/Create.jsx": {
    file: "assets/Create-c56d3493.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-d7a8707f.js",
      "_TextInput-b8dc6570.js",
      "_InputError-384f6daa.js",
      "_TextAreaInput-fd3cc2e6.js",
      "_PrimaryButton-ee44eafd.js",
      "_SelectInput-caea256b.js",
      "_IranStatesOptions-4f288355.js",
      "_DangerButton-43405439.js",
      "_useMemorable-ea60ceee.js",
      "_ApplicationLogo-ebb08f88.js",
      "_Icon-253babe4.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Create.jsx"
  },
  "resources/js/Pages/Users/Edit.jsx": {
    file: "assets/Edit-a1010a42.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-d7a8707f.js",
      "_TextAreaInput-fd3cc2e6.js",
      "_TextInput-b8dc6570.js",
      "_InputError-384f6daa.js",
      "_PrimaryButton-ee44eafd.js",
      "_DangerButton-43405439.js",
      "_SelectInput-caea256b.js",
      "_WarningButton-e19063db.js",
      "_Modal-9e67a04f.js",
      "_CheckboxInput-f7da3931.js",
      "_InputLabel-11f6ccef.js",
      "_useMemorable-ea60ceee.js",
      "_ApplicationLogo-ebb08f88.js",
      "_Icon-253babe4.js",
      "_transition-e2ecc6df.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Edit.jsx"
  },
  "resources/js/Pages/Users/Index.jsx": {
    file: "assets/Index-0ae76e02.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-d7a8707f.js",
      "_Pagination-b8efb202.js",
      "_TextInput-b8dc6570.js",
      "_useFirstRender-cb9651eb.js",
      "_useMemorable-ea60ceee.js",
      "_ApplicationLogo-ebb08f88.js",
      "_Icon-253babe4.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Index.jsx"
  },
  "resources/js/Pages/Users/NotCompleted.jsx": {
    file: "assets/NotCompleted-dbb320d1.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-d7a8707f.js",
      "_Pagination-b8efb202.js",
      "_SecondaryButton-98de84e1.js",
      "_DangerButton-43405439.js",
      "_Modal-9e67a04f.js",
      "_useMemorable-ea60ceee.js",
      "_ApplicationLogo-ebb08f88.js",
      "_Icon-253babe4.js",
      "_transition-e2ecc6df.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/NotCompleted.jsx"
  },
  "resources/js/Pages/Users/Partials/DeleteUserForm.jsx": {
    file: "assets/DeleteUserForm-711a380d.js",
    imports: [
      "resources/js/app.jsx",
      "_DangerButton-43405439.js",
      "_InputError-384f6daa.js",
      "_InputLabel-11f6ccef.js",
      "_Modal-9e67a04f.js",
      "_SecondaryButton-98de84e1.js",
      "_TextInput-b8dc6570.js",
      "_transition-e2ecc6df.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Partials/DeleteUserForm.jsx"
  },
  "resources/js/Pages/Users/Partials/UpdatePasswordForm.jsx": {
    file: "assets/UpdatePasswordForm-7e1a83de.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-384f6daa.js",
      "_InputLabel-11f6ccef.js",
      "_PrimaryButton-ee44eafd.js",
      "_TextInput-b8dc6570.js",
      "_transition-e2ecc6df.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Partials/UpdatePasswordForm.jsx"
  },
  "resources/js/Pages/Users/Partials/UpdateProfileInformationForm.jsx": {
    file: "assets/UpdateProfileInformationForm-acb9403b.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-384f6daa.js",
      "_InputLabel-11f6ccef.js",
      "_PrimaryButton-ee44eafd.js",
      "_TextInput-b8dc6570.js",
      "_transition-e2ecc6df.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Partials/UpdateProfileInformationForm.jsx"
  },
  "resources/js/Pages/Welcome.jsx": {
    file: "assets/Welcome-fce87d4a.js",
    imports: [
      "resources/js/app.jsx",
      "_ApplicationLogo-ebb08f88.js",
      "_Icon-253babe4.js",
      "_PrimaryButton-ee44eafd.js",
      "_index-b81602a2.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Welcome.jsx"
  },
  "resources/js/app.css": {
    file: "assets/app-ba1a09f8.css",
    src: "resources/js/app.css"
  },
  "resources/js/app.jsx": {
    assets: [
      "assets/Dana-Hairline-7712cf11.woff2",
      "assets/Dana-Hairline-6d7bb084.woff",
      "assets/Dana-Thin-bec2bd8a.woff2",
      "assets/Dana-Thin-56dc1e1f.woff",
      "assets/Dana-UltraLight-24615a03.woff2",
      "assets/Dana-UltraLight-a025f30e.woff",
      "assets/Dana-Light-e07a4868.woff2",
      "assets/Dana-Light-eeed4155.woff",
      "assets/Dana-Medium-d623f857.woff2",
      "assets/Dana-Medium-d0241b30.woff",
      "assets/Dana-DemiBold-34870445.woff2",
      "assets/Dana-DemiBold-fa427dcf.woff",
      "assets/Dana-ExtraBold-08dea612.woff2",
      "assets/Dana-ExtraBold-0d7888d7.woff",
      "assets/Dana-Black-cdfe2203.woff2",
      "assets/Dana-Black-575de1e5.woff",
      "assets/Dana-ExtraBlack-3208afe0.woff2",
      "assets/Dana-ExtraBlack-6c729c23.woff",
      "assets/Dana-Heavy-091eb261.woff2",
      "assets/Dana-Heavy-e159608a.woff",
      "assets/Dana-Fat-1f7b7061.woff2",
      "assets/Dana-Fat-8831a7f0.woff",
      "assets/Dana-Regular-43506011.woff2",
      "assets/Dana-Regular-eee25c04.woff"
    ],
    css: [
      "assets/app-ba1a09f8.css"
    ],
    dynamicImports: [
      "resources/js/Pages/Accessories/Components/ProductsSlider.jsx",
      "_Create-5948842b.js",
      "resources/js/Pages/Accessories/Index.jsx",
      "resources/js/Pages/Accessories/Show.jsx",
      "_Create-5948842b.js",
      "_Create-5948842b.js",
      "resources/js/Pages/Admin/Accessories.jsx",
      "resources/js/Pages/Admin/Records.jsx",
      "resources/js/Pages/Auth/Address.jsx",
      "resources/js/Pages/Auth/ConfirmPassword.jsx",
      "resources/js/Pages/Auth/ForgotPassword.jsx",
      "resources/js/Pages/Auth/Info.jsx",
      "resources/js/Pages/Auth/Login.jsx",
      "resources/js/Pages/Auth/Register.jsx",
      "resources/js/Pages/Auth/ResetPassword.jsx",
      "resources/js/Pages/Auth/VerifyEmail.jsx",
      "resources/js/Pages/Auth/WaitForVerify.jsx",
      "resources/js/Pages/Dashboards/Admin.jsx",
      "resources/js/Pages/Dashboards/User.jsx",
      "resources/js/Pages/Download/Accessory.jsx",
      "resources/js/Pages/Download/Record.jsx",
      "resources/js/Pages/Patients/Create.jsx",
      "resources/js/Pages/Patients/Edit.jsx",
      "resources/js/Pages/Patients/Index.jsx",
      "resources/js/Pages/Patients/Partials/DeleteUserForm.jsx",
      "resources/js/Pages/Patients/Partials/UpdatePasswordForm.jsx",
      "resources/js/Pages/Patients/Partials/UpdateProfileInformationForm.jsx",
      "resources/js/Pages/Products/CreateOrEdit.jsx",
      "resources/js/Pages/Products/Index.jsx",
      "resources/js/Pages/Profile/Edit.jsx",
      "resources/js/Pages/Profile/Index.jsx",
      "_AidInputs-b1365da7.js",
      "resources/js/Pages/Records/Components/ProductsSlider.jsx",
      "resources/js/Pages/Records/Components/Steps.jsx",
      "_AidInputs-b1365da7.js",
      "resources/js/Pages/Records/Index.jsx",
      "resources/js/Pages/Records/Partials/Step.jsx",
      "resources/js/Pages/Records/Show.jsx",
      "_AidInputs-b1365da7.js",
      "_AidInputs-b1365da7.js",
      "_AidInputs-b1365da7.js",
      "_AidInputs-b1365da7.js",
      "_AidInputs-b1365da7.js",
      "resources/js/Pages/Settings/CreateOrEdit.jsx",
      "resources/js/Pages/Settings/Index.jsx",
      "resources/js/Pages/Settings/OffLimits.jsx",
      "resources/js/Pages/Settings/OutOfSchedule.jsx",
      "resources/js/Pages/Terms.jsx",
      "resources/js/Pages/Users/Create.jsx",
      "resources/js/Pages/Users/Edit.jsx",
      "resources/js/Pages/Users/Index.jsx",
      "resources/js/Pages/Users/NotCompleted.jsx",
      "resources/js/Pages/Users/Partials/DeleteUserForm.jsx",
      "resources/js/Pages/Users/Partials/UpdatePasswordForm.jsx",
      "resources/js/Pages/Users/Partials/UpdateProfileInformationForm.jsx",
      "resources/js/Pages/Welcome.jsx"
    ],
    file: "assets/app-b383427d.js",
    isEntry: true,
    src: "resources/js/app.jsx"
  }
};
export {
  manifest as m
};
