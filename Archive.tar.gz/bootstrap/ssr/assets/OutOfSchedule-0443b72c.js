import { j as jsxs, a as jsx } from "../ssr.js";
import { A as Authenticated } from "./AuthenticatedLayout-5fd2cf47.js";
import { Head } from "@inertiajs/react";
import { P as PrimaryButton } from "./PrimaryButton-6a55fe23.js";
import { Player } from "@lottiefiles/react-lottie-player";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "react-toastify";
import "./useMemorable-ea291d99.js";
import "react";
import "./ApplicationLogo-40648ed6.js";
import "./Icon-2f3a2698.js";
function OutOfSchedule({ start_time, end_time }) {
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      header: "بازه زمانی غیرمجاز",
      children: [
        /* @__PURE__ */ jsx(Head, { title: "بازه زمانی غیرمجاز" }),
        /* @__PURE__ */ jsxs("div", { className: "w-full text-center text-gray-700 dark:text-slate-300", children: [
          /* @__PURE__ */ jsx(
            Player,
            {
              autoplay: true,
              loop: true,
              src: "/storage/animations/warning.json",
              style: { height: "300px" }
            }
          ),
          /* @__PURE__ */ jsx("h4", { className: "font-bold text-lg", children: "بازه زمانی غیرمجاز" }),
          /* @__PURE__ */ jsx("p", { className: "px-40 mt-5 mb-12", children: "شما در این بازه زمانی مجاز به سفارش گذاری نمی باشید." }),
          (start_time & end_time) === 1 && /* @__PURE__ */ jsxs("div", { className: "text-sm font-semibold", children: [
            /* @__PURE__ */ jsxs("p", { className: "px-40 mt-8", children: [
              "شروع سفارش گذاری: ",
              start_time
            ] }),
            /* @__PURE__ */ jsxs("p", { className: "px-40 mt-4 mb-12", children: [
              "پایان سفارش گذاری: ",
              end_time
            ] })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "flex justify-center", children: /* @__PURE__ */ jsx(
            PrimaryButton,
            {
              className: "w-3/12 ml-5 !px-4 !py-2",
              link: true,
              href: route("records.index"),
              children: "بازگشت به صفحه سفارشات"
            }
          ) })
        ] })
      ]
    }
  );
}
export {
  OutOfSchedule as default
};
