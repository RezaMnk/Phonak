import { j as jsxs, a as jsx } from "../ssr.js";
import { A as Authenticated } from "./AuthenticatedLayout-c3b08c0f.js";
import { useForm, router, Head, Link } from "@inertiajs/react";
import { S as SecondaryButton } from "./SecondaryButton-5e4fee1b.js";
import { D as DangerButton } from "./DangerButton-d6ee3472.js";
import { M as Modal } from "./Modal-dd933eed.js";
import { useState, useEffect } from "react";
import { P as PrimaryButton } from "./PrimaryButton-6a55fe23.js";
import { P as Pagination } from "./Pagination-781980f1.js";
import { T as TextInput } from "./TextInput-ca1f9780.js";
import { u as useFirstRender } from "./useFirstRender-5b0e5bdf.js";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "react-toastify";
import "./useMemorable-ea291d99.js";
import "./ApplicationLogo-40648ed6.js";
import "./Icon-2f3a2698.js";
import "@headlessui/react";
function Index({ products }) {
  const [deleteModalShow, setDeleteModalShow] = useState(false);
  const [modalProduct, setModalProduct] = useState({});
  const [search, setSearch] = useState(new URLSearchParams(window.location.search).get("search") || "");
  const firstRender = useFirstRender();
  const data_products = products.data;
  const [productInventories, setProductInventories] = useState(
    data_products.reduce((acc, product) => ({ ...acc, [product.id]: product.inventory }), {})
  );
  const {
    delete: destroy,
    processing
  } = useForm();
  useEffect(() => {
    if (!firstRender) {
      const delayDebounceFn = setTimeout(() => {
        router.get(route("products.index"), {
          search
        });
      }, 1500);
      return () => clearTimeout(delayDebounceFn);
    }
  }, [search]);
  const deletePatient = (e) => {
    e.preventDefault();
    destroy(route("products.destroy", modalProduct), {
      preserveScroll: true,
      onSuccess: () => closeModal()
    });
  };
  const updateInventory = (product_id, event) => {
    let value = parseInt(event.target.value);
    setProductInventories((prev) => {
      return {
        ...prev,
        [product_id]: value
      };
    });
  };
  const submitInventory = (product_id, value) => {
    router.post(route("products.update_inventory", product_id), {
      inventory: value
    }, {
      preserveScroll: true
    });
  };
  const closeModal = () => {
    setDeleteModalShow(false);
  };
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      header: "محصولات",
      breadcrumbs: {
        "محصولات": route("products.index")
      },
      headerExtra: /* @__PURE__ */ jsxs("div", { className: "flex flex-col flex-col-reverse md:flex-row gap-2", children: [
        /* @__PURE__ */ jsx("form", { id: "search", children: /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "search-input",
            name: "search",
            value: search,
            label: "جستوجو...",
            className: "!py-2 !px-4",
            autoComplete: "name",
            onChange: (e) => setSearch(e.target.value),
            isFocused: !!search
          }
        ) }),
        /* @__PURE__ */ jsx(
          PrimaryButton,
          {
            link: true,
            href: route("products.create"),
            className: "!px-4 !py-2 text-xs",
            children: "افزون محصول"
          }
        )
      ] }),
      children: [
        /* @__PURE__ */ jsx(Head, { title: "محصولات" }),
        /* @__PURE__ */ jsx("div", { className: "relative overflow-x-auto rounded-lg", children: /* @__PURE__ */ jsxs("table", { className: "w-full text-right text-gray-500 dark:text-slate-400", children: [
          /* @__PURE__ */ jsx("thead", { className: "text-xs text-gray-700 dark:text-gray-300 bg-gray-50 dark:bg-slate-700", children: /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx("th", { scope: "col", className: "px-6 py-3 hidden xl:table-cell", children: "تصویر محصول" }),
            /* @__PURE__ */ jsx("th", { scope: "col", className: "px-6 py-3", children: "نام محصول" }),
            /* @__PURE__ */ jsx("th", { scope: "col", className: "px-6 py-3 hidden xl:table-cell", children: "برند" }),
            /* @__PURE__ */ jsx("th", { scope: "col", className: "px-6 py-3", children: "دسته بندی" }),
            /* @__PURE__ */ jsx("th", { scope: "col", className: "px-6 py-3 hidden xl:table-cell", children: "موجودی" }),
            /* @__PURE__ */ jsx("th", { scope: "col", className: "px-6 py-3", children: "وضعیت" }),
            /* @__PURE__ */ jsx("th", { scope: "col", className: "px-6 py-3", children: "عملیات" })
          ] }) }),
          /* @__PURE__ */ jsx("tbody", { children: Object.keys(data_products).length ? Object.values(data_products).map((product) => {
            const is_last = data_products[Object.keys(data_products).length - 1] === product;
            return /* @__PURE__ */ jsxs("tr", { className: `bg-white dark:bg-slate-900 ${!is_last ? "border-b" : ""} border-gray-200 dark:border-slate-600`, children: [
              /* @__PURE__ */ jsx("td", { className: "px-6 py-2 hidden xl:table-cell", children: /* @__PURE__ */ jsx("img", { src: product.image_url, alt: product.name, className: "w-14 h-14 rounded-lg object-cover bg-gray-100 dark:bg-slate-800 p-1" }) }),
              /* @__PURE__ */ jsx(
                "th",
                {
                  scope: "row",
                  className: "px-6 py-4 text-sm font-medium text-gray-700 dark:text-slate-300 whitespace-nowrap",
                  children: product.name
                }
              ),
              /* @__PURE__ */ jsxs("td", { className: "px-6 py-4 hidden xl:table-cell", children: [
                product.brand === "phonak" && /* @__PURE__ */ jsx("span", { className: "inline-flex whitespace-nowrap items-center rounded-md bg-green-50 dark:bg-green-500/30 px-2 py-1 text-sm font-medium text-green-800 dark:text-green-300/70 ring-1 ring-inset ring-green-600/20", children: product.brand }),
                product.brand === "hansaton" && /* @__PURE__ */ jsx("span", { className: "inline-flex whitespace-nowrap items-center rounded-md bg-gray-50 dark:bg-gray-500/30 px-2 py-1 text-sm font-medium text-gray-800 dark:text-gray-300/70 ring-1 ring-inset ring-gray-600/20", children: product.brand }),
                product.brand === "unitron" && /* @__PURE__ */ jsx("span", { className: "inline-flex whitespace-nowrap items-center rounded-md bg-blue-50 dark:bg-blue-500/30 px-2 py-1 text-sm font-medium text-blue-800 dark:text-blue-300/70 ring-1 ring-inset ring-blue-600/20", children: product.brand }),
                product.brand === "rayovac" && /* @__PURE__ */ jsx("span", { className: "inline-flex whitespace-nowrap items-center rounded-md bg-red-50 dark:bg-red-500/30 px-2 py-1 text-sm font-medium text-red-800 dark:text-red-300/70 ring-1 ring-inset ring-red-600/20", children: product.brand }),
                product.brand === "detax" && /* @__PURE__ */ jsx("span", { className: "inline-flex whitespace-nowrap items-center rounded-md bg-stone-50 dark:bg-stone-500/30 px-2 py-1 text-sm font-medium text-stone-800 dark:text-stone-300/70 ring-1 ring-inset ring-stone-600/20", children: product.brand }),
                product.brand === "etc" && /* @__PURE__ */ jsx("span", { className: "inline-flex whitespace-nowrap items-center rounded-md bg-pink-50 dark:bg-pink-500/30 px-2 py-1 text-sm font-medium text-pink-800 dark:text-pink-300/70 ring-1 ring-inset ring-pink-600/20", children: "سایر" })
              ] }),
              /* @__PURE__ */ jsx("td", { className: "px-6 py-4", children: product.category }),
              /* @__PURE__ */ jsx("td", { className: "px-6 py-4 hidden xl:table-cell", children: /* @__PURE__ */ jsx(
                TextInput,
                {
                  className: "!w-20 !p-1 text-center",
                  size: "1",
                  type: "number",
                  value: productInventories[product.id],
                  onBlur: (e) => submitInventory(product.id, e.target.value),
                  onChange: (e) => updateInventory(product.id, e)
                }
              ) }),
              /* @__PURE__ */ jsx("td", { className: "px-6 py-4", children: product.group_products.length ? /* @__PURE__ */ jsx("span", { className: "inline-flex whitespace-nowrap items-center rounded-md bg-green-50 dark:bg-green-500/30 px-2 py-1 text-sm font-medium text-green-800 dark:text-green-300/70 ring-1 ring-inset ring-green-600/20", children: "گروهبندی شده" }) : /* @__PURE__ */ jsx("span", { className: "inline-flex whitespace-nowrap items-center rounded-md bg-red-50 dark:bg-red-500/30 px-2 py-1 text-sm font-medium text-red-800 dark:text-red-300/70 ring-1 ring-inset ring-red-600/20", children: "گروهبندی نشده" }) }),
              /* @__PURE__ */ jsxs("td", { className: "px-6 py-4 whitespace-nowrap", children: [
                /* @__PURE__ */ jsx(
                  Link,
                  {
                    href: route("products.edit", [product.id]),
                    className: "inline-flex px-2 py-1 text-xs text-center text-yellow-900 dark:text-yellow-200 transition-colors duration-300 bg-yellow-100 dark:bg-yellow-600/50 border border-yellow-200 dark:border-yellow-800 rounded-lg hover:bg-yellow-200 dark:hover:bg-yellow-600 focus:outline-none focus:ring-0 focus:border-yellow-500",
                    children: "ویرایش"
                  }
                ),
                /* @__PURE__ */ jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      setDeleteModalShow(true);
                      setModalProduct(product);
                    },
                    className: "inline-flex mr-2 px-2 py-1 text-xs text-center text-red-900 dark:text-red-200 transition-colors duration-300 bg-red-100 dark:bg-red-600/50 border border-red-200 dark:border-red-800 rounded-lg hover:bg-red-200 dark:hover:bg-red-600 focus:outline-none focus:ring-0 focus:border-red-500",
                    children: "حذف"
                  }
                )
              ] })
            ] }, product.id);
          }) : /* @__PURE__ */ jsx("tr", { className: "bg-white text-gray-700 dark:text-slate-300 dark:bg-slate-900", children: /* @__PURE__ */ jsxs(
            "th",
            {
              scope: "row",
              colSpan: "7",
              className: "text-lg px-6 py-6",
              children: [
                "هیچ محصولی یافت نشد!",
                /* @__PURE__ */ jsx(
                  Link,
                  {
                    href: route("products.create"),
                    className: "mr-2 text-sky-500 text-base",
                    children: "ایجاد اولین محصول"
                  }
                )
              ]
            }
          ) }) })
        ] }) }),
        /* @__PURE__ */ jsx(Pagination, { data: products, search }),
        /* @__PURE__ */ jsx(Modal, { show: deleteModalShow, onClose: closeModal, maxWidth: "sm", children: /* @__PURE__ */ jsxs("form", { onSubmit: deletePatient, className: "p-6", children: [
          /* @__PURE__ */ jsx("h2", { className: "text-lg font-semibold text-gray-700 dark:text-slate-200", children: "آیا از حذف محصول مطمئن هستید؟" }),
          /* @__PURE__ */ jsx("p", { className: "mt-5 text-gray-600 dark:text-slate-300", children: "با حذف محصول، سفارشاتی که با این محصول انجام شده باشند دچار مشکل خواهند شد!" }),
          /* @__PURE__ */ jsxs("div", { className: "mt-6 flex justify-between", children: [
            /* @__PURE__ */ jsx(SecondaryButton, { className: "!px-4 !py-2 text-xs", type: "button", onClick: closeModal, children: "لغو" }),
            /* @__PURE__ */ jsx(DangerButton, { className: "mr-3 !px-4 !py-2 text-xs", disabled: processing, children: "تایید حذف محصول" })
          ] })
        ] }) })
      ]
    }
  );
}
export {
  Index as default
};
