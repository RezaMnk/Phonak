import { j as jsxs, a as jsx, F as Fragment } from "../ssr.js";
import { Head } from "@inertiajs/react";
import { useState, useEffect } from "react";
import { m as manifest } from "./manifest-fc82f16f.js";
import JSZip from "jszip";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
function Record({ record }) {
  const [first, setFirst] = useState(true);
  useEffect(() => {
    let images = {
      [record.audiogram_image_url]: record.patient.name + "-" + record.user.name + "-audiogram.jpg",
      [record.id_card_image_url]: record.patient.name + "-" + record.user.name + "-id.jpg",
      [record.prescription_image_url]: record.patient.name + "-" + record.user.name + "-prescription.jpg",
      [record.national_code_confirm_image_url]: record.patient.name + "-" + record.user.name + "-national_cde.jpg"
    };
    const zip = new JSZip();
    async function handleZip() {
      for (let url in images) {
        const response = await fetch(url);
        const blob = await response.blob();
        zip.file(images[url], blob);
      }
      const modulePreloadTags = Array.from(document.querySelectorAll('link[rel="modulepreload"][href]'));
      const scriptTags = Array.from(document.querySelectorAll("script[src]"));
      modulePreloadTags.forEach((modulePreloadTag) => modulePreloadTag.remove());
      scriptTags.forEach((scriptTag) => scriptTag.remove());
      const cssFilename = manifest["resources/js/app.jsx"].css[0];
      const cssUrl = `${document.location.origin}/build/${cssFilename}`;
      fetch(cssUrl).then((response) => response.text()).then(async (cssData) => {
        document.getElementById("local-css").innerHTML = cssData;
        const modifiedHtml = document.documentElement.outerHTML;
        const blob = new Blob([modifiedHtml], { type: "text/html" });
        zip.file("سفارش سمعک شماره " + record.id + ".html", blob);
        const zipData = await zip.generateAsync({
          type: "blob",
          streamFiles: true
        });
        const link = document.createElement("a");
        link.href = window.URL.createObjectURL(zipData);
        link.download = "سفارش سمعک شماره " + record.id + ".zip";
        link.click();
        window.close();
      }).catch((error) => {
        console.error("Error fetching CSS:", error);
      });
    }
    if (first)
      handleZip();
    return setFirst(false);
  }, []);
  const vent_sizes = {
    "2-3 mm": "2-3 mm",
    "1.5 mm": "1.5 mm",
    "1 mm": "1 mm",
    "groove": "شیاری",
    "none": "هیچکدام"
  };
  const dome_sizes = {
    "large": "بزرگ",
    "medium": "متوسط",
    "small": "کوچک"
  };
  const tests_list = [
    "250",
    "500",
    "1000",
    "2000",
    "4000"
  ];
  const shipping_types = {
    "terminal": "ترمینالی",
    "air": "هوایی",
    "tipax": "تیپاکس",
    "post": "پست",
    "co-worker delivery": "تحویل به پیک همکار",
    "company delivery": "ارسال با پیک شرکت",
    "etc": "سایر"
  };
  const render_aid_info = (ear) => /* @__PURE__ */ jsxs(Fragment, { children: [
    (record.type === "CIC" || record.type === "ITC") && /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-5 xl:mt-8", children: [
      /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
        /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
          /* @__PURE__ */ jsx("span", { className: `inline-block min-h-[10px] ml-2 w-[2px] h-full ${ear === "left" ? "bg-sky-400 dark:bg-sky-600" : "bg-red-400 dark:bg-red-600"}` }),
          "اندازه سمعک"
        ] }),
        /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.record_aid[ear].hearing_aid_size })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
        /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
          /* @__PURE__ */ jsx("span", { className: `inline-block min-h-[10px] ml-2 w-[2px] h-full ${ear === "left" ? "bg-sky-400 dark:bg-sky-600" : "bg-red-400 dark:bg-red-600"}` }),
          "اندازه ونت"
        ] }),
        /* @__PURE__ */ jsx("p", { className: "mt-2", children: vent_sizes[record.record_aid[ear].vent_size] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3", children: [
        /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
          /* @__PURE__ */ jsx("span", { className: `inline-block min-h-[10px] ml-2 w-[2px] h-full ${ear === "left" ? "bg-sky-400 dark:bg-sky-600" : "bg-red-400 dark:bg-red-600"}` }),
          "نوع رسیور"
        ] }),
        /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.record_aid[ear].receiver })
      ] })
    ] }) }),
    record.type === "BTE mold" && /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-5 xl:mt-8", children: [
      /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
        /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
          /* @__PURE__ */ jsx("span", { className: `inline-block min-h-[10px] ml-2 w-[2px] h-full ${ear === "left" ? "bg-sky-400 dark:bg-sky-600" : "bg-red-400 dark:bg-red-600"}` }),
          "قالب دارد؟"
        ] }),
        /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.record_aid[ear].has_mold ? "بله" : "خیر" })
      ] }),
      record.record_aid[ear].has_mold === 1 && /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: `inline-block min-h-[10px] ml-2 w-[2px] h-full ${ear === "left" ? "bg-sky-400 dark:bg-sky-600" : "bg-red-400 dark:bg-red-600"}` }),
            "جنس قالب"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.record_aid[ear].mold_material === "hard" ? "سخت" : "نرم" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: `w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ` + record.record_aid[ear].has_vent ? "ml-5" : "", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: `inline-block min-h-[10px] ml-2 w-[2px] h-full ${ear === "left" ? "bg-sky-400 dark:bg-sky-600" : "bg-red-400 dark:bg-red-600"}` }),
            "اندازه قالب"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.record_aid[ear].mold_size })
        ] })
      ] })
    ] }) }),
    record.type === "BTE tube" && /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-5 xl:mt-8", children: [
      /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
        /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
          /* @__PURE__ */ jsx("span", { className: `inline-block min-h-[10px] ml-2 w-[2px] h-full ${ear === "left" ? "bg-sky-400 dark:bg-sky-600" : "bg-red-400 dark:bg-red-600"}` }),
          "قالب دارد؟"
        ] }),
        /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.record_aid[ear].has_mold ? "بله" : "خیر" })
      ] }),
      record.record_aid[ear].has_mold ? /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: `inline-block min-h-[10px] ml-2 w-[2px] h-full ${ear === "left" ? "bg-sky-400 dark:bg-sky-600" : "bg-red-400 dark:bg-red-600"}` }),
            "ونت دارد؟"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.record_aid[ear].has_vent ? "بله" : "خیر" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: `w-full xl:w-1/3 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5`, children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: `inline-block min-h-[10px] ml-2 w-[2px] h-full ${ear === "left" ? "bg-sky-400 dark:bg-sky-600" : "bg-red-400 dark:bg-red-600"}` }),
            "اندازه اسلیم تیوب"
          ] }),
          /* @__PURE__ */ jsxs("p", { className: "mt-2", children: [
            "سایز ",
            record.record_aid[ear].tube_size
          ] })
        ] }),
        record.record_aid[ear].has_vent && /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: `inline-block min-h-[10px] ml-2 w-[2px] h-full ${ear === "left" ? "bg-sky-400 dark:bg-sky-600" : "bg-red-400 dark:bg-red-600"}` }),
            "اندازه ونت"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: vent_sizes[record.record_aid[ear].vent_size] })
        ] })
      ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: `inline-block min-h-[10px] ml-2 w-[2px] h-full ${ear === "left" ? "bg-sky-400 dark:bg-sky-600" : "bg-red-400 dark:bg-red-600"}` }),
            "اندازه اسلیم تیوب"
          ] }),
          /* @__PURE__ */ jsxs("p", { className: "mt-2", children: [
            "سایز ",
            record.record_aid[ear].tube_size
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: `inline-block min-h-[10px] ml-2 w-[2px] h-full ${ear === "left" ? "bg-sky-400 dark:bg-sky-600" : "bg-red-400 dark:bg-red-600"}` }),
            "نوع Dome"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.record_aid[ear].dome_type })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: `inline-block min-h-[10px] ml-2 w-[2px] h-full ${ear === "left" ? "bg-sky-400 dark:bg-sky-600" : "bg-red-400 dark:bg-red-600"}` }),
            "اندازه Dome"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: dome_sizes[record.record_aid[ear].dome_size] })
        ] })
      ] })
    ] }) }),
    record.type === "RIC" && /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-5 xl:mt-8", children: [
      /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
        /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
          /* @__PURE__ */ jsx("span", { className: `inline-block min-h-[10px] ml-2 w-[2px] h-full ${ear === "left" ? "bg-sky-400 dark:bg-sky-600" : "bg-red-400 dark:bg-red-600"}` }),
          "قالب دارد؟"
        ] }),
        /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.record_aid[ear].has_mold ? "بله" : "خیر" })
      ] }),
      record.record_aid[ear].has_mold ? /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: `inline-block min-h-[10px] ml-2 w-[2px] h-full ${ear === "left" ? "bg-sky-400 dark:bg-sky-600" : "bg-red-400 dark:bg-red-600"}` }),
            "نوع رسیور"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.record_aid[ear].receiver })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: `inline-block min-h-[10px] ml-2 w-[2px] h-full ${ear === "left" ? "bg-sky-400 dark:bg-sky-600" : "bg-red-400 dark:bg-red-600"}` }),
            "نوع پوسته"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.record_aid[ear].shell_type })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: `inline-block min-h-[10px] ml-2 w-[2px] h-full ${ear === "left" ? "bg-sky-400 dark:bg-sky-600" : "bg-red-400 dark:bg-red-600"}` }),
            "اندازه رسیور خارجی"
          ] }),
          /* @__PURE__ */ jsxs("p", { className: "mt-2", children: [
            "سایز ",
            record.record_aid[ear].external_receiver_size
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: `inline-block min-h-[10px] ml-2 w-[2px] h-full ${ear === "left" ? "bg-sky-400 dark:bg-sky-600" : "bg-red-400 dark:bg-red-600"}` }),
            "اندازه ونت"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: vent_sizes[record.record_aid[ear].vent_size] })
        ] })
      ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: `inline-block min-h-[10px] ml-2 w-[2px] h-full ${ear === "left" ? "bg-sky-400 dark:bg-sky-600" : "bg-red-400 dark:bg-red-600"}` }),
            "نوع رسیور"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.record_aid[ear].receiver })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: `inline-block min-h-[10px] ml-2 w-[2px] h-full ${ear === "left" ? "bg-sky-400 dark:bg-sky-600" : "bg-red-400 dark:bg-red-600"}` }),
            "اندازه رسیور خارجی"
          ] }),
          /* @__PURE__ */ jsxs("p", { className: "mt-2", children: [
            "سایز ",
            record.record_aid[ear].external_receiver_size
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: `inline-block min-h-[10px] ml-2 w-[2px] h-full ${ear === "left" ? "bg-sky-400 dark:bg-sky-600" : "bg-red-400 dark:bg-red-600"}` }),
            "نوع Dome"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.record_aid[ear].dome_type })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: `inline-block min-h-[10px] ml-2 w-[2px] h-full ${ear === "left" ? "bg-sky-400 dark:bg-sky-600" : "bg-red-400 dark:bg-red-600"}` }),
            "اندازه Dome"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: dome_sizes[record.record_aid[ear].dome_size] })
        ] })
      ] })
    ] }) }),
    record.record_aid[ear].description && /* @__PURE__ */ jsxs("div", { className: "w-full mt-5 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3", children: [
      /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
        /* @__PURE__ */ jsx("span", { className: `inline-block min-h-[10px] ml-2 w-[2px] h-full ${ear === "left" ? "bg-sky-400 dark:bg-sky-600" : "bg-red-400 dark:bg-red-600"}` }),
        "توضیحات"
      ] }),
      /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.record_aid[ear].description })
    ] })
  ] });
  return /* @__PURE__ */ jsxs("div", { className: "bg-gray-100 p-24 print:p-4", children: [
    /* @__PURE__ */ jsx(Head, { title: "نمایش سفارش" }),
    /* @__PURE__ */ jsx("style", { type: "text/css", id: "local-css" }),
    /* @__PURE__ */ jsx("div", { className: "flex flex-col sm:justify-center items-center", children: /* @__PURE__ */ jsx("div", { className: "w-full px-6 py-4 bg-white dark:bg-slate-800 border border-white dark:border-slate-600 sm:rounded-lg", id: "info", children: /* @__PURE__ */ jsxs("div", { className: "w-full text-gray-700 dark:text-slate-200", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex gap-2 items-center text-lg font-semibold mb-5", children: [
        /* @__PURE__ */ jsxs("p", { children: [
          "سفارش سمعک شماره ",
          /* @__PURE__ */ jsx("span", { children: record.id })
        ] }),
        record.status === "completed" && /* @__PURE__ */ jsx("span", { children: "(پرداخت نشده)" }),
        record.status === "paid" && /* @__PURE__ */ jsx("span", { children: "(پرداخت شده)" }),
        record.status === "approved" && /* @__PURE__ */ jsx("span", { children: "(تایید شده)" })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("h5", { children: "اطلاعات کاربر" }),
        /* @__PURE__ */ jsx("hr", { className: "dark:border-slate-600" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-6", children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/5 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
            "نام و نام خانوادگی"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.patient.name })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/5 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
            "نام و نام خانوادگی به لاتین"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.patient.eng_name })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/5 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
            "کد ملی"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.patient.national_code })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/5 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
            "سال تولد"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.patient.birth_year })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/5 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
            "موقعیت"
          ] }),
          /* @__PURE__ */ jsxs("p", { className: "mt-2", children: [
            record.patient.state,
            " - ",
            record.patient.city
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-5 xl:mt-8", children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full print:w-1/5 xl:w-1/5 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 print:px-2 print:py-1 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: "inline-block print:hidden min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
            "نوع بیمه"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.patient.insurance })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/5 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
            "تلفن همراه"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.patient.phone })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/5 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
            "کد پستی"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.patient.post_code })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-2/5 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
            "آدرس"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.patient.address })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mt-12", children: [
        /* @__PURE__ */ jsx("h5", { children: "محصول مورد سفارش" }),
        /* @__PURE__ */ jsx("hr", { className: "dark:border-slate-600" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-5 xl:mt-8", children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
            "برند"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.brand })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
            "نوع"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.type })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
            "نام محصول"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.product.name })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 print:px-2 print:py-1", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: "inline-block print:hidden min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
            "کد IRC"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.product.irc })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col print:flex-row xl:flex-row space-y-5 items-center print:space-y-0 xl:space-y-0 mt-5 xl:mt-8", children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/5 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 print:px-2 print:py-1 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: "inline-block print:hidden min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
            "تعداد مورد سفارش"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.ear === "both" ? "دو عدد" : "یک عدد" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/5 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 print:px-2 print:py-1 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: "inline-block print:hidden min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
            "سفارش پکیج دارد؟"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.has_package ? "بله" : "خیر" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/5 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 print:px-2 print:py-1 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: "inline-block print:hidden min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
            "سفارش قالب دارد؟"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.has_mold ? "بله" : "خیر" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/5 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 print:px-2 print:py-1 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: "inline-block print:hidden min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
            "سفارش شارژر دارد؟"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.has_charger ? "بله" : "خیر" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/5 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 print:px-2 print:py-1", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: "inline-block print:hidden min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
            "جمع فاکتور سفارش"
          ] }),
          /* @__PURE__ */ jsxs("p", { className: "mt-2", children: [
            record.total_price.toLocaleString("fa-IR"),
            " ریال"
          ] })
        ] })
      ] }),
      record.record_aid.left && /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsxs("div", { className: "mt-12", children: [
          /* @__PURE__ */ jsx("h5", { children: "مشخصات سمعک گوش چپ" }),
          /* @__PURE__ */ jsx("hr", { className: "dark:border-slate-600" })
        ] }),
        render_aid_info("left")
      ] }),
      record.record_aid.right && /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsxs("div", { className: "mt-12", children: [
          /* @__PURE__ */ jsx("h5", { children: "مشخصات سمعک گوش راست" }),
          /* @__PURE__ */ jsx("hr", { className: "dark:border-slate-600" })
        ] }),
        render_aid_info("right")
      ] }),
      record.record_aid.left && /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsxs("div", { className: "mt-12", children: [
          /* @__PURE__ */ jsx("h5", { children: "ادیوگرام گوش چپ" }),
          /* @__PURE__ */ jsx("hr", { className: "dark:border-slate-600" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col-reverse xl:flex-row space-y-5 space-y-reverse xl:space-y-0 xl:space-x-reverse xl:space-x-10 mt-5 xl:mt-8", children: [
          [...tests_list].reverse().map((item, index) => /* @__PURE__ */ jsxs("div", { className: "w-full flex text-gray-800 dark:text-slate-200", children: [
            /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-col", children: [
              /* @__PURE__ */ jsxs("span", { className: "block text-sm cursor-pointer font-semibold bg-sky-200 dark:bg-sky-700 rounded-lg py-1 text-center", children: [
                item,
                "Hz"
              ] }),
              /* @__PURE__ */ jsx("div", { className: "mt-2 block text-sm cursor-pointer font-semibold bg-gray-100 dark:bg-slate-700 rounded-lg py-3 text-center", children: record.audiogram.left["ac_" + item] }),
              /* @__PURE__ */ jsx("div", { className: "mt-2 block text-sm cursor-pointer font-semibold bg-gray-100 dark:bg-slate-700 rounded-lg py-3 text-center", children: record.audiogram.left["bc_" + item] ? record.audiogram.left["bc_" + item] : "ثبت نشده" })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "flex xl:hidden", children: /* @__PURE__ */ jsxs("div", { className: "w-full mr-5 text-gray-800 dark:text-slate-200", children: [
              /* @__PURE__ */ jsx("div", { className: "text-center text-xs font-semibold bg-gray-200 dark:bg-slate-900 rounded-lg py-1 px-2", children: "Frequency" }),
              /* @__PURE__ */ jsx("div", { className: "text-center font-semibold bg-gray-200 dark:bg-slate-900 rounded-lg py-[.65rem] px-2 mt-2", children: "AC" }),
              /* @__PURE__ */ jsx("div", { className: "text-center font-semibold bg-gray-200 dark:bg-slate-900 rounded-lg py-[.65rem] px-2 mt-2", children: "BC" })
            ] }) })
          ] }, index)),
          /* @__PURE__ */ jsxs("div", { className: "hidden xl:block w-1/12 text-gray-800 dark:text-slate-200", children: [
            /* @__PURE__ */ jsx("div", { className: "text-center text-xs font-semibold bg-gray-200 dark:bg-slate-900 rounded-lg py-1 px-2", children: "Frequency" }),
            /* @__PURE__ */ jsx("div", { className: "text-center font-semibold bg-gray-200 dark:bg-slate-900 rounded-lg py-[.65rem] px-2 mt-2", children: "AC" }),
            /* @__PURE__ */ jsx("div", { className: "text-center font-semibold bg-gray-200 dark:bg-slate-900 rounded-lg py-[.65rem] px-2 mt-2", children: "BC" })
          ] })
        ] })
      ] }),
      record.record_aid.right && /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsxs("div", { className: "mt-12", children: [
          /* @__PURE__ */ jsx("h5", { children: "ادیوگرام گوش راست" }),
          /* @__PURE__ */ jsx("hr", { className: "dark:border-slate-600" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col-reverse xl:flex-row space-y-5 space-y-reverse xl:space-y-0 xl:space-x-reverse xl:space-x-10 mt-5 xl:mt-8", children: [
          [...tests_list].reverse().map((item, index) => /* @__PURE__ */ jsxs("div", { className: "w-full flex text-gray-800 dark:text-slate-200", children: [
            /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-col", children: [
              /* @__PURE__ */ jsxs("span", { className: "block text-sm cursor-pointer font-semibold bg-red-200 dark:bg-red-700 rounded-lg py-1 text-center", children: [
                item,
                "Hz"
              ] }),
              /* @__PURE__ */ jsx("div", { className: "mt-2 block text-sm cursor-pointer font-semibold bg-gray-100 dark:bg-slate-700 rounded-lg py-3 text-center", children: record.audiogram.right["ac_" + item] }),
              /* @__PURE__ */ jsx("div", { className: "mt-2 block text-sm cursor-pointer font-semibold bg-gray-100 dark:bg-slate-700 rounded-lg py-3 text-center", children: record.audiogram.right["bc_" + item] ? record.audiogram.right["bc_" + item] : "ثبت نشده" })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "flex xl:hidden", children: /* @__PURE__ */ jsxs("div", { className: "w-full mr-5 text-gray-800 dark:text-slate-200", children: [
              /* @__PURE__ */ jsx("div", { className: "text-center text-xs font-semibold bg-gray-200 dark:bg-slate-900 rounded-lg py-1 px-2", children: "Frequency" }),
              /* @__PURE__ */ jsx("div", { className: "text-center font-semibold bg-gray-200 dark:bg-slate-900 rounded-lg py-[.65rem] px-2 mt-2", children: "AC" }),
              /* @__PURE__ */ jsx("div", { className: "text-center font-semibold bg-gray-200 dark:bg-slate-900 rounded-lg py-[.65rem] px-2 mt-2", children: "BC" })
            ] }) })
          ] }, index)),
          /* @__PURE__ */ jsxs("div", { className: "hidden xl:block w-1/12 text-gray-800 dark:text-slate-200", children: [
            /* @__PURE__ */ jsx("div", { className: "text-center text-xs font-semibold bg-gray-200 dark:bg-slate-900 rounded-lg py-1 px-2", children: "Frequency" }),
            /* @__PURE__ */ jsx("div", { className: "text-center font-semibold bg-gray-200 dark:bg-slate-900 rounded-lg py-[.65rem] px-2 mt-2", children: "AC" }),
            /* @__PURE__ */ jsx("div", { className: "text-center font-semibold bg-gray-200 dark:bg-slate-900 rounded-lg py-[.65rem] px-2 mt-2", children: "BC" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mt-12", children: [
        /* @__PURE__ */ jsx("h5", { children: "نحوه ارسال" }),
        /* @__PURE__ */ jsx("hr", { className: "dark:border-slate-600" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-6", children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
            "تلفن همراه شنوایی شناس جهت ارسال صورتحساب"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.shipping.expert_phone })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
            "شیوه ارسال"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: shipping_types[record.shipping.type] })
        ] }),
        record.shipping.type === "etc" && /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-2/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
            "توضیحات شیوه ارسال"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.shipping.etc_delivery })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-6", children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
            /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
            "بیمه سلامت دارد؟"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.shipping.has_health_insurance ? "بله" : "خیر" })
        ] }),
        record.shipping.has_health_insurance === 1 && /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
            /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
              /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
              "تلفن همراه کاربر"
            ] }),
            /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.shipping.phone })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
            /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
              /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
              "شماره نظام پزشکی شنوایی شناس"
            ] }),
            /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.shipping.audiologist_med_number })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
            /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
              /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
              "شماره نظام پزشکی پزشک گوش و حلق و بینی"
            ] }),
            /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.shipping.otolaryngologist_med_number })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3 ml-5", children: [
            /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
              /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-slate-400 dark:bg-slate-600" }),
              "نوع بیمه تکمیلی"
            ] }),
            /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.shipping.supplementary_insurance })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "flex mt-6", children: /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3", children: [
        /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
          /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-sky-400 dark:bg-sky-600" }),
          "آدرس ارسال محصول"
        ] }),
        /* @__PURE__ */ jsxs("p", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-5 xl:mt-2", children: [
          /* @__PURE__ */ jsx("span", { className: "inline-block", children: record.shipping.address.address }),
          /* @__PURE__ */ jsxs("span", { className: "inline-block xl:mr-5 xl:pr-5 xl:border-r border-gray-300 dark:border-slate-600", children: [
            "کدپستی: ",
            record.shipping.address.post_code
          ] }),
          record.shipping.address.phone && /* @__PURE__ */ jsxs(
            "span",
            {
              className: "inline-block xl:mr-5 xl:pr-5 xl:border-r border-gray-300 dark:border-slate-600",
              children: [
                "تلفن: ",
                record.shipping.address.phone
              ]
            }
          )
        ] })
      ] }) }),
      record.shipping.description && /* @__PURE__ */ jsx("div", { className: "flex mt-6", children: /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-col bg-gray-50 dark:bg-slate-700/30 rounded-lg p-3", children: [
        /* @__PURE__ */ jsxs("p", { className: "text-xs flex items-center", children: [
          /* @__PURE__ */ jsx("span", { className: "inline-block min-h-[10px] ml-2 w-[2px] h-full bg-sky-400 dark:bg-sky-600" }),
          "توضیحات"
        ] }),
        /* @__PURE__ */ jsx("p", { className: "mt-2", children: record.shipping.description })
      ] }) })
    ] }) }) })
  ] });
}
export {
  Record as default
};
