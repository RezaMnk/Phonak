const manifest = {
  "AuthenticatedLayout.css": {
    file: "assets/AuthenticatedLayout-b7bb1ac5.css",
    src: "AuthenticatedLayout.css"
  },
  "_AidInputs-0fedbed5.js": {
    file: "assets/AidInputs-0fedbed5.js",
    imports: [
      "resources/js/app.jsx",
      "_SelectInput-3bee1cbc.js",
      "_InputError-f1ac2675.js",
      "_PrimaryButton-dd419429.js",
      "_DangerButton-1ec709bb.js",
      "_AuthenticatedLayout-bb10bb71.js",
      "resources/js/Pages/Records/Components/Steps.jsx",
      "_TextInput-2369dc55.js",
      "_TextAreaInput-cbd42b6c.js",
      "_IranStatesOptions-cc8da08a.js",
      "_FileInput-ee3447d2.js",
      "_RadioInput-1ca9cc2f.js",
      "_InputLabel-eb7294d6.js",
      "resources/js/Pages/Records/Components/ProductsSlider.jsx",
      "_useFirstRender-70362520.js",
      "_CheckboxInput-404eaa22.js",
      "_Icon-ce5d2d29.js"
    ],
    isDynamicEntry: true
  },
  "_ApplicationLogo-d276a950.js": {
    file: "assets/ApplicationLogo-d276a950.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_ArrowLink-94e6fb86.js": {
    file: "assets/ArrowLink-94e6fb86.js",
    imports: [
      "resources/js/app.jsx",
      "__commonjs-dynamic-modules-302442b1.js"
    ]
  },
  "_AuthenticatedLayout-bb10bb71.js": {
    css: [
      "assets/AuthenticatedLayout-b7bb1ac5.css"
    ],
    file: "assets/AuthenticatedLayout-bb10bb71.js",
    imports: [
      "resources/js/app.jsx",
      "_useMemorable-89bd680c.js",
      "_ApplicationLogo-d276a950.js",
      "_Icon-ce5d2d29.js"
    ]
  },
  "_CheckboxInput-404eaa22.js": {
    file: "assets/CheckboxInput-404eaa22.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_Create-3787b3cc.js": {
    file: "assets/Create-3787b3cc.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bb10bb71.js",
      "_TextInput-2369dc55.js",
      "_InputError-f1ac2675.js",
      "_TextAreaInput-cbd42b6c.js",
      "_PrimaryButton-dd419429.js",
      "_SelectInput-3bee1cbc.js",
      "_RadioInput-1ca9cc2f.js",
      "_InputLabel-eb7294d6.js",
      "resources/js/Pages/Accessories/Components/ProductsSlider.jsx",
      "_DangerButton-1ec709bb.js",
      "_Icon-ce5d2d29.js"
    ],
    isDynamicEntry: true
  },
  "_DangerButton-1ec709bb.js": {
    file: "assets/DangerButton-1ec709bb.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_FileInput-ee3447d2.js": {
    file: "assets/FileInput-ee3447d2.js",
    imports: [
      "resources/js/app.jsx",
      "_Icon-ce5d2d29.js",
      "_PrimaryButton-dd419429.js"
    ]
  },
  "_GuestLayout-5f3f962a.js": {
    file: "assets/GuestLayout-5f3f962a.js",
    imports: [
      "resources/js/app.jsx",
      "_ApplicationLogo-d276a950.js",
      "_useMemorable-89bd680c.js"
    ]
  },
  "_Icon-ce5d2d29.js": {
    file: "assets/Icon-ce5d2d29.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_InputError-f1ac2675.js": {
    file: "assets/InputError-f1ac2675.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_InputLabel-eb7294d6.js": {
    file: "assets/InputLabel-eb7294d6.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_IranStatesOptions-cc8da08a.js": {
    file: "assets/IranStatesOptions-cc8da08a.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_Modal-14e61c67.js": {
    file: "assets/Modal-14e61c67.js",
    imports: [
      "resources/js/app.jsx",
      "_transition-d6ab3856.js"
    ]
  },
  "_Pagination-2759b472.js": {
    file: "assets/Pagination-2759b472.js",
    imports: [
      "resources/js/app.jsx",
      "_useFirstRender-70362520.js"
    ]
  },
  "_PrimaryButton-dd419429.js": {
    file: "assets/PrimaryButton-dd419429.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_RadioInput-1ca9cc2f.js": {
    file: "assets/RadioInput-1ca9cc2f.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_SecondaryButton-51f6a1e1.js": {
    file: "assets/SecondaryButton-51f6a1e1.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_SelectInput-3bee1cbc.js": {
    file: "assets/SelectInput-3bee1cbc.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_TextAreaInput-cbd42b6c.js": {
    file: "assets/TextAreaInput-cbd42b6c.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_TextInput-2369dc55.js": {
    file: "assets/TextInput-2369dc55.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_WarningButton-24b0c597.js": {
    file: "assets/WarningButton-24b0c597.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "__commonjs-dynamic-modules-302442b1.js": {
    file: "assets/_commonjs-dynamic-modules-302442b1.js"
  },
  "_index-794ed720.js": {
    file: "assets/index-794ed720.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_lottie-react.esm-f5edb6e8.js": {
    file: "assets/lottie-react.esm-f5edb6e8.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_manifest-7215c072.js": {
    file: "assets/manifest-7215c072.js"
  },
  "_pagination-019f6b53.js": {
    css: [
      "assets/pagination-211b41b8.css"
    ],
    file: "assets/pagination-019f6b53.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_transition-d6ab3856.js": {
    file: "assets/transition-d6ab3856.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_useFirstRender-70362520.js": {
    file: "assets/useFirstRender-70362520.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "_useMemorable-89bd680c.js": {
    file: "assets/useMemorable-89bd680c.js",
    imports: [
      "resources/js/app.jsx"
    ]
  },
  "pagination.css": {
    file: "assets/pagination-211b41b8.css",
    src: "pagination.css"
  },
  "resources/fonts/woff/Dana-Black.woff": {
    file: "assets/Dana-Black-575de1e5.woff",
    src: "resources/fonts/woff/Dana-Black.woff"
  },
  "resources/fonts/woff/Dana-DemiBold.woff": {
    file: "assets/Dana-DemiBold-fa427dcf.woff",
    src: "resources/fonts/woff/Dana-DemiBold.woff"
  },
  "resources/fonts/woff/Dana-ExtraBlack.woff": {
    file: "assets/Dana-ExtraBlack-6c729c23.woff",
    src: "resources/fonts/woff/Dana-ExtraBlack.woff"
  },
  "resources/fonts/woff/Dana-ExtraBold.woff": {
    file: "assets/Dana-ExtraBold-0d7888d7.woff",
    src: "resources/fonts/woff/Dana-ExtraBold.woff"
  },
  "resources/fonts/woff/Dana-Fat.woff": {
    file: "assets/Dana-Fat-8831a7f0.woff",
    src: "resources/fonts/woff/Dana-Fat.woff"
  },
  "resources/fonts/woff/Dana-Hairline.woff": {
    file: "assets/Dana-Hairline-6d7bb084.woff",
    src: "resources/fonts/woff/Dana-Hairline.woff"
  },
  "resources/fonts/woff/Dana-Heavy.woff": {
    file: "assets/Dana-Heavy-e159608a.woff",
    src: "resources/fonts/woff/Dana-Heavy.woff"
  },
  "resources/fonts/woff/Dana-Light.woff": {
    file: "assets/Dana-Light-eeed4155.woff",
    src: "resources/fonts/woff/Dana-Light.woff"
  },
  "resources/fonts/woff/Dana-Medium.woff": {
    file: "assets/Dana-Medium-d0241b30.woff",
    src: "resources/fonts/woff/Dana-Medium.woff"
  },
  "resources/fonts/woff/Dana-Regular.woff": {
    file: "assets/Dana-Regular-eee25c04.woff",
    src: "resources/fonts/woff/Dana-Regular.woff"
  },
  "resources/fonts/woff/Dana-Thin.woff": {
    file: "assets/Dana-Thin-56dc1e1f.woff",
    src: "resources/fonts/woff/Dana-Thin.woff"
  },
  "resources/fonts/woff/Dana-UltraLight.woff": {
    file: "assets/Dana-UltraLight-a025f30e.woff",
    src: "resources/fonts/woff/Dana-UltraLight.woff"
  },
  "resources/fonts/woff2/Dana-Black.woff2": {
    file: "assets/Dana-Black-cdfe2203.woff2",
    src: "resources/fonts/woff2/Dana-Black.woff2"
  },
  "resources/fonts/woff2/Dana-DemiBold.woff2": {
    file: "assets/Dana-DemiBold-34870445.woff2",
    src: "resources/fonts/woff2/Dana-DemiBold.woff2"
  },
  "resources/fonts/woff2/Dana-ExtraBlack.woff2": {
    file: "assets/Dana-ExtraBlack-3208afe0.woff2",
    src: "resources/fonts/woff2/Dana-ExtraBlack.woff2"
  },
  "resources/fonts/woff2/Dana-ExtraBold.woff2": {
    file: "assets/Dana-ExtraBold-08dea612.woff2",
    src: "resources/fonts/woff2/Dana-ExtraBold.woff2"
  },
  "resources/fonts/woff2/Dana-Fat.woff2": {
    file: "assets/Dana-Fat-1f7b7061.woff2",
    src: "resources/fonts/woff2/Dana-Fat.woff2"
  },
  "resources/fonts/woff2/Dana-Hairline.woff2": {
    file: "assets/Dana-Hairline-7712cf11.woff2",
    src: "resources/fonts/woff2/Dana-Hairline.woff2"
  },
  "resources/fonts/woff2/Dana-Heavy.woff2": {
    file: "assets/Dana-Heavy-091eb261.woff2",
    src: "resources/fonts/woff2/Dana-Heavy.woff2"
  },
  "resources/fonts/woff2/Dana-Light.woff2": {
    file: "assets/Dana-Light-e07a4868.woff2",
    src: "resources/fonts/woff2/Dana-Light.woff2"
  },
  "resources/fonts/woff2/Dana-Medium.woff2": {
    file: "assets/Dana-Medium-d623f857.woff2",
    src: "resources/fonts/woff2/Dana-Medium.woff2"
  },
  "resources/fonts/woff2/Dana-Regular.woff2": {
    file: "assets/Dana-Regular-43506011.woff2",
    src: "resources/fonts/woff2/Dana-Regular.woff2"
  },
  "resources/fonts/woff2/Dana-Thin.woff2": {
    file: "assets/Dana-Thin-bec2bd8a.woff2",
    src: "resources/fonts/woff2/Dana-Thin.woff2"
  },
  "resources/fonts/woff2/Dana-UltraLight.woff2": {
    file: "assets/Dana-UltraLight-24615a03.woff2",
    src: "resources/fonts/woff2/Dana-UltraLight.woff2"
  },
  "resources/js/Pages/Accessories/Components/ProductsSlider.jsx": {
    file: "assets/ProductsSlider-ad343560.js",
    imports: [
      "resources/js/app.jsx",
      "_pagination-019f6b53.js",
      "_RadioInput-1ca9cc2f.js",
      "_InputLabel-eb7294d6.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Accessories/Components/ProductsSlider.jsx"
  },
  "resources/js/Pages/Accessories/Index.jsx": {
    file: "assets/Index-7e262608.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bb10bb71.js",
      "_SecondaryButton-51f6a1e1.js",
      "_DangerButton-1ec709bb.js",
      "_Modal-14e61c67.js",
      "_PrimaryButton-dd419429.js",
      "_Pagination-2759b472.js",
      "_useMemorable-89bd680c.js",
      "_ApplicationLogo-d276a950.js",
      "_Icon-ce5d2d29.js",
      "_transition-d6ab3856.js",
      "_useFirstRender-70362520.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Accessories/Index.jsx"
  },
  "resources/js/Pages/Accessories/Show.jsx": {
    file: "assets/Show-eb61465a.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bb10bb71.js",
      "_WarningButton-24b0c597.js",
      "_PrimaryButton-dd419429.js",
      "_SecondaryButton-51f6a1e1.js",
      "_useMemorable-89bd680c.js",
      "_ApplicationLogo-d276a950.js",
      "_Icon-ce5d2d29.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Accessories/Show.jsx"
  },
  "resources/js/Pages/Admin/Accessories.jsx": {
    file: "assets/Accessories-b79f7da4.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bb10bb71.js",
      "_Pagination-2759b472.js",
      "_useFirstRender-70362520.js",
      "_TextInput-2369dc55.js",
      "_useMemorable-89bd680c.js",
      "_ApplicationLogo-d276a950.js",
      "_Icon-ce5d2d29.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Admin/Accessories.jsx"
  },
  "resources/js/Pages/Admin/Records.jsx": {
    file: "assets/Records-67ead4c6.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bb10bb71.js",
      "_Pagination-2759b472.js",
      "_TextInput-2369dc55.js",
      "_useFirstRender-70362520.js",
      "_useMemorable-89bd680c.js",
      "_ApplicationLogo-d276a950.js",
      "_Icon-ce5d2d29.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Admin/Records.jsx"
  },
  "resources/js/Pages/Auth/Address.jsx": {
    file: "assets/Address-32bd6cbb.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-5f3f962a.js",
      "_InputError-f1ac2675.js",
      "_PrimaryButton-dd419429.js",
      "_TextInput-2369dc55.js",
      "_TextAreaInput-cbd42b6c.js",
      "_RadioInput-1ca9cc2f.js",
      "_InputLabel-eb7294d6.js",
      "_Icon-ce5d2d29.js",
      "_DangerButton-1ec709bb.js",
      "_SelectInput-3bee1cbc.js",
      "_IranStatesOptions-cc8da08a.js",
      "_ApplicationLogo-d276a950.js",
      "_useMemorable-89bd680c.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Address.jsx"
  },
  "resources/js/Pages/Auth/ConfirmPassword.jsx": {
    file: "assets/ConfirmPassword-598f99f4.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-5f3f962a.js",
      "_InputError-f1ac2675.js",
      "_InputLabel-eb7294d6.js",
      "_PrimaryButton-dd419429.js",
      "_TextInput-2369dc55.js",
      "_ApplicationLogo-d276a950.js",
      "_useMemorable-89bd680c.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/ConfirmPassword.jsx"
  },
  "resources/js/Pages/Auth/ForgotPassword.jsx": {
    file: "assets/ForgotPassword-a2e53049.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-5f3f962a.js",
      "_InputError-f1ac2675.js",
      "_PrimaryButton-dd419429.js",
      "_TextInput-2369dc55.js",
      "_ApplicationLogo-d276a950.js",
      "_useMemorable-89bd680c.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/ForgotPassword.jsx"
  },
  "resources/js/Pages/Auth/Info.jsx": {
    file: "assets/Info-42cae6e9.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-5f3f962a.js",
      "_InputError-f1ac2675.js",
      "_PrimaryButton-dd419429.js",
      "_TextInput-2369dc55.js",
      "_TextAreaInput-cbd42b6c.js",
      "_FileInput-ee3447d2.js",
      "_InputLabel-eb7294d6.js",
      "_ApplicationLogo-d276a950.js",
      "_useMemorable-89bd680c.js",
      "_Icon-ce5d2d29.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Info.jsx"
  },
  "resources/js/Pages/Auth/Login.jsx": {
    file: "assets/Login-abc1403c.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-5f3f962a.js",
      "_InputError-f1ac2675.js",
      "_InputLabel-eb7294d6.js",
      "_PrimaryButton-dd419429.js",
      "_TextInput-2369dc55.js",
      "_CheckboxInput-404eaa22.js",
      "_WarningButton-24b0c597.js",
      "_Icon-ce5d2d29.js",
      "_ApplicationLogo-d276a950.js",
      "_useMemorable-89bd680c.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Login.jsx"
  },
  "resources/js/Pages/Auth/Register.jsx": {
    file: "assets/Register-15e03683.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-5f3f962a.js",
      "_InputError-f1ac2675.js",
      "_PrimaryButton-dd419429.js",
      "_TextInput-2369dc55.js",
      "_SelectInput-3bee1cbc.js",
      "_IranStatesOptions-cc8da08a.js",
      "_ApplicationLogo-d276a950.js",
      "_useMemorable-89bd680c.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/Register.jsx"
  },
  "resources/js/Pages/Auth/ResetPassword.jsx": {
    file: "assets/ResetPassword-956caa00.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-5f3f962a.js",
      "_InputError-f1ac2675.js",
      "_PrimaryButton-dd419429.js",
      "_TextInput-2369dc55.js",
      "_ApplicationLogo-d276a950.js",
      "_useMemorable-89bd680c.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/ResetPassword.jsx"
  },
  "resources/js/Pages/Auth/VerifyEmail.jsx": {
    file: "assets/VerifyEmail-a6ff88c0.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-5f3f962a.js",
      "_PrimaryButton-dd419429.js",
      "_ApplicationLogo-d276a950.js",
      "_useMemorable-89bd680c.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/VerifyEmail.jsx"
  },
  "resources/js/Pages/Auth/WaitForVerify.jsx": {
    file: "assets/WaitForVerify-20c22a90.js",
    imports: [
      "resources/js/app.jsx",
      "_GuestLayout-5f3f962a.js",
      "_lottie-react.esm-f5edb6e8.js",
      "_PrimaryButton-dd419429.js",
      "_DangerButton-1ec709bb.js",
      "_ApplicationLogo-d276a950.js",
      "_useMemorable-89bd680c.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Auth/WaitForVerify.jsx"
  },
  "resources/js/Pages/Dashboards/Admin.jsx": {
    file: "assets/Admin-bb543cb3.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bb10bb71.js",
      "_ArrowLink-94e6fb86.js",
      "_useMemorable-89bd680c.js",
      "_ApplicationLogo-d276a950.js",
      "_Icon-ce5d2d29.js",
      "__commonjs-dynamic-modules-302442b1.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Dashboards/Admin.jsx"
  },
  "resources/js/Pages/Dashboards/User.jsx": {
    file: "assets/User-3ba7defe.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bb10bb71.js",
      "_ArrowLink-94e6fb86.js",
      "_useMemorable-89bd680c.js",
      "_ApplicationLogo-d276a950.js",
      "_Icon-ce5d2d29.js",
      "__commonjs-dynamic-modules-302442b1.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Dashboards/User.jsx"
  },
  "resources/js/Pages/Download/Accessory.jsx": {
    file: "assets/Accessory-ed9cbe22.js",
    imports: [
      "resources/js/app.jsx",
      "_manifest-7215c072.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Download/Accessory.jsx"
  },
  "resources/js/Pages/Download/Record.jsx": {
    file: "assets/Record-791afe4b.js",
    imports: [
      "resources/js/app.jsx",
      "_manifest-7215c072.js",
      "__commonjs-dynamic-modules-302442b1.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Download/Record.jsx"
  },
  "resources/js/Pages/Patients/Create.jsx": {
    file: "assets/Create-58bbdff1.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bb10bb71.js",
      "_TextInput-2369dc55.js",
      "_InputError-f1ac2675.js",
      "_TextAreaInput-cbd42b6c.js",
      "_PrimaryButton-dd419429.js",
      "_SelectInput-3bee1cbc.js",
      "_IranStatesOptions-cc8da08a.js",
      "_DangerButton-1ec709bb.js",
      "_useMemorable-89bd680c.js",
      "_ApplicationLogo-d276a950.js",
      "_Icon-ce5d2d29.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Create.jsx"
  },
  "resources/js/Pages/Patients/Edit.jsx": {
    file: "assets/Edit-516c7eb8.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bb10bb71.js",
      "_TextInput-2369dc55.js",
      "_InputError-f1ac2675.js",
      "_TextAreaInput-cbd42b6c.js",
      "_PrimaryButton-dd419429.js",
      "_SelectInput-3bee1cbc.js",
      "_IranStatesOptions-cc8da08a.js",
      "_DangerButton-1ec709bb.js",
      "_useMemorable-89bd680c.js",
      "_ApplicationLogo-d276a950.js",
      "_Icon-ce5d2d29.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Edit.jsx"
  },
  "resources/js/Pages/Patients/Index.jsx": {
    file: "assets/Index-10798a3d.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bb10bb71.js",
      "_SecondaryButton-51f6a1e1.js",
      "_DangerButton-1ec709bb.js",
      "_Modal-14e61c67.js",
      "_Pagination-2759b472.js",
      "_useMemorable-89bd680c.js",
      "_ApplicationLogo-d276a950.js",
      "_Icon-ce5d2d29.js",
      "_transition-d6ab3856.js",
      "_useFirstRender-70362520.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Index.jsx"
  },
  "resources/js/Pages/Patients/Partials/DeleteUserForm.jsx": {
    file: "assets/DeleteUserForm-e9245c12.js",
    imports: [
      "resources/js/app.jsx",
      "_DangerButton-1ec709bb.js",
      "_InputError-f1ac2675.js",
      "_InputLabel-eb7294d6.js",
      "_Modal-14e61c67.js",
      "_SecondaryButton-51f6a1e1.js",
      "_TextInput-2369dc55.js",
      "_transition-d6ab3856.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Partials/DeleteUserForm.jsx"
  },
  "resources/js/Pages/Patients/Partials/UpdatePasswordForm.jsx": {
    file: "assets/UpdatePasswordForm-c0ab064e.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-f1ac2675.js",
      "_InputLabel-eb7294d6.js",
      "_PrimaryButton-dd419429.js",
      "_TextInput-2369dc55.js",
      "_transition-d6ab3856.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Partials/UpdatePasswordForm.jsx"
  },
  "resources/js/Pages/Patients/Partials/UpdateProfileInformationForm.jsx": {
    file: "assets/UpdateProfileInformationForm-4e532e9b.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-f1ac2675.js",
      "_InputLabel-eb7294d6.js",
      "_PrimaryButton-dd419429.js",
      "_TextInput-2369dc55.js",
      "_transition-d6ab3856.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Patients/Partials/UpdateProfileInformationForm.jsx"
  },
  "resources/js/Pages/Products/CreateOrEdit.jsx": {
    file: "assets/CreateOrEdit-4aa3a811.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bb10bb71.js",
      "_TextInput-2369dc55.js",
      "_InputError-f1ac2675.js",
      "_PrimaryButton-dd419429.js",
      "_SelectInput-3bee1cbc.js",
      "_DangerButton-1ec709bb.js",
      "_Icon-ce5d2d29.js",
      "_CheckboxInput-404eaa22.js",
      "_InputLabel-eb7294d6.js",
      "_useMemorable-89bd680c.js",
      "_ApplicationLogo-d276a950.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Products/CreateOrEdit.jsx"
  },
  "resources/js/Pages/Products/Index.jsx": {
    file: "assets/Index-cfcecbc7.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bb10bb71.js",
      "_SecondaryButton-51f6a1e1.js",
      "_DangerButton-1ec709bb.js",
      "_Modal-14e61c67.js",
      "_PrimaryButton-dd419429.js",
      "_Pagination-2759b472.js",
      "_TextInput-2369dc55.js",
      "_useFirstRender-70362520.js",
      "_useMemorable-89bd680c.js",
      "_ApplicationLogo-d276a950.js",
      "_Icon-ce5d2d29.js",
      "_transition-d6ab3856.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Products/Index.jsx"
  },
  "resources/js/Pages/Profile/Edit.jsx": {
    file: "assets/Edit-796039ca.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bb10bb71.js",
      "_GuestLayout-5f3f962a.js",
      "_TextInput-2369dc55.js",
      "_InputError-f1ac2675.js",
      "_TextAreaInput-cbd42b6c.js",
      "_PrimaryButton-dd419429.js",
      "_DangerButton-1ec709bb.js",
      "_SelectInput-3bee1cbc.js",
      "_IranStatesOptions-cc8da08a.js",
      "_FileInput-ee3447d2.js",
      "_RadioInput-1ca9cc2f.js",
      "_InputLabel-eb7294d6.js",
      "_Icon-ce5d2d29.js",
      "_useMemorable-89bd680c.js",
      "_ApplicationLogo-d276a950.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Profile/Edit.jsx"
  },
  "resources/js/Pages/Profile/Index.jsx": {
    file: "assets/Index-e72d48f2.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bb10bb71.js",
      "_WarningButton-24b0c597.js",
      "_useMemorable-89bd680c.js",
      "_ApplicationLogo-d276a950.js",
      "_Icon-ce5d2d29.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Profile/Index.jsx"
  },
  "resources/js/Pages/Records/Components/ProductsSlider.jsx": {
    file: "assets/ProductsSlider-a6d774ca.js",
    imports: [
      "resources/js/app.jsx",
      "_pagination-019f6b53.js",
      "_RadioInput-1ca9cc2f.js",
      "_InputLabel-eb7294d6.js",
      "_CheckboxInput-404eaa22.js",
      "_Icon-ce5d2d29.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Components/ProductsSlider.jsx"
  },
  "resources/js/Pages/Records/Components/Steps.jsx": {
    file: "assets/Steps-c34509d3.js",
    imports: [
      "resources/js/app.jsx",
      "resources/js/Pages/Records/Partials/Step.jsx",
      "_Icon-ce5d2d29.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Components/Steps.jsx"
  },
  "resources/js/Pages/Records/Index.jsx": {
    file: "assets/Index-c2bffa02.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bb10bb71.js",
      "_SecondaryButton-51f6a1e1.js",
      "_DangerButton-1ec709bb.js",
      "_Modal-14e61c67.js",
      "_PrimaryButton-dd419429.js",
      "_Pagination-2759b472.js",
      "_useMemorable-89bd680c.js",
      "_ApplicationLogo-d276a950.js",
      "_Icon-ce5d2d29.js",
      "_transition-d6ab3856.js",
      "_useFirstRender-70362520.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Index.jsx"
  },
  "resources/js/Pages/Records/Partials/Step.jsx": {
    file: "assets/Step-65c24fd7.js",
    imports: [
      "resources/js/app.jsx"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Partials/Step.jsx"
  },
  "resources/js/Pages/Records/Show.jsx": {
    file: "assets/Show-34e06608.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bb10bb71.js",
      "_WarningButton-24b0c597.js",
      "_PrimaryButton-dd419429.js",
      "_SecondaryButton-51f6a1e1.js",
      "_useMemorable-89bd680c.js",
      "_ApplicationLogo-d276a950.js",
      "_Icon-ce5d2d29.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Records/Show.jsx"
  },
  "resources/js/Pages/Settings/CreateOrEdit.jsx": {
    file: "assets/CreateOrEdit-cbb26d2b.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bb10bb71.js",
      "_TextInput-2369dc55.js",
      "_InputError-f1ac2675.js",
      "_PrimaryButton-dd419429.js",
      "_DangerButton-1ec709bb.js",
      "_useMemorable-89bd680c.js",
      "_ApplicationLogo-d276a950.js",
      "_Icon-ce5d2d29.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/CreateOrEdit.jsx"
  },
  "resources/js/Pages/Settings/Index.jsx": {
    file: "assets/Index-4b7cdd09.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bb10bb71.js",
      "_SecondaryButton-51f6a1e1.js",
      "_DangerButton-1ec709bb.js",
      "_Modal-14e61c67.js",
      "_PrimaryButton-dd419429.js",
      "_Pagination-2759b472.js",
      "_TextInput-2369dc55.js",
      "_useFirstRender-70362520.js",
      "_useMemorable-89bd680c.js",
      "_ApplicationLogo-d276a950.js",
      "_Icon-ce5d2d29.js",
      "_transition-d6ab3856.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/Index.jsx"
  },
  "resources/js/Pages/Settings/OffLimits.jsx": {
    file: "assets/OffLimits-0a2371db.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bb10bb71.js",
      "_PrimaryButton-dd419429.js",
      "_lottie-react.esm-f5edb6e8.js",
      "_useMemorable-89bd680c.js",
      "_ApplicationLogo-d276a950.js",
      "_Icon-ce5d2d29.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/OffLimits.jsx"
  },
  "resources/js/Pages/Settings/OutOfSchedule.jsx": {
    file: "assets/OutOfSchedule-556d4696.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bb10bb71.js",
      "_PrimaryButton-dd419429.js",
      "_lottie-react.esm-f5edb6e8.js",
      "_useMemorable-89bd680c.js",
      "_ApplicationLogo-d276a950.js",
      "_Icon-ce5d2d29.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Settings/OutOfSchedule.jsx"
  },
  "resources/js/Pages/Terms.jsx": {
    file: "assets/Terms-719a165d.js",
    imports: [
      "resources/js/app.jsx",
      "_ApplicationLogo-d276a950.js",
      "_Icon-ce5d2d29.js",
      "_PrimaryButton-dd419429.js",
      "_index-794ed720.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Terms.jsx"
  },
  "resources/js/Pages/Users/Create.jsx": {
    file: "assets/Create-e59eeea1.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bb10bb71.js",
      "_TextInput-2369dc55.js",
      "_InputError-f1ac2675.js",
      "_TextAreaInput-cbd42b6c.js",
      "_PrimaryButton-dd419429.js",
      "_SelectInput-3bee1cbc.js",
      "_IranStatesOptions-cc8da08a.js",
      "_DangerButton-1ec709bb.js",
      "_useMemorable-89bd680c.js",
      "_ApplicationLogo-d276a950.js",
      "_Icon-ce5d2d29.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Create.jsx"
  },
  "resources/js/Pages/Users/Edit.jsx": {
    file: "assets/Edit-4e28c92a.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bb10bb71.js",
      "_TextAreaInput-cbd42b6c.js",
      "_TextInput-2369dc55.js",
      "_InputError-f1ac2675.js",
      "_PrimaryButton-dd419429.js",
      "_DangerButton-1ec709bb.js",
      "_SelectInput-3bee1cbc.js",
      "_WarningButton-24b0c597.js",
      "_Modal-14e61c67.js",
      "_CheckboxInput-404eaa22.js",
      "_InputLabel-eb7294d6.js",
      "_useMemorable-89bd680c.js",
      "_ApplicationLogo-d276a950.js",
      "_Icon-ce5d2d29.js",
      "_transition-d6ab3856.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Edit.jsx"
  },
  "resources/js/Pages/Users/Index.jsx": {
    file: "assets/Index-f4975cdd.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bb10bb71.js",
      "_Pagination-2759b472.js",
      "_TextInput-2369dc55.js",
      "_useFirstRender-70362520.js",
      "_SelectInput-3bee1cbc.js",
      "_useMemorable-89bd680c.js",
      "_ApplicationLogo-d276a950.js",
      "_Icon-ce5d2d29.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Index.jsx"
  },
  "resources/js/Pages/Users/NotCompleted.jsx": {
    file: "assets/NotCompleted-8c49402e.js",
    imports: [
      "resources/js/app.jsx",
      "_AuthenticatedLayout-bb10bb71.js",
      "_Pagination-2759b472.js",
      "_SecondaryButton-51f6a1e1.js",
      "_DangerButton-1ec709bb.js",
      "_Modal-14e61c67.js",
      "_TextInput-2369dc55.js",
      "_useFirstRender-70362520.js",
      "_useMemorable-89bd680c.js",
      "_ApplicationLogo-d276a950.js",
      "_Icon-ce5d2d29.js",
      "_transition-d6ab3856.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/NotCompleted.jsx"
  },
  "resources/js/Pages/Users/Partials/DeleteUserForm.jsx": {
    file: "assets/DeleteUserForm-285e9769.js",
    imports: [
      "resources/js/app.jsx",
      "_DangerButton-1ec709bb.js",
      "_InputError-f1ac2675.js",
      "_InputLabel-eb7294d6.js",
      "_Modal-14e61c67.js",
      "_SecondaryButton-51f6a1e1.js",
      "_TextInput-2369dc55.js",
      "_transition-d6ab3856.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Partials/DeleteUserForm.jsx"
  },
  "resources/js/Pages/Users/Partials/UpdatePasswordForm.jsx": {
    file: "assets/UpdatePasswordForm-ebc8e644.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-f1ac2675.js",
      "_InputLabel-eb7294d6.js",
      "_PrimaryButton-dd419429.js",
      "_TextInput-2369dc55.js",
      "_transition-d6ab3856.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Partials/UpdatePasswordForm.jsx"
  },
  "resources/js/Pages/Users/Partials/UpdateProfileInformationForm.jsx": {
    file: "assets/UpdateProfileInformationForm-fd0390c7.js",
    imports: [
      "resources/js/app.jsx",
      "_InputError-f1ac2675.js",
      "_InputLabel-eb7294d6.js",
      "_PrimaryButton-dd419429.js",
      "_TextInput-2369dc55.js",
      "_transition-d6ab3856.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Users/Partials/UpdateProfileInformationForm.jsx"
  },
  "resources/js/Pages/Welcome.jsx": {
    file: "assets/Welcome-f735fc66.js",
    imports: [
      "resources/js/app.jsx",
      "_ApplicationLogo-d276a950.js",
      "_Icon-ce5d2d29.js",
      "_PrimaryButton-dd419429.js",
      "_index-794ed720.js"
    ],
    isDynamicEntry: true,
    src: "resources/js/Pages/Welcome.jsx"
  },
  "resources/js/app.css": {
    file: "assets/app-20b9877a.css",
    src: "resources/js/app.css"
  },
  "resources/js/app.jsx": {
    assets: [
      "assets/Dana-Hairline-7712cf11.woff2",
      "assets/Dana-Hairline-6d7bb084.woff",
      "assets/Dana-Thin-bec2bd8a.woff2",
      "assets/Dana-Thin-56dc1e1f.woff",
      "assets/Dana-UltraLight-24615a03.woff2",
      "assets/Dana-UltraLight-a025f30e.woff",
      "assets/Dana-Light-e07a4868.woff2",
      "assets/Dana-Light-eeed4155.woff",
      "assets/Dana-Medium-d623f857.woff2",
      "assets/Dana-Medium-d0241b30.woff",
      "assets/Dana-DemiBold-34870445.woff2",
      "assets/Dana-DemiBold-fa427dcf.woff",
      "assets/Dana-ExtraBold-08dea612.woff2",
      "assets/Dana-ExtraBold-0d7888d7.woff",
      "assets/Dana-Black-cdfe2203.woff2",
      "assets/Dana-Black-575de1e5.woff",
      "assets/Dana-ExtraBlack-3208afe0.woff2",
      "assets/Dana-ExtraBlack-6c729c23.woff",
      "assets/Dana-Heavy-091eb261.woff2",
      "assets/Dana-Heavy-e159608a.woff",
      "assets/Dana-Fat-1f7b7061.woff2",
      "assets/Dana-Fat-8831a7f0.woff",
      "assets/Dana-Regular-43506011.woff2",
      "assets/Dana-Regular-eee25c04.woff"
    ],
    css: [
      "assets/app-20b9877a.css"
    ],
    dynamicImports: [
      "resources/js/Pages/Accessories/Components/ProductsSlider.jsx",
      "_Create-3787b3cc.js",
      "resources/js/Pages/Accessories/Index.jsx",
      "resources/js/Pages/Accessories/Show.jsx",
      "_Create-3787b3cc.js",
      "_Create-3787b3cc.js",
      "resources/js/Pages/Admin/Accessories.jsx",
      "resources/js/Pages/Admin/Records.jsx",
      "resources/js/Pages/Auth/Address.jsx",
      "resources/js/Pages/Auth/ConfirmPassword.jsx",
      "resources/js/Pages/Auth/ForgotPassword.jsx",
      "resources/js/Pages/Auth/Info.jsx",
      "resources/js/Pages/Auth/Login.jsx",
      "resources/js/Pages/Auth/Register.jsx",
      "resources/js/Pages/Auth/ResetPassword.jsx",
      "resources/js/Pages/Auth/VerifyEmail.jsx",
      "resources/js/Pages/Auth/WaitForVerify.jsx",
      "resources/js/Pages/Dashboards/Admin.jsx",
      "resources/js/Pages/Dashboards/User.jsx",
      "resources/js/Pages/Download/Accessory.jsx",
      "resources/js/Pages/Download/Record.jsx",
      "resources/js/Pages/Patients/Create.jsx",
      "resources/js/Pages/Patients/Edit.jsx",
      "resources/js/Pages/Patients/Index.jsx",
      "resources/js/Pages/Patients/Partials/DeleteUserForm.jsx",
      "resources/js/Pages/Patients/Partials/UpdatePasswordForm.jsx",
      "resources/js/Pages/Patients/Partials/UpdateProfileInformationForm.jsx",
      "resources/js/Pages/Products/CreateOrEdit.jsx",
      "resources/js/Pages/Products/Index.jsx",
      "resources/js/Pages/Profile/Edit.jsx",
      "resources/js/Pages/Profile/Index.jsx",
      "_AidInputs-0fedbed5.js",
      "resources/js/Pages/Records/Components/ProductsSlider.jsx",
      "resources/js/Pages/Records/Components/Steps.jsx",
      "_AidInputs-0fedbed5.js",
      "resources/js/Pages/Records/Index.jsx",
      "resources/js/Pages/Records/Partials/Step.jsx",
      "resources/js/Pages/Records/Show.jsx",
      "_AidInputs-0fedbed5.js",
      "_AidInputs-0fedbed5.js",
      "_AidInputs-0fedbed5.js",
      "_AidInputs-0fedbed5.js",
      "_AidInputs-0fedbed5.js",
      "resources/js/Pages/Settings/CreateOrEdit.jsx",
      "resources/js/Pages/Settings/Index.jsx",
      "resources/js/Pages/Settings/OffLimits.jsx",
      "resources/js/Pages/Settings/OutOfSchedule.jsx",
      "resources/js/Pages/Terms.jsx",
      "resources/js/Pages/Users/Create.jsx",
      "resources/js/Pages/Users/Edit.jsx",
      "resources/js/Pages/Users/Index.jsx",
      "resources/js/Pages/Users/NotCompleted.jsx",
      "resources/js/Pages/Users/Partials/DeleteUserForm.jsx",
      "resources/js/Pages/Users/Partials/UpdatePasswordForm.jsx",
      "resources/js/Pages/Users/Partials/UpdateProfileInformationForm.jsx",
      "resources/js/Pages/Welcome.jsx"
    ],
    file: "assets/app-866ee257.js",
    isEntry: true,
    src: "resources/js/app.jsx"
  }
};
export {
  manifest as m
};
