import { j as jsxs, a as jsx } from "../ssr.js";
import { useState, useEffect } from "react";
import { G as Guest } from "./GuestLayout-7a2aca2c.js";
import { I as InputError } from "./InputError-0c916dba.js";
import { I as InputLabel } from "./InputLabel-b9d20af6.js";
import { P as PrimaryButton } from "./PrimaryButton-6a55fe23.js";
import { T as TextInput } from "./TextInput-ca1f9780.js";
import { C as CheckboxInput } from "./CheckboxInput-b35e3493.js";
import { useForm, Head, Link } from "@inertiajs/react";
import { W as WarningButton } from "./WarningButton-ea0dcf3d.js";
import { I as Icon } from "./Icon-2f3a2698.js";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "./ApplicationLogo-40648ed6.js";
import "./useMemorable-ea291d99.js";
function Login({ status }) {
  const { data, setData, post, processing, errors, reset } = useForm({
    med_number: "",
    password: "",
    remember: false
  });
  const [showPassword, setShowPassword] = useState(false);
  useEffect(() => {
    return () => {
      reset("password");
    };
  }, []);
  const submit = (e) => {
    e.preventDefault();
    post(route("login"));
  };
  return /* @__PURE__ */ jsxs(Guest, { name: "ورود به حساب کاربری", children: [
    /* @__PURE__ */ jsx(Head, { title: "ورود" }),
    status && /* @__PURE__ */ jsx("div", { className: "mb-4 font-medium text-sm text-sky-600", children: status }),
    /* @__PURE__ */ jsxs("form", { onSubmit: submit, children: [
      /* @__PURE__ */ jsxs("div", { className: "block mt-5", children: [
        /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "med_number",
            type: "number",
            name: "med_number",
            label: "نام کاربری (شماره نظام پزشکی)",
            value: data.med_number,
            svgIcon: /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M12 8V16M8 12H16M7.8 21H16.2C17.8802 21 18.7202 21 19.362 20.673C19.9265 20.3854 20.3854 19.9265 20.673 19.362C21 18.7202 21 17.8802 21 16.2V7.8C21 6.11984 21 5.27976 20.673 4.63803C20.3854 4.07354 19.9265 3.6146 19.362 3.32698C18.7202 3 17.8802 3 16.2 3H7.8C6.11984 3 5.27976 3 4.63803 3.32698C4.07354 3.6146 3.6146 4.07354 3.32698 4.63803C3 5.27976 3 6.11984 3 7.8V16.2C3 17.8802 3 18.7202 3.32698 19.362C3.6146 19.9265 4.07354 20.3854 4.63803 20.673C5.27976 21 6.11984 21 7.8 21Z" }),
            onChange: (e) => setData("med_number", e.target.value),
            error: errors.med_number
          }
        ),
        /* @__PURE__ */ jsx(InputError, { message: errors.med_number, className: "mt-2" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "block mt-5 relative", children: [
        /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "password",
            type: showPassword ? "text" : "password",
            name: "password",
            label: "کلمه عبور",
            value: data.password,
            svgIcon: /* @__PURE__ */ jsx(
              "path",
              {
                d: "M6 18C6.06366 18 6.12926 18 6.19691 18H12M6 18C5.01173 17.9992 4.49334 17.9868 4.0918 17.7822C3.71547 17.5905 3.40973 17.2837 3.21799 16.9074C3 16.4796 3 15.9203 3 14.8002V9.2002C3 8.08009 3 7.51962 3.21799 7.0918C3.40973 6.71547 3.71547 6.40973 4.0918 6.21799C4.51962 6 5.08009 6 6.2002 6H17.8002C18.9203 6 19.4796 6 19.9074 6.21799C20.2837 6.40973 20.5905 6.71547 20.7822 7.0918C21 7.5192 21 8.07899 21 9.19691V14.8031C21 15.921 21 16.48 20.7822 16.9074C20.5905 17.2837 20.2837 17.5905 19.9074 17.7822C19.48 18 18.921 18 17.8031 18H12M6 18C6.00004 16.8954 7.34317 16 9 16C10.6569 16 12 16.8954 12 18M6 18C6 18 6 17.9999 6 18ZM18 14H14M18 11H15M9 13C7.89543 13 7 12.1046 7 11C7 9.89543 7.89543 9 9 9C10.1046 9 11 9.89543 11 11C11 12.1046 10.1046 13 9 13Z",
                strokeLinecap: "round",
                strokeLinejoin: "round"
              }
            ),
            onChange: (e) => setData("password", e.target.value),
            error: errors.password
          }
        ),
        /* @__PURE__ */ jsx("div", { className: "absolute top-1/2 -translate-y-1/2 left-0 cursor-pointer transition-all hover:opacity-80", children: showPassword ? /* @__PURE__ */ jsx(
          Icon,
          {
            viewBox: "0 0 24 24",
            type: "fill",
            className: "p-3 !w-12 !h-12",
            onClick: () => setShowPassword(false),
            children: /* @__PURE__ */ jsx("path", { fillRule: "evenodd", clipRule: "evenodd", d: "M19.7071 5.70711C20.0976 5.31658 20.0976 4.68342 19.7071 4.29289C19.3166 3.90237 18.6834 3.90237 18.2929 4.29289L14.032 8.55382C13.4365 8.20193 12.7418 8 12 8C9.79086 8 8 9.79086 8 12C8 12.7418 8.20193 13.4365 8.55382 14.032L4.29289 18.2929C3.90237 18.6834 3.90237 19.3166 4.29289 19.7071C4.68342 20.0976 5.31658 20.0976 5.70711 19.7071L9.96803 15.4462C10.5635 15.7981 11.2582 16 12 16C14.2091 16 16 14.2091 16 12C16 11.2582 15.7981 10.5635 15.4462 9.96803L19.7071 5.70711ZM12.518 10.0677C12.3528 10.0236 12.1792 10 12 10C10.8954 10 10 10.8954 10 12C10 12.1792 10.0236 12.3528 10.0677 12.518L12.518 10.0677ZM11.482 13.9323L13.9323 11.482C13.9764 11.6472 14 11.8208 14 12C14 13.1046 13.1046 14 12 14C11.8208 14 11.6472 13.9764 11.482 13.9323ZM15.7651 4.8207C14.6287 4.32049 13.3675 4 12 4C9.14754 4 6.75717 5.39462 4.99812 6.90595C3.23268 8.42276 2.00757 10.1376 1.46387 10.9698C1.05306 11.5985 1.05306 12.4015 1.46387 13.0302C1.92276 13.7326 2.86706 15.0637 4.21194 16.3739L5.62626 14.9596C4.4555 13.8229 3.61144 12.6531 3.18002 12C3.6904 11.2274 4.77832 9.73158 6.30147 8.42294C7.87402 7.07185 9.81574 6 12 6C12.7719 6 13.5135 6.13385 14.2193 6.36658L15.7651 4.8207ZM12 18C11.2282 18 10.4866 17.8661 9.78083 17.6334L8.23496 19.1793C9.37136 19.6795 10.6326 20 12 20C14.8525 20 17.2429 18.6054 19.002 17.0941C20.7674 15.5772 21.9925 13.8624 22.5362 13.0302C22.947 12.4015 22.947 11.5985 22.5362 10.9698C22.0773 10.2674 21.133 8.93627 19.7881 7.62611L18.3738 9.04043C19.5446 10.1771 20.3887 11.3469 20.8201 12C20.3097 12.7726 19.2218 14.2684 17.6986 15.5771C16.1261 16.9282 14.1843 18 12 18Z" })
          }
        ) : /* @__PURE__ */ jsx(
          Icon,
          {
            viewBox: "0 0 24 24",
            type: "fill",
            className: "p-3 !w-12 !h-12",
            onClick: () => setShowPassword(true),
            children: /* @__PURE__ */ jsx("path", { fillRule: "evenodd", clipRule: "evenodd", d: "M6.30147 15.5771C4.77832 14.2684 3.6904 12.7726 3.18002 12C3.6904 11.2274 4.77832 9.73158 6.30147 8.42294C7.87402 7.07185 9.81574 6 12 6C14.1843 6 16.1261 7.07185 17.6986 8.42294C19.2218 9.73158 20.3097 11.2274 20.8201 12C20.3097 12.7726 19.2218 14.2684 17.6986 15.5771C16.1261 16.9282 14.1843 18 12 18C9.81574 18 7.87402 16.9282 6.30147 15.5771ZM12 4C9.14754 4 6.75717 5.39462 4.99812 6.90595C3.23268 8.42276 2.00757 10.1376 1.46387 10.9698C1.05306 11.5985 1.05306 12.4015 1.46387 13.0302C2.00757 13.8624 3.23268 15.5772 4.99812 17.0941C6.75717 18.6054 9.14754 20 12 20C14.8525 20 17.2429 18.6054 19.002 17.0941C20.7674 15.5772 21.9925 13.8624 22.5362 13.0302C22.947 12.4015 22.947 11.5985 22.5362 10.9698C21.9925 10.1376 20.7674 8.42276 19.002 6.90595C17.2429 5.39462 14.8525 4 12 4ZM10 12C10 10.8954 10.8955 10 12 10C13.1046 10 14 10.8954 14 12C14 13.1046 13.1046 14 12 14C10.8955 14 10 13.1046 10 12ZM12 8C9.7909 8 8.00004 9.79086 8.00004 12C8.00004 14.2091 9.7909 16 12 16C14.2092 16 16 14.2091 16 12C16 9.79086 14.2092 8 12 8Z" })
          }
        ) }),
        /* @__PURE__ */ jsx(InputError, { message: errors.password, className: "mt-2" })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "block mt-3", children: /* @__PURE__ */ jsxs("div", { className: "inline-block ml-8 mt-2", children: [
        /* @__PURE__ */ jsx(
          CheckboxInput,
          {
            id: "remember",
            name: "remember",
            checked: data.remember,
            onChange: (e) => setData("remember", e.target.checked)
          }
        ),
        /* @__PURE__ */ jsx(
          InputLabel,
          {
            htmlFor: "remember",
            value: "به خاطر سپاردن",
            className: "mr-2"
          }
        )
      ] }) }),
      /* @__PURE__ */ jsxs("div", { className: "mt-6", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0", children: [
          /* @__PURE__ */ jsx(PrimaryButton, { className: "w-full xl:w-3/4 ml-5", disabled: processing, children: "ورود به حساب کاربری" }),
          /* @__PURE__ */ jsx(
            WarningButton,
            {
              bordered: true,
              className: "w-full xl:w-1/4 text-xs xl:text-sm",
              href: route("register"),
              link: true,
              children: "ثبت نام"
            }
          )
        ] }),
        /* @__PURE__ */ jsx("div", { className: "mt-6 text-center", children: /* @__PURE__ */ jsx(
          Link,
          {
            href: route("password.request"),
            className: "text-sm text-blue-950 dark:text-blue-300 hover:underline",
            children: "کلمه عبور خود را فراموش کرده اید؟"
          }
        ) })
      ] })
    ] })
  ] });
}
export {
  Login as default
};
