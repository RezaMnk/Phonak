import { j as jsxs, a as jsx } from "../ssr.js";
import { G as Guest } from "./GuestLayout-7a2aca2c.js";
import { Head } from "@inertiajs/react";
import { Player } from "@lottiefiles/react-lottie-player";
import { P as PrimaryButton } from "./PrimaryButton-6a55fe23.js";
import { D as DangerButton } from "./DangerButton-d6ee3472.js";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "./ApplicationLogo-40648ed6.js";
import "./useMemorable-ea291d99.js";
import "react";
function Address({ user }) {
  return /* @__PURE__ */ jsxs(Guest, { className: "!max-w-3xl", children: [
    /* @__PURE__ */ jsx(Head, { title: "در انتظار تایید" }),
    /* @__PURE__ */ jsxs("div", { className: "w-full text-center text-gray-700 dark:text-slate-200", children: [
      /* @__PURE__ */ jsx(
        Player,
        {
          autoplay: true,
          loop: true,
          src: user.status === "waiting" ? "/storage/animations/verifying.json" : "/storage/animations/error.json",
          style: { height: "300px" }
        }
      ),
      /* @__PURE__ */ jsx("h4", { className: "font-bold text-lg", children: user.status === "waiting" ? "در حال بررسی اطلاعات" : "اطلاعات شما تایید نشد!" }),
      /* @__PURE__ */ jsx("p", { className: "px-12 md:px-40 mt-5 mb-12", children: user.status === "waiting" ? "اطلاعات شما در حال بررسی می باشد، ظرف 48 ساعت کاری اینده اطلاعات شما بررسی میگردد و پس از تایید، به گروه واتساپی خانواده آشنا خواهید پیوست." : user.disapprove ? "پیام مدیرییت: " + user.disapprove : "اطلاعات شما مورد تایید واقع نشدند. لطفا مجددا اطلاعات خود را بررسی بفرمایید." }),
      /* @__PURE__ */ jsx("hr", { className: "my-2 border-gray-300 border-slate-600" }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row gap-5", children: [
        /* @__PURE__ */ jsx(
          PrimaryButton,
          {
            className: "w-full xl:w-9/12 !px-4 !py-2",
            link: true,
            href: route("profile.edit"),
            children: "ویرایش اطلاعات ثبت شده"
          }
        ),
        /* @__PURE__ */ jsx(
          DangerButton,
          {
            className: "w-full xl:w-3/12 !px-4 !py-2",
            link: true,
            method: "POST",
            href: route("logout"),
            as: "button",
            children: "خروج از حساب"
          }
        )
      ] })
    ] })
  ] });
}
export {
  Address as default
};
