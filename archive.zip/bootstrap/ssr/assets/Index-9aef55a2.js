import { j as jsxs, a as jsx, F as Fragment } from "../ssr.js";
import { A as Authenticated } from "./AuthenticatedLayout-c3b08c0f.js";
import { useForm, Head, Link } from "@inertiajs/react";
import { S as SecondaryButton } from "./SecondaryButton-5e4fee1b.js";
import { D as DangerButton } from "./DangerButton-d6ee3472.js";
import { M as Modal } from "./Modal-dd933eed.js";
import { useState } from "react";
import { P as PrimaryButton } from "./PrimaryButton-6a55fe23.js";
import { P as Pagination } from "./Pagination-781980f1.js";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "react-toastify";
import "./useMemorable-ea291d99.js";
import "./ApplicationLogo-40648ed6.js";
import "./Icon-2f3a2698.js";
import "@headlessui/react";
import "./useFirstRender-5b0e5bdf.js";
function Index({ accessories }) {
  const [deleteModalShow, setDeleteModalShow] = useState(false);
  const [modalAccessory, setModalAccessory] = useState({});
  const data_accessories = accessories.data;
  const {
    delete: destroy,
    processing
  } = useForm();
  const deleteAccessory = (e) => {
    e.preventDefault();
    destroy(route("accessories.destroy", modalAccessory), {
      preserveScroll: true,
      onSuccess: () => closeModal()
    });
  };
  const closeModal = () => {
    setDeleteModalShow(false);
  };
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      header: "سفارشات لوازم جانبی",
      breadcrumbs: {
        "سفارشات لوازم جانبی": route("accessories.index")
      },
      headerExtra: /* @__PURE__ */ jsx(
        PrimaryButton,
        {
          link: true,
          href: route("accessories.create"),
          className: "!px-4 !py-2 text-xs",
          children: "سفارش جدید"
        }
      ),
      children: [
        /* @__PURE__ */ jsx(Head, { title: "سفارشات لوازم جانبی" }),
        /* @__PURE__ */ jsx("div", { className: "mb-8 p-4 text-sm font-semibold bg-teal-200 dark:bg-teal-700 text-teal-700 dark:text-teal-100 rounded-lg", children: "لطفا پس از پرداخت منتظر هدایت شدن به وبسایت بمانید." }),
        /* @__PURE__ */ jsx("div", { className: "relative overflow-x-auto rounded-lg", children: /* @__PURE__ */ jsxs("table", { className: "w-full text-right text-gray-500 dark:text-slate-400", children: [
          /* @__PURE__ */ jsx("thead", { className: "text-xs text-gray-700 dark:text-gray-300 bg-gray-50 dark:bg-slate-700", children: /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx("th", { scope: "col", className: "px-6 py-3 hidden xl:table-cell", children: "شماره سفارش" }),
            /* @__PURE__ */ jsx("th", { scope: "col", className: "px-6 py-3", children: "محصول" }),
            /* @__PURE__ */ jsx("th", { scope: "col", className: "px-6 py-3", children: "وضعیت" }),
            /* @__PURE__ */ jsx("th", { scope: "col", className: "px-6 py-3", children: "عملیات" })
          ] }) }),
          /* @__PURE__ */ jsx("tbody", { children: Object.keys(data_accessories).length ? Object.values(data_accessories).map((accessory) => {
            const is_last = data_accessories[Object.keys(data_accessories).length - 1] === accessory;
            return /* @__PURE__ */ jsxs("tr", { className: `bg-white text-gray-700 dark:text-slate-300 dark:bg-slate-900 ${!is_last ? "border-b" : ""} border-gray-200 dark:border-slate-600`, children: [
              /* @__PURE__ */ jsx(
                "th",
                {
                  scope: "row",
                  className: "px-6 py-4 hidden xl:table-cell",
                  children: accessory.id
                }
              ),
              /* @__PURE__ */ jsx("td", { className: "px-6 py-4", children: accessory.product.name }),
              /* @__PURE__ */ jsxs("td", { className: "px-6 py-4", children: [
                accessory.status === "completed" && /* @__PURE__ */ jsx("span", { className: "inline-flex whitespace-nowrap items-center rounded-md bg-yellow-50 dark:bg-yellow-500/30 px-2 py-1 text-sm font-medium text-yellow-800 dark:text-yellow-300/70 ring-1 ring-inset ring-yellow-600/20", children: "در انتظار پرداخت" }),
                accessory.status === "paid" && /* @__PURE__ */ jsx("span", { className: "inline-flex whitespace-nowrap items-center rounded-md bg-sky-50 dark:bg-sky-500/30 px-2 py-1 text-sm font-medium text-sky-800 dark:text-sky-300/70 ring-1 ring-inset ring-sky-600/20", children: "پرداخت شده" }),
                accessory.status === "approved" && /* @__PURE__ */ jsx("span", { className: "inline-flex whitespace-nowrap items-center rounded-md bg-green-50 dark:bg-green-500/30 px-2 py-1 text-sm font-medium text-green-800 dark:text-green-300/70 ring-1 ring-inset ring-green-600/20", children: "تایید شده" }),
                accessory.status === "canceled" && /* @__PURE__ */ jsx("span", { className: "inline-flex whitespace-nowrap items-center rounded-md bg-stone-50 dark:bg-stone-500/30 px-2 py-1 text-sm font-medium text-stone-800 dark:text-stone-300/70 ring-1 ring-inset ring-stone-600/20", children: "لغو شده" }),
                !["completed", "paid", "canceled", "approved"].includes(accessory.status) && /* @__PURE__ */ jsx("span", { className: "inline-flex whitespace-nowrap items-center rounded-md bg-red-50 dark:bg-red-500/30 px-2 py-1 text-sm font-medium text-red-800 dark:text-red-300/70 ring-1 ring-inset ring-red-600/20", children: "در انتظار تکمیل" })
              ] }),
              /* @__PURE__ */ jsxs("td", { className: "px-6 py-4 whitespace-nowrap", children: [
                accessory.status === "completed" && /* @__PURE__ */ jsx(
                  "a",
                  {
                    href: route("accessories.pay", [accessory.id]),
                    className: "inline-flex px-2 py-1 text-xs text-center text-green-900 dark:text-green-200 transition-colors duration-300 bg-green-100 dark:bg-green-600/50 border border-green-200 dark:border-green-800 rounded-lg hover:bg-green-200 dark:hover:bg-green-600 focus:outline-none focus:ring-0 focus:border-green-500",
                    target: "_blank",
                    children: "پرداخت سفارش"
                  }
                ),
                ["paid", "approved", "canceled"].includes(accessory.status) ? /* @__PURE__ */ jsx(
                  Link,
                  {
                    href: route("accessories.show", [accessory.id]),
                    className: "inline-flex px-2 py-1 text-xs text-center text-sky-900 dark:text-sky-200 transition-colors duration-300 bg-sky-100 dark:bg-sky-600/50 border border-sky-200 dark:border-sky-800 rounded-lg hover:bg-sky-200 dark:hover:bg-sky-600 focus:outline-none focus:ring-0 focus:border-sky-500",
                    children: "نمایش"
                  }
                ) : /* @__PURE__ */ jsxs(Fragment, { children: [
                  /* @__PURE__ */ jsx(
                    Link,
                    {
                      href: route("accessories.edit", [accessory.id]),
                      className: "inline-flex mr-2 px-2 py-1 text-xs text-center text-yellow-900 dark:text-yellow-200 transition-colors duration-300 bg-yellow-100 dark:bg-yellow-600/50 border border-yellow-200 dark:border-yellow-800 rounded-lg hover:bg-yellow-200 dark:hover:bg-yellow-600 focus:outline-none focus:ring-0 focus:border-yellow-500",
                      children: "ویرایش"
                    }
                  ),
                  /* @__PURE__ */ jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => {
                        setDeleteModalShow(true);
                        setModalAccessory(accessory);
                      },
                      className: "inline-flex mr-2 px-2 py-1 text-xs text-center text-red-900 dark:text-red-200 transition-colors duration-300 bg-red-100 dark:bg-red-600/50 border border-red-200 dark:border-red-800 rounded-lg hover:bg-red-200 dark:hover:bg-red-600 focus:outline-none focus:ring-0 focus:border-red-500",
                      children: "حذف"
                    }
                  )
                ] })
              ] })
            ] }, accessory.id);
          }) : /* @__PURE__ */ jsx("tr", { className: "bg-white text-gray-700 dark:text-slate-300 dark:bg-slate-900", children: /* @__PURE__ */ jsxs(
            "th",
            {
              scope: "row",
              colSpan: "6",
              className: "text-lg px-6 py-6",
              children: [
                "هیچ سفارشی یافت نشد!",
                /* @__PURE__ */ jsx(
                  Link,
                  {
                    href: route("accessories.create"),
                    className: "mr-2 text-sky-500 text-base",
                    children: "ایجاد اولین سفارش"
                  }
                )
              ]
            }
          ) }) })
        ] }) }),
        /* @__PURE__ */ jsx(Pagination, { data: accessories }),
        /* @__PURE__ */ jsx(Modal, { show: deleteModalShow, onClose: closeModal, maxWidth: "sm", children: /* @__PURE__ */ jsxs("form", { onSubmit: deleteAccessory, className: "p-6", children: [
          /* @__PURE__ */ jsx("h2", { className: "text-lg font-semibold text-gray-700 dark:text-slate-200", children: "آیا از حذف سفارش مطمئن هستید؟" }),
          /* @__PURE__ */ jsx("p", { className: "mt-5 text-gray-600 dark:text-slate-300", children: "با حذف سفارش، اطلاعات ثبت شده حذف خواهند شد و غیرقابل برگشت خواهند بود!" }),
          /* @__PURE__ */ jsxs("div", { className: "mt-6 flex justify-between", children: [
            /* @__PURE__ */ jsx(SecondaryButton, { className: "!px-4 !py-2 text-xs", type: "button", onClick: closeModal, children: "لغو" }),
            /* @__PURE__ */ jsx(DangerButton, { className: "mr-3 !px-4 !py-2 text-xs", disabled: processing, children: "تایید حذف سفارش" })
          ] })
        ] }) })
      ]
    }
  );
}
export {
  Index as default
};
