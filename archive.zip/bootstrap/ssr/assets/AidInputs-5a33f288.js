import { j as jsxs, F as Fragment, a as jsx } from "../ssr.js";
import { S as SelectInput } from "./SelectInput-257ca42f.js";
import { I as InputError } from "./InputError-0c916dba.js";
import { useContext, useState, useEffect, createContext } from "react";
import { useForm, Head } from "@inertiajs/react";
import { P as PrimaryButton } from "./PrimaryButton-6a55fe23.js";
import { D as DangerButton } from "./DangerButton-d6ee3472.js";
import { A as Authenticated } from "./AuthenticatedLayout-c3b08c0f.js";
import Steps from "./Steps-1b9b711f.js";
import { T as TextInput } from "./TextInput-ca1f9780.js";
import { T as TextAreaInput } from "./TextAreaInput-7c309df0.js";
import { I as IranStatesOptions, C as Cities } from "./IranStatesOptions-7761120b.js";
import { F as FileInput } from "./FileInput-f4444771.js";
import { R as RadioInput } from "./RadioInput-a6c65c03.js";
import { I as InputLabel } from "./InputLabel-b9d20af6.js";
import ProductsSlider from "./ProductsSlider-626fa326.js";
import { u as useFirstRender } from "./useFirstRender-5b0e5bdf.js";
import { C as CheckboxInput } from "./CheckboxInput-b35e3493.js";
import { I as Icon } from "./Icon-2f3a2698.js";
import "react-toastify";
function PatientStep() {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j;
  const { record, nextStep } = useContext(StepContext);
  const { data, setData, post, patch, processing, errors } = useForm({
    state: ((_a = record == null ? void 0 : record.patient) == null ? void 0 : _a.state) || "تهران",
    city: ((_b = record == null ? void 0 : record.patient) == null ? void 0 : _b.city) || "تهران",
    national_code: ((_c = record == null ? void 0 : record.patient) == null ? void 0 : _c.national_code) || "",
    name: ((_d = record == null ? void 0 : record.patient) == null ? void 0 : _d.name) || "",
    eng_name: ((_e = record == null ? void 0 : record.patient) == null ? void 0 : _e.eng_name) || "",
    insurance: ((_f = record == null ? void 0 : record.patient) == null ? void 0 : _f.insurance) || "",
    address: ((_g = record == null ? void 0 : record.patient) == null ? void 0 : _g.address) || "",
    post_code: ((_h = record == null ? void 0 : record.patient) == null ? void 0 : _h.post_code) || "",
    phone: ((_i = record == null ? void 0 : record.patient) == null ? void 0 : _i.phone) || "",
    birth_year: ((_j = record == null ? void 0 : record.patient) == null ? void 0 : _j.birth_year) || "",
    prescription_image: (record == null ? void 0 : record.prescription_image) || ""
  });
  const [oldPatient, setOldPatient] = useState(false);
  const submit = (e) => {
    e.preventDefault();
    if (record)
      patch(route("records.update", record.id), {
        preserveScroll: true,
        onSuccess: () => {
          nextStep();
        }
      });
    else
      post(route("records.store"), {
        preserveScroll: true,
        onSuccess: () => {
          nextStep();
        }
      });
  };
  const update_patient = (new_patient) => {
    setData((data2) => ({
      ...data2,
      name: new_patient.name,
      eng_name: new_patient.eng_name,
      insurance: new_patient.insurance,
      state: new_patient.state,
      city: new_patient.city,
      address: new_patient.address,
      post_code: new_patient.post_code,
      phone: new_patient.phone,
      birth_year: new_patient.birth_year
    }));
  };
  const reset_form = () => {
    setData((data2) => ({
      ...data2,
      name: "",
      eng_name: "",
      insurance: "",
      state: "تهران",
      city: "تهران",
      address: "",
      post_code: "",
      phone: "",
      birth_year: ""
    }));
  };
  const national_code_change = (e) => {
    setData("national_code", e.target.value);
    if (e.target.value.length === 10)
      check_national_code(e.target.value);
  };
  const check_national_code = async (national_code) => {
    try {
      const response = await axios.post(route("records.check_national_code"), { national_code });
      let patient = response.data.patient;
      if (patient) {
        update_patient(response.data.patient);
        setOldPatient(true);
      } else {
        setOldPatient(false);
        reset_form();
      }
    } catch (error) {
      console.log("error!");
      setOldPatient(false);
    }
  };
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Head, { title: "سفارش - کاربر" }),
    /* @__PURE__ */ jsxs("form", { className: "w-full", onSubmit: submit, children: [
      /* @__PURE__ */ jsxs("div", { className: "text-gray-700 dark:text-slate-200", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex justify-between items-end", children: [
          /* @__PURE__ */ jsx("h5", { children: "اطلاعات کاربر" }),
          /* @__PURE__ */ jsxs(
            "div",
            {
              className: `transition-all ${data.national_code.length === 10 ? "opacity-1 visible" : "opacity-0 invisible"}`,
              children: [
                /* @__PURE__ */ jsx(
                  "div",
                  {
                    className: `inline-block ml-1 w-2 h-2 ${oldPatient ? "bg-red-500 dark:bg-red-300" : ""} rounded-full`
                  }
                ),
                oldPatient && /* @__PURE__ */ jsx("span", { className: "text-sm", children: "کاربر قبلا پرونده داشته است!" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsx("hr", { className: "dark:border-slate-600" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row gap-5 mt-6 mb-5", children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/6", children: [
          /* @__PURE__ */ jsx(
            TextInput,
            {
              id: "national_code",
              name: "national_code",
              type: "number",
              value: data.national_code,
              label: "کد ملی کاربر",
              svgIcon: /* @__PURE__ */ jsx(
                "path",
                {
                  d: "M6 18C6.06366 18 6.12926 18 6.19691 18H12M6 18C5.01173 17.9992 4.49334 17.9868 4.0918 17.7822C3.71547 17.5905 3.40973 17.2837 3.21799 16.9074C3 16.4796 3 15.9203 3 14.8002V9.2002C3 8.08009 3 7.51962 3.21799 7.0918C3.40973 6.71547 3.71547 6.40973 4.0918 6.21799C4.51962 6 5.08009 6 6.2002 6H17.8002C18.9203 6 19.4796 6 19.9074 6.21799C20.2837 6.40973 20.5905 6.71547 20.7822 7.0918C21 7.5192 21 8.07899 21 9.19691V14.8031C21 15.921 21 16.48 20.7822 16.9074C20.5905 17.2837 20.2837 17.5905 19.9074 17.7822C19.48 18 18.921 18 17.8031 18H12M6 18C6.00004 16.8954 7.34317 16 9 16C10.6569 16 12 16.8954 12 18M6 18C6 18 6 17.9999 6 18ZM18 14H14M18 11H15M9 13C7.89543 13 7 12.1046 7 11C7 9.89543 7.89543 9 9 9C10.1046 9 11 9.89543 11 11C11 12.1046 10.1046 13 9 13Z",
                  strokeLinecap: "round",
                  strokeLinejoin: "round"
                }
              ),
              onChange: national_code_change,
              error: errors.national_code
            }
          ),
          /* @__PURE__ */ jsx(InputError, { message: errors.national_code, className: "mt-2" }),
          /* @__PURE__ */ jsx(
            PrimaryButton,
            {
              className: "text-xs rounded mt-2 !px-2 !py-1",
              link: true,
              target: "_blank",
              href: "https://searchline.ir/NationalCode",
              children: "استعلام صحت کد ملی"
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4", children: [
          /* @__PURE__ */ jsx(
            TextInput,
            {
              id: "name",
              name: "name",
              value: data.name,
              label: "نام و نام خانوادگی کاربر",
              svgIcon: /* @__PURE__ */ jsx(
                "path",
                {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  d: "M20 21C20 18.2386 16.4183 16 12 16C7.58172 16 4 18.2386 4 21M12 13C9.23858 13 7 10.7614 7 8C7 5.23858 9.23858 3 12 3C14.7614 3 17 5.23858 17 8C17 10.7614 14.7614 13 12 13Z"
                }
              ),
              onChange: (e) => setData("name", e.target.value),
              error: errors.name
            }
          ),
          /* @__PURE__ */ jsx(InputError, { message: errors.name, className: "mt-2" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-[12%]", children: [
          /* @__PURE__ */ jsx(
            TextInput,
            {
              id: "birth_year",
              name: "birth_year",
              type: "number",
              value: data.birth_year,
              label: "سال تولد",
              svgIcon: /* @__PURE__ */ jsx(
                "path",
                {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  d: "M20 21C20 18.2386 16.4183 16 12 16C7.58172 16 4 18.2386 4 21M12 13C9.23858 13 7 10.7614 7 8C7 5.23858 9.23858 3 12 3C14.7614 3 17 5.23858 17 8C17 10.7614 14.7614 13 12 13Z"
                }
              ),
              onChange: (e) => setData("birth_year", e.target.value),
              error: errors.birth_year
            }
          ),
          /* @__PURE__ */ jsx(InputError, { message: errors.birth_year, className: "mt-2" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4", children: [
          /* @__PURE__ */ jsx(
            TextInput,
            {
              id: "phone",
              name: "phone",
              type: "number",
              value: data.phone,
              label: "تلفن همراه کاربر",
              svgIcon: /* @__PURE__ */ jsx(
                "path",
                {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  d: "M20 21C20 18.2386 16.4183 16 12 16C7.58172 16 4 18.2386 4 21M12 13C9.23858 13 7 10.7614 7 8C7 5.23858 9.23858 3 12 3C14.7614 3 17 5.23858 17 8C17 10.7614 14.7614 13 12 13Z"
                }
              ),
              onChange: (e) => setData("phone", e.target.value),
              error: errors.phone
            }
          ),
          /* @__PURE__ */ jsx(InputError, { message: errors.phone, className: "mt-2" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4", children: [
          /* @__PURE__ */ jsx(
            TextInput,
            {
              id: "eng_name",
              name: "eng_name",
              value: data.eng_name,
              label: "نام و نام خانوادگی کاربر به لاتین",
              svgIcon: /* @__PURE__ */ jsx(
                "path",
                {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  d: "M20 21C20 18.2386 16.4183 16 12 16C7.58172 16 4 18.2386 4 21M12 13C9.23858 13 7 10.7614 7 8C7 5.23858 9.23858 3 12 3C14.7614 3 17 5.23858 17 8C17 10.7614 14.7614 13 12 13Z"
                }
              ),
              onChange: (e) => setData("eng_name", e.target.value),
              error: errors.eng_name
            }
          ),
          /* @__PURE__ */ jsx(InputError, { message: errors.eng_name, className: "mt-2" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row gap-5 mt-8", children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4", children: [
          /* @__PURE__ */ jsx(
            TextInput,
            {
              id: "insurance",
              name: "insurance",
              value: data.insurance,
              label: "نوع بیمه",
              svgIcon: /* @__PURE__ */ jsx("path", { d: "M9 14H15M12 11V17M8 7H7.8C6.11984 7 5.27976 7 4.63803 7.32698C4.07354 7.6146 3.6146 8.07354 3.32698 8.63803C3 9.27976 3 10.1198 3 11.8V16.2C3 17.8802 3 18.7202 3.32698 19.362C3.6146 19.9265 4.07354 20.3854 4.63803 20.673C5.27976 21 6.11984 21 7.8 21H16.2C17.8802 21 18.7202 21 19.362 20.673C19.9265 20.3854 20.3854 19.9265 20.673 19.362C21 18.7202 21 17.8802 21 16.2V11.8C21 10.1198 21 9.27976 20.673 8.63803C20.3854 8.07354 19.9265 7.6146 19.362 7.32698C18.7202 7 17.8802 7 16.2 7H16M8 7V6C8 4.34315 9.34315 3 11 3H13C14.6569 3 16 4.34315 16 6V7M8 7H16" }),
              onChange: (e) => setData("insurance", e.target.value),
              error: errors.insurance
            }
          ),
          /* @__PURE__ */ jsx(InputError, { message: errors.insurance, className: "mt-2" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4", children: [
          /* @__PURE__ */ jsx(
            SelectInput,
            {
              id: "state",
              name: "state",
              value: data.state,
              label: "استان محل اقامت",
              onChange: (e) => setData("state", e.target.value),
              error: errors.state,
              children: /* @__PURE__ */ jsx(IranStatesOptions, {})
            }
          ),
          /* @__PURE__ */ jsx(InputError, { message: errors.state, className: "mt-2" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4", children: [
          /* @__PURE__ */ jsx(
            SelectInput,
            {
              id: "city",
              name: "name",
              value: data.city,
              label: "شهر محل اقامت",
              onChange: (e) => setData("city", e.target.value),
              error: errors.city,
              children: /* @__PURE__ */ jsx(Cities, { state: data.state })
            }
          ),
          /* @__PURE__ */ jsx(InputError, { message: errors.city, className: "mt-2" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4", children: [
          /* @__PURE__ */ jsx(
            TextInput,
            {
              id: "post_code",
              name: "post_code",
              value: data.post_code,
              label: "کد پستی",
              svgIcon: /* @__PURE__ */ jsxs("g", { children: [
                /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M10 3L8 21" }),
                /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M16 3L14 21" }),
                /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M3.5 9H21.5" }),
                /* @__PURE__ */ jsx("path", { xmlns: "http://www.w3.org/2000/svg", d: "M2.5 15H20.5" })
              ] }),
              autoComplete: "post_code",
              onChange: (e) => setData("post_code", e.target.value),
              error: errors.post_code
            }
          ),
          /* @__PURE__ */ jsx(InputError, { message: errors.post_code, className: "mt-2" }),
          /* @__PURE__ */ jsxs("span", { className: "inline-block mt-2 text-sm text-gray-500 dark:text-slate-400", children: [
            "لطفا صحت کد پستی را بررسی فرمایید:",
            /* @__PURE__ */ jsx(
              PrimaryButton,
              {
                className: "text-xs rounded !px-2 !py-1 mr-1",
                link: true,
                target: "_blank",
                href: "https://searchline.ir/PostalCode",
                children: "استعلام کد پستی"
              }
            )
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "flex flex-col xl:flex-row gap-5 mt-8", children: /* @__PURE__ */ jsxs("div", { className: "w-full", children: [
        /* @__PURE__ */ jsx(
          TextAreaInput,
          {
            id: "address",
            name: "address",
            value: data.address,
            rows: "4",
            label: "آدرس کامل محل اقامت",
            svgIcon: /* @__PURE__ */ jsx(
              "path",
              {
                d: "M3.99999 10L12 3L20 10L20 20H15V16C15 15.2044 14.6839 14.4413 14.1213 13.8787C13.5587 13.3161 12.7956 13 12 13C11.2043 13 10.4413 13.3161 9.87868 13.8787C9.31607 14.4413 9 15.2043 9 16V20H4L3.99999 10Z",
                strokeLinecap: "round",
                strokeLinejoin: "round"
              }
            ),
            autoComplete: "address",
            onChange: (e) => setData("address", e.target.value),
            error: errors.address
          }
        ),
        /* @__PURE__ */ jsx(InputError, { message: errors.address, className: "mt-2" })
      ] }) }),
      /* @__PURE__ */ jsx("div", { className: "flex justify-end mt-8", children: /* @__PURE__ */ jsx(
        PrimaryButton,
        {
          className: "!px-4 !py-2",
          disabled: processing,
          type: "submit",
          children: "مرحله بعد"
        }
      ) })
    ] })
  ] });
}
const PatientStep$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: PatientStep
}, Symbol.toStringTag, { value: "Module" }));
function AidTypeStep() {
  const { record, nextStep, prevStep } = useContext(StepContext);
  const { data, setData, post, processing, errors, clearErrors } = useForm({
    brand: record.brand || "",
    type: record.type || "",
    ear: record.ear || "",
    product: record.product_id || "",
    has_mold: record.has_mold,
    has_package: record.has_package,
    has_charger: record.has_charger
  });
  const firstRender = useFirstRender();
  const [products, setProducts] = useState({});
  const [product, setProduct] = useState(record.product_id || "");
  const [productsItems, setProductsItems] = useState({});
  const [productItems, setProductItems] = useState([]);
  useEffect(() => {
    setData("product", product);
    const items = firstRender ? [record.has_package && "package", record.has_mold && "mold", record.has_charger && "charger"] : ["package", "charger"];
    setProductItems(items);
    clearErrors("product");
  }, [product]);
  useEffect(() => {
    setData((data2) => ({
      ...data2,
      has_package: productItems.includes("package"),
      has_mold: productItems.includes("mold"),
      has_charger: productItems.includes("charger")
    }));
  }, [productItems]);
  useEffect(() => {
    if (data.type && data.brand) {
      get_products(data.type).then(() => {
        if (!firstRender) {
          setData("product", "");
          setProduct("");
        }
      });
    }
  }, [data.type, data.brand]);
  const submit = (e) => {
    e.preventDefault();
    post(route("records.store_aid_type", record.id), {
      preserveScroll: true,
      onSuccess: () => {
        nextStep();
      }
    });
  };
  const get_products = async () => {
    try {
      const response = await axios.post(route("records.products"), { type: data.type, brand: data.brand });
      let new_products = response.data.products;
      if (new_products) {
        setProducts(new_products);
        let items = {};
        for (let loop_product of Object.values(products)) {
          items[loop_product.id] = [];
          if (loop_product.has_package) {
            items[loop_product.id].push("package");
          }
          if (loop_product.has_mold) {
            items[loop_product.id].push("mold");
          }
          if (loop_product.has_charger) {
            items[loop_product.id].push("charger");
          }
        }
        setProductsItems(items);
      } else {
        console.log("none");
      }
    } catch (error) {
      console.log("error!");
    }
  };
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Head, { title: "سفارش - نوع سفارش" }),
    /* @__PURE__ */ jsxs("form", { className: "w-full", onSubmit: submit, noValidate: true, children: [
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-3", children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3 ml-5 text-gray-700 dark:text-slate-200", children: [
          /* @__PURE__ */ jsx("p", { children: "برند مورد سفارش:" }),
          /* @__PURE__ */ jsx(InputError, { message: errors.brand, className: "mt-2" }),
          /* @__PURE__ */ jsxs("div", { className: "mt-5 flex justify-between xl:justify-start", children: [
            /* @__PURE__ */ jsxs("div", { className: "inline-block ml-5", children: [
              /* @__PURE__ */ jsx(
                RadioInput,
                {
                  id: "brand_phonak",
                  className: "hidden peer",
                  name: "brand",
                  checked: data.brand === "phonak",
                  onChange: () => setData("brand", "phonak")
                }
              ),
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "brand_phonak",
                  className: "bg-lime-500/30 dark:bg-lime-400/40 peer-checked:bg-lime-500/50 peer-checked:dark:bg-lime-400/50 border border-gray-200 dark:border-slate-500 rounded-lg peer-checked:border-green-400",
                  children: /* @__PURE__ */ jsxs("div", { className: "p-2", children: [
                    /* @__PURE__ */ jsx("img", { src: "/storage/brands/phonak.png", alt: "", className: "w-24 h-24 object-contain" }),
                    /* @__PURE__ */ jsx("hr", { className: "my-4 border-gray-200 dark:border-slate-500" }),
                    /* @__PURE__ */ jsx("p", { className: "text-center", children: "فوناک" })
                  ] })
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "inline-block ml-5", children: [
              /* @__PURE__ */ jsx(
                RadioInput,
                {
                  id: "brand_hansaton",
                  className: "hidden peer",
                  name: "brand",
                  checked: data.brand === "hansaton",
                  onChange: () => setData("brand", "hansaton")
                }
              ),
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "brand_hansaton",
                  className: "bg-red-500/30 dark:bg-red-400/40 peer-checked:bg-red-500/50 peer-checked:dark:bg-red-400/50 border border-gray-200 dark:border-slate-500 rounded-lg peer-checked:border-red-400",
                  children: /* @__PURE__ */ jsxs("div", { className: "p-2", children: [
                    /* @__PURE__ */ jsx("img", { src: "/storage/brands/hansaton.png", alt: "", className: "w-24 h-24 object-contain" }),
                    /* @__PURE__ */ jsx("hr", { className: "my-4 border-gray-200 dark:border-slate-500" }),
                    /* @__PURE__ */ jsx("p", { className: "text-center", children: "هنزاتون" })
                  ] })
                }
              )
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-2/3 flex flex-col space-y-5 xl:space-y-0", children: [
          /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-col xl:flex-row space-y-5 xl:space-y-0", children: [
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/2 ml-5 h-fit", children: [
              /* @__PURE__ */ jsxs(
                SelectInput,
                {
                  id: "type",
                  name: "name",
                  value: data.type,
                  label: "نوع سفارش",
                  onChange: (e) => setData("type", e.target.value),
                  error: errors.type,
                  children: [
                    /* @__PURE__ */ jsx("option", { value: "", disabled: "disabled", children: "انتخاب کنید" }),
                    /* @__PURE__ */ jsx("option", { value: "CIC", children: "CIC (داخل گوشی با باتری 10)" }),
                    /* @__PURE__ */ jsx("option", { value: "ITC", children: "ITC (داخل گوشی با باتری 312)" }),
                    /* @__PURE__ */ jsx("option", { value: "BTE mold", children: "BTE با/بدون قالب" }),
                    /* @__PURE__ */ jsx("option", { value: "BTE tube", children: "BTE با اسلیم تیوب" }),
                    /* @__PURE__ */ jsx("option", { value: "RIC", children: "RIC" })
                  ]
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.type, className: "mt-2" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/2 h-fit", children: [
              /* @__PURE__ */ jsxs(
                SelectInput,
                {
                  id: "ear",
                  name: "ear",
                  value: data.ear,
                  label: "نوع تجویز",
                  onChange: (e) => setData("ear", e.target.value),
                  error: errors.ear,
                  children: [
                    /* @__PURE__ */ jsx("option", { value: "", disabled: "disabled", children: "انتخاب کنید" }),
                    /* @__PURE__ */ jsx("option", { value: "right", children: "تجویز تک گوشی گوش راست" }),
                    /* @__PURE__ */ jsx("option", { value: "left", children: "تجویز تک گوشی گوش چپ" }),
                    /* @__PURE__ */ jsx("option", { value: "both", children: "تجویز دو گوشی" })
                  ]
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.ear, className: "mt-2" })
            ] })
          ] }),
          Object.keys(products).length === 0 && /* @__PURE__ */ jsx("p", { className: "block text-lg !mt-5 text-gray-700 dark:text-slate-300", children: "با اطلاعات وارد شده، محصول قابل سفارشی برای گروه شما وجود ندارد!" }),
          /* @__PURE__ */ jsxs("div", { className: `!mt-5 transition-all ${!record.product_id && "ease-in-out duration-500"} ${Object.keys(products).length ? "max-h-full" : "max-h-0"} overflow-hidden`, children: [
            /* @__PURE__ */ jsx(ProductsSlider, { products, setProduct, product, setProductItems, productItems, productsItems, error: errors.product }),
            /* @__PURE__ */ jsx(InputError, { message: errors.product, className: "mt-2" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex justify-between mt-8", children: [
        /* @__PURE__ */ jsx(
          DangerButton,
          {
            className: "!px-4 !py-2",
            type: "button",
            onClick: prevStep,
            children: "مرحله قبل"
          }
        ),
        /* @__PURE__ */ jsx(
          PrimaryButton,
          {
            className: "!px-4 !py-2",
            disabled: processing,
            type: "submit",
            children: "مرحله بعد"
          }
        )
      ] })
    ] })
  ] });
}
const AidTypeStep$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: AidTypeStep
}, Symbol.toStringTag, { value: "Module" }));
const AidContext$1 = createContext();
function AudiogramStep() {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _A, _B, _C, _D, _E, _F, _G, _H, _I, _J, _K, _L, _M, _N;
  const { record, nextStep, prevStep } = useContext(StepContext);
  const { data, setData, post, processing, errors } = useForm({
    left: {
      "ac_250": ((_b = (_a = record.audiogram) == null ? void 0 : _a.left) == null ? void 0 : _b.ac_250) || "",
      "ac_500": ((_d = (_c = record.audiogram) == null ? void 0 : _c.left) == null ? void 0 : _d.ac_500) || "",
      "ac_1000": ((_f = (_e = record.audiogram) == null ? void 0 : _e.left) == null ? void 0 : _f.ac_1000) || "",
      "ac_2000": ((_h = (_g = record.audiogram) == null ? void 0 : _g.left) == null ? void 0 : _h.ac_2000) || "",
      "ac_4000": ((_j = (_i = record.audiogram) == null ? void 0 : _i.left) == null ? void 0 : _j.ac_4000) || "",
      "bc_250": ((_l = (_k = record.audiogram) == null ? void 0 : _k.left) == null ? void 0 : _l.bc_250) || "",
      "bc_500": ((_n = (_m = record.audiogram) == null ? void 0 : _m.left) == null ? void 0 : _n.bc_500) || "",
      "bc_1000": ((_p = (_o = record.audiogram) == null ? void 0 : _o.left) == null ? void 0 : _p.bc_1000) || "",
      "bc_2000": ((_r = (_q = record.audiogram) == null ? void 0 : _q.left) == null ? void 0 : _r.bc_2000) || "",
      "bc_4000": ((_t = (_s = record.audiogram) == null ? void 0 : _s.left) == null ? void 0 : _t.bc_4000) || ""
    },
    right: {
      "ac_250": ((_v = (_u = record.audiogram) == null ? void 0 : _u.right) == null ? void 0 : _v.ac_250) || "",
      "ac_500": ((_x = (_w = record.audiogram) == null ? void 0 : _w.right) == null ? void 0 : _x.ac_500) || "",
      "ac_1000": ((_z = (_y = record.audiogram) == null ? void 0 : _y.right) == null ? void 0 : _z.ac_1000) || "",
      "ac_2000": ((_B = (_A = record.audiogram) == null ? void 0 : _A.right) == null ? void 0 : _B.ac_2000) || "",
      "ac_4000": ((_D = (_C = record.audiogram) == null ? void 0 : _C.right) == null ? void 0 : _D.ac_4000) || "",
      "bc_250": ((_F = (_E = record.audiogram) == null ? void 0 : _E.right) == null ? void 0 : _F.bc_250) || "",
      "bc_500": ((_H = (_G = record.audiogram) == null ? void 0 : _G.right) == null ? void 0 : _H.bc_500) || "",
      "bc_1000": ((_J = (_I = record.audiogram) == null ? void 0 : _I.right) == null ? void 0 : _J.bc_1000) || "",
      "bc_2000": ((_L = (_K = record.audiogram) == null ? void 0 : _K.right) == null ? void 0 : _L.bc_2000) || "",
      "bc_4000": ((_N = (_M = record.audiogram) == null ? void 0 : _M.right) == null ? void 0 : _N.bc_4000) || ""
    },
    "audiogram_image": record.audiogram_image || "",
    "id_card_image": record.id_card_image || "",
    "prescription_image": record.prescription_image || "",
    "national_code_confirm_image": record.national_code_confirm_image || "",
    "creditor_image": record.creditor_image || ""
  });
  const submit = (e) => {
    e.preventDefault();
    post(route("records.store_audiogram", record.id), {
      preserveScroll: true,
      onSuccess: () => {
        nextStep();
      }
    });
  };
  const tests_list = [
    "250",
    "500",
    "1000",
    "2000",
    "4000"
  ];
  const render_ear = (ear) => /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsx("div", { className: "flex flex-col xl:flex-row xl:space-x-reverse xl:space-x-5 space-y-5 xl:space-y-0", children: /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-col-reverse xl:flex-row xl:space-x-reverse xl:space-x-10 space-y-reverse space-y-5 xl:space-y-0", children: [
    [...tests_list].reverse().map((item, index) => /* @__PURE__ */ jsxs("div", { className: "flex text-gray-800 dark:text-slate-200", children: [
      /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-col space-y-3", children: [
        /* @__PURE__ */ jsxs("label", { htmlFor: `ac_${item}_` + ear, className: "block text-sm cursor-pointer font-semibold bg-gray-200 dark:bg-slate-500 rounded-lg py-2 text-center", children: [
          item,
          "Hz"
        ] }),
        /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(
          TextInput,
          {
            className: "text-center",
            size: 2,
            id: `ac_${item}_` + ear,
            name: `${ear}.ac_${item}`,
            value: data[ear]["ac_" + item],
            type: "number",
            onChange: (e) => setData((prevData) => ({
              ...prevData,
              [ear]: {
                ...prevData[ear],
                ["ac_" + item]: e.target.value
              }
            })),
            error: errors[ear + ".ac_" + item]
          }
        ) }),
        /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(
          TextInput,
          {
            className: "text-center",
            size: 2,
            id: `bc_${item}_` + ear,
            name: `${ear}.bc_${item}`,
            value: data[ear]["bc_" + item],
            type: "number",
            onChange: (e) => setData((prevData) => ({
              ...prevData,
              [ear]: {
                ...prevData[ear],
                ["bc_" + item]: e.target.value
              }
            })),
            error: errors[ear + ".bc_" + item]
          }
        ) })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "flex xl:hidden", children: /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-col space-y-3 mr-5 text-gray-800 dark:text-slate-200", children: [
        /* @__PURE__ */ jsx("div", { className: "text-center text-xs font-semibold bg-gray-200 dark:bg-slate-900 rounded-lg py-2 px-2", children: "Frequency" }),
        /* @__PURE__ */ jsx("div", { className: "text-center font-semibold bg-gray-200 dark:bg-slate-900 rounded-lg py-[.65rem] px-2", children: "AC" }),
        /* @__PURE__ */ jsx("div", { className: "text-center font-semibold bg-gray-200 dark:bg-slate-900 rounded-lg py-[.65rem] px-2", children: "BC" })
      ] }) })
    ] }, index)),
    /* @__PURE__ */ jsxs("div", { className: "hidden xl:flex xl:flex-col space-y-3 w-1/12 text-gray-800 dark:text-slate-200", children: [
      /* @__PURE__ */ jsx("div", { className: "text-center text-xs font-semibold bg-gray-200 dark:bg-slate-900 rounded-lg py-2 px-2", children: "Frequency" }),
      /* @__PURE__ */ jsx("div", { className: "text-center font-semibold bg-gray-200 dark:bg-slate-900 rounded-lg py-[.65rem] px-2", children: "AC" }),
      /* @__PURE__ */ jsx("div", { className: "text-center font-semibold bg-gray-200 dark:bg-slate-900 rounded-lg py-[.65rem] px-2", children: "BC" })
    ] })
  ] }) }) });
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Head, { title: "سفارش - ادیوگرام" }),
    /* @__PURE__ */ jsxs("form", { className: "w-full", onSubmit: submit, children: [
      /* @__PURE__ */ jsxs(AidContext$1.Provider, { value: { data, setData, errors }, children: [
        (record.ear === "left" || record.ear === "both") && /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsxs("div", { className: "mb-8", children: [
            /* @__PURE__ */ jsx("div", { className: `inline-block ml-2 w-3 h-3 bg-blue-400 rounded-full` }),
            /* @__PURE__ */ jsx("span", { className: "text-lg text-gray-700 dark:text-slate-200", children: "ادیوگرام گوش چپ" }),
            /* @__PURE__ */ jsx("hr", { className: "mt-1 dark:border-slate-600" })
          ] }),
          render_ear("left")
        ] }),
        (record.ear === "right" || record.ear === "both") && /* @__PURE__ */ jsxs("div", { className: record.ear === "both" ? "mt-8" : "", children: [
          /* @__PURE__ */ jsxs("div", { className: "mb-8", children: [
            /* @__PURE__ */ jsx("div", { className: `inline-block ml-2 w-3 h-3 bg-red-600 dark:bg-red-400 rounded-full` }),
            /* @__PURE__ */ jsx("span", { className: "text-lg text-gray-700 dark:text-slate-200", children: "ادیوگرام گوش راست" }),
            /* @__PURE__ */ jsx("hr", { className: "mt-1 dark:border-slate-600" })
          ] }),
          render_ear("right")
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "mt-8", children: [
          /* @__PURE__ */ jsxs("div", { className: "mb-8", children: [
            /* @__PURE__ */ jsx("span", { className: "text-lg text-gray-700 dark:text-slate-200", children: "سایر مدارک" }),
            /* @__PURE__ */ jsx("hr", { className: "mt-1 dark:border-slate-600" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row gap-x-0 xl:gap-x-5 gap-y-5 xl:gap-y-0 mt-5", children: [
            /* @__PURE__ */ jsx("div", { className: "w-full xl:w-1/2", children: /* @__PURE__ */ jsx(
              FileInput,
              {
                name: "audiogram_image",
                fileName: data.audiogram_image,
                viewLink: record.audiogram_image && record.audiogram_image_url,
                label: "تصویر ادیوگرام",
                accept: ".jpg, .jpeg",
                setData: (e) => setData("audiogram_image", e.target.files[0]),
                error: errors.audiogram_image
              }
            ) }),
            /* @__PURE__ */ jsx("div", { className: "w-full xl:w-1/2", children: /* @__PURE__ */ jsx(
              FileInput,
              {
                name: "id_card_image",
                fileName: data.id_card_image,
                viewLink: record.id_card_image && record.id_card_image_url,
                label: "تصویر مدرک شناسایی (کارت ملی یا صفحه اول شناسنامه حاوی کد ملی)",
                accept: ".jpg, .jpeg",
                setData: (e) => setData("id_card_image", e.target.files[0]),
                error: errors.id_card_image
              }
            ) })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row gap-x-0 xl:gap-x-5 gap-y-5 xl:gap-y-0 mt-5", children: [
            /* @__PURE__ */ jsx("div", { className: "w-full xl:w-1/2", children: /* @__PURE__ */ jsx(
              FileInput,
              {
                name: "prescription_image",
                fileName: data.prescription_image,
                viewLink: record.prescription_image && record.prescription_image_url,
                label: "تصویر نسخه پزشک گوش و حلق و بینی",
                accept: ".jpg, .jpeg",
                setData: (e) => setData("prescription_image", e.target.files[0]),
                error: errors.prescription_image
              }
            ) }),
            /* @__PURE__ */ jsx("div", { className: "w-full xl:w-1/2", children: /* @__PURE__ */ jsx(
              FileInput,
              {
                name: "national_code_confirm",
                fileName: data.national_code_confirm_image,
                viewLink: record.national_code_confirm_image && record.national_code_confirm_image_url,
                label: "تصویر تعهد عدم اعلام کدملی تکراری با متن ارسالی کارشناسان فروش",
                accept: ".jpg, .jpeg",
                setData: (e) => setData("national_code_confirm_image", e.target.files[0]),
                error: errors.national_code_confirm_image
              }
            ) })
          ] }),
          !!record.user.creditor_image && /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row gap-x-0 xl:gap-x-5 gap-y-5 xl:gap-y-0 mt-5", children: [
            /* @__PURE__ */ jsx("div", { className: "w-full xl:w-2/4", children: /* @__PURE__ */ jsx(
              FileInput,
              {
                name: "creditor_image",
                fileName: data.creditor_image,
                viewLink: record.creditor_image && record.creditor_image_url,
                label: "نامه تاییدیه بستانکاری",
                accept: ".jpg, .jpeg",
                setData: (e) => setData("creditor_image", e.target.files[0]),
                error: errors.creditor_image
              }
            ) }),
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 flex flex-col gap-2 md:gap-8 justify-end", children: [
              /* @__PURE__ */ jsx("p", { className: "text-sm text-center md:text-right font-semibold text-gray-700 dark:text-slate-200", children: "میتوانید از نمونه نامه تاییدیه بستانکاری پیوست شده، استفاده نمایید." }),
              /* @__PURE__ */ jsx(
                PrimaryButton,
                {
                  link: true,
                  target: "_blank",
                  download: true,
                  href: "/storage/creditor-example.pdf",
                  children: "دانلود فایل نمونه"
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex text-sm font-semibold mt-5 text-gray-700 dark:text-slate-200", children: [
            /* @__PURE__ */ jsx("span", { className: "animate-pulse ml-1", children: "توجه: " }),
            "مسئولیت صحت مدارک با کارشناس بوده و در صورت عدم تطبیق، سفارش حذف خواهد شد!"
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex justify-between mt-8", children: [
        /* @__PURE__ */ jsx(
          DangerButton,
          {
            className: "!px-4 !py-2",
            type: "button",
            onClick: prevStep,
            children: "مرحله قبل"
          }
        ),
        /* @__PURE__ */ jsx(
          PrimaryButton,
          {
            className: "!px-4 !py-2",
            disabled: processing,
            type: "submit",
            children: "مرحله بعد"
          }
        )
      ] })
    ] })
  ] });
}
const AudiogramStep$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  AidContext: AidContext$1,
  default: AudiogramStep
}, Symbol.toStringTag, { value: "Module" }));
function ShippingStep() {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k;
  const { record, prevStep } = useContext(StepContext);
  const { data, setData, post, processing, errors } = useForm({
    expert_phone: ((_a = record.shipping) == null ? void 0 : _a.expert_phone) || "",
    type: ((_b = record.shipping) == null ? void 0 : _b.type) || "",
    etc_delivery: ((_c = record.shipping) == null ? void 0 : _c.etc_delivery) || "",
    has_health_insurance: ((_d = record.shipping) == null ? void 0 : _d.has_health_insurance) || false,
    phone: ((_e = record.shipping) == null ? void 0 : _e.phone) || "",
    audiologist_med_number: ((_f = record.shipping) == null ? void 0 : _f.audiologist_med_number) || "",
    otolaryngologist_med_number: ((_g = record.shipping) == null ? void 0 : _g.otolaryngologist_med_number) || "",
    supplementary_insurance: ((_h = record.shipping) == null ? void 0 : _h.supplementary_insurance) || "",
    description: ((_i = record.shipping) == null ? void 0 : _i.description) || "",
    mail_address: ((_j = record.shipping) == null ? void 0 : _j.mail_address) || ((_k = record.shipping) == null ? void 0 : _k.address.mail_address)
  });
  const submit = (e) => {
    e.preventDefault();
    post(route("records.store_shipping", record.id), {
      preserveScroll: true
      // onSuccess: () => {
      //     nextStep()
      // }
    });
  };
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Head, { title: "سفارش - ارسال محصول" }),
    /* @__PURE__ */ jsxs("form", { className: "w-full", onSubmit: submit, children: [
      /* @__PURE__ */ jsxs("div", { className: "text-gray-700 dark:text-slate-200", children: [
        /* @__PURE__ */ jsx("div", { className: "flex justify-between items-end", children: /* @__PURE__ */ jsx("h5", { children: "ارسال محصول" }) }),
        /* @__PURE__ */ jsx("hr", { className: "dark:border-slate-600" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-6 mb-5", children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3 ml-5", children: [
          /* @__PURE__ */ jsx(
            TextInput,
            {
              id: "expert_phone",
              name: "expert_phone",
              type: "number",
              value: data.expert_phone,
              label: "تلفن همراه شنوایی شناس",
              onChange: (e) => setData("expert_phone", e.target.value),
              error: errors.expert_phone
            }
          ),
          /* @__PURE__ */ jsxs("span", { className: "text-gray-700 dark:text-slate-300 text-xs", children: [
            /* @__PURE__ */ jsx(Icon, { className: "inline-block !w-4 !h-4 ml-1", viewBox: "0 0 24 24", type: "fill", children: /* @__PURE__ */ jsx("path", { d: "M15,8a1,1,0,0,1-1,1H6A1,1,0,0,1,6,7h8A1,1,0,0,1,15,8Zm-1,3H6a1,1,0,0,0,0,2h8a1,1,0,0,0,0-2Zm-4,4H6a1,1,0,0,0,0,2h4a1,1,0,0,0,0-2Zm13-3v8a3,3,0,0,1-3,3H4a3,3,0,0,1-3-3V4A3,3,0,0,1,4,1H16a3,3,0,0,1,3,3v7h3A1,1,0,0,1,23,12ZM17,4a1,1,0,0,0-1-1H4A1,1,0,0,0,3,4V20a1,1,0,0,0,1,1H17Zm4,9H19v8h1a1,1,0,0,0,1-1Z" }) }),
            "جهت ارسال صورتحساب"
          ] }),
          /* @__PURE__ */ jsx(InputError, { message: errors.expert_phone, className: "mt-2" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3 ml-5", children: [
          /* @__PURE__ */ jsxs(
            SelectInput,
            {
              id: "type",
              name: "type",
              value: data.type,
              label: "شیوه ارسال",
              onChange: (e) => setData("type", e.target.value),
              error: errors.type,
              children: [
                /* @__PURE__ */ jsx("option", { value: "", disabled: "disabled", children: "انتخاب کنید" }),
                /* @__PURE__ */ jsx("option", { value: "terminal", children: "ترمینالی" }),
                /* @__PURE__ */ jsx("option", { value: "air", children: "هوایی" }),
                /* @__PURE__ */ jsx("option", { value: "tipax", children: "تیپاکس" }),
                /* @__PURE__ */ jsx("option", { value: "post", children: "پست" }),
                /* @__PURE__ */ jsx("option", { value: "co-worker delivery", children: "تحویل به پیک همکار" }),
                /* @__PURE__ */ jsx("option", { value: "company delivery", children: "ارسال با پیک شرکت" }),
                /* @__PURE__ */ jsx("option", { value: "etc", children: "سایر" })
              ]
            }
          ),
          /* @__PURE__ */ jsx(InputError, { message: errors.type, className: "mt-2" })
        ] }),
        data.type === "etc" && /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3", children: [
          /* @__PURE__ */ jsx(
            TextInput,
            {
              id: "etc_delivery",
              etc_delivery: "etc_delivery",
              value: data.etc_delivery,
              label: "شیوه ارسال محصول",
              onChange: (e) => setData("etc_delivery", e.target.value),
              error: errors.etc_delivery
            }
          ),
          /* @__PURE__ */ jsx(InputError, { message: errors.etc_delivery, className: "mt-2" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mt-8 text-gray-700 dark:text-slate-200", children: [
        /* @__PURE__ */ jsx("div", { className: "flex justify-between items-end", children: /* @__PURE__ */ jsx("h5", { children: "آدرس جهت ارسال" }) }),
        /* @__PURE__ */ jsx("hr", { className: "dark:border-slate-600" })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "flex mt-8", children: /* @__PURE__ */ jsxs("div", { className: "w-full ml-5 text-gray-700 dark:text-slate-200", children: [
        /* @__PURE__ */ jsx("p", { children: "مرسولات شما به کدام آدرس ارسال شوند؟" }),
        /* @__PURE__ */ jsx(InputError, { message: errors.mail_address, className: "mt-2" }),
        /* @__PURE__ */ jsxs("div", { className: "mb-5 mt-2", children: [
          /* @__PURE__ */ jsxs("div", { className: "mb-5", children: [
            /* @__PURE__ */ jsx(
              RadioInput,
              {
                className: "hidden peer",
                id: "mail_address_work",
                name: "mail_address",
                checked: data.mail_address === "work",
                onChange: () => setData("mail_address", "work")
              }
            ),
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                className: "!block md:!inline-block p-4 rounded-lg bg-gray-100 dark:bg-slate-700 peer-checked:bg-sky-100 peer-checked:dark:bg-sky-900 border border-gray-200 dark:border-slate-500 peer-checked:border-sky-400",
                htmlFor: "mail_address_work",
                children: /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("h6", { className: "font-semibold border-b pb-2", children: "محل کار" }),
                  /* @__PURE__ */ jsxs("p", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-5 xl:mt-2", children: [
                    /* @__PURE__ */ jsxs("span", { className: "inline-block", children: [
                      "استان: ",
                      record.shipping.address.work_state,
                      " - شهر: ",
                      record.shipping.address.work_city
                    ] }),
                    /* @__PURE__ */ jsxs("span", { className: "inline-block xl:mr-5", children: [
                      "آدرس: ",
                      record.shipping.address.work_address
                    ] }),
                    /* @__PURE__ */ jsxs("span", { className: "inline-block xl:mr-5 xl:pr-5 xl:border-r border-gray-300 dark:border-slate-600", children: [
                      "کدپستی: ",
                      record.shipping.address.work_post_code
                    ] }),
                    record.shipping.address.work_phone && /* @__PURE__ */ jsxs(
                      "span",
                      {
                        className: "inline-block xl:mr-5 xl:pr-5 xl:border-r border-gray-300 dark:border-slate-600",
                        children: [
                          "تلفن: ",
                          record.shipping.address.work_phone
                        ]
                      }
                    )
                  ] })
                ] })
              }
            )
          ] }),
          record.shipping.address.second_work_address && /* @__PURE__ */ jsxs("div", { className: "mb-5", children: [
            /* @__PURE__ */ jsx(
              RadioInput,
              {
                className: "hidden peer",
                id: "second_mail_address_work",
                name: "mail_address",
                checked: data.mail_address === "second_work",
                onChange: () => setData("mail_address", "second_work")
              }
            ),
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                className: "!block md:!inline-block p-4 rounded-lg bg-gray-100 dark:bg-slate-700 peer-checked:bg-sky-100 peer-checked:dark:bg-sky-900 border border-gray-200 dark:border-slate-500 peer-checked:border-sky-400",
                htmlFor: "second_mail_address_work",
                children: /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("h6", { className: "font-semibold border-b pb-2", children: "محل کار دوم" }),
                  /* @__PURE__ */ jsxs("p", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-5 xl:mt-2", children: [
                    /* @__PURE__ */ jsxs("span", { className: "inline-block", children: [
                      "استان: ",
                      record.shipping.address.second_work_state,
                      " - شهر: ",
                      record.shipping.address.second_work_city
                    ] }),
                    /* @__PURE__ */ jsxs("span", { className: "inline-block xl:mr-5", children: [
                      "آدرس: ",
                      record.shipping.address.second_work_address
                    ] }),
                    /* @__PURE__ */ jsxs("span", { className: "inline-block xl:mr-5 xl:pr-5 xl:border-r border-gray-300 dark:border-slate-600", children: [
                      "کدپستی: ",
                      record.shipping.address.second_work_post_code
                    ] }),
                    record.shipping.address.second_work_phone && /* @__PURE__ */ jsxs(
                      "span",
                      {
                        className: "inline-block xl:mr-5 xl:pr-5 xl:border-r border-gray-300 dark:border-slate-600",
                        children: [
                          "تلفن: ",
                          record.shipping.address.second_work_phone
                        ]
                      }
                    )
                  ] })
                ] })
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(
              RadioInput,
              {
                className: "hidden peer",
                id: "mail_address_home",
                name: "mail_address",
                checked: data.mail_address === "home",
                onChange: () => setData("mail_address", "home")
              }
            ),
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                className: "!block md:!inline-block p-4 rounded-lg bg-gray-100 dark:bg-slate-700 peer-checked:bg-sky-100 peer-checked:dark:bg-sky-900 border border-gray-200 dark:border-slate-500 peer-checked:border-sky-400",
                htmlFor: "mail_address_home",
                children: /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("h6", { className: "font-semibold border-b pb-2", children: "محل سکونت" }),
                  /* @__PURE__ */ jsxs("p", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-5 xl:mt-2", children: [
                    /* @__PURE__ */ jsxs("span", { className: "inline-block", children: [
                      "استان: ",
                      record.shipping.address.home_state,
                      " - شهر: ",
                      record.shipping.address.home_city
                    ] }),
                    /* @__PURE__ */ jsxs("span", { className: "inline-block xl:mr-5", children: [
                      "آدرس: ",
                      record.shipping.address.home_address
                    ] }),
                    /* @__PURE__ */ jsxs("span", { className: "inline-block xl:mr-5 xl:pr-5 xl:border-r border-gray-300 dark:border-slate-600", children: [
                      "کدپستی: ",
                      record.shipping.address.home_post_code
                    ] }),
                    record.shipping.address.home_phone && /* @__PURE__ */ jsxs(
                      "span",
                      {
                        className: "inline-block xl:mr-5 xl:pr-5 xl:border-r border-gray-300 dark:border-slate-600",
                        children: [
                          "تلفن: ",
                          record.shipping.address.home_phone
                        ]
                      }
                    )
                  ] })
                ] })
              }
            )
          ] })
        ] })
      ] }) }),
      /* @__PURE__ */ jsxs("div", { className: "mt-5 text-gray-700 dark:text-slate-200", children: [
        /* @__PURE__ */ jsx("h5", { children: "بیمه سلامت" }),
        /* @__PURE__ */ jsx("hr", { className: "dark:border-slate-600" })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "flex mt-5 mb-5", children: /* @__PURE__ */ jsxs("div", { className: "w-full", children: [
        /* @__PURE__ */ jsx(
          CheckboxInput,
          {
            id: "has_health_insurance",
            name: "has_health_insurance",
            checked: data.has_health_insurance,
            onChange: (e) => setData("has_health_insurance", e.target.checked)
          }
        ),
        /* @__PURE__ */ jsx(
          InputLabel,
          {
            htmlFor: "has_health_insurance",
            value: "تمایل به دریافت برگه بیمه سلامت",
            className: "mr-2"
          }
        )
      ] }) }),
      data.has_health_insurance && /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-6 mb-5", children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 ml-5", children: [
          /* @__PURE__ */ jsx(
            TextInput,
            {
              id: "phone",
              name: "phone",
              type: "number",
              value: data.phone,
              label: "تلفن همراه کاربر",
              onChange: (e) => setData("phone", e.target.value),
              error: errors.phone
            }
          ),
          /* @__PURE__ */ jsx(InputError, { message: errors.phone, className: "mt-2" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 ml-5", children: [
          /* @__PURE__ */ jsx(
            TextInput,
            {
              id: "audiologist_med_number",
              name: "audiologist_med_number",
              type: "number",
              value: data.audiologist_med_number,
              label: "شماره نظام پزشکی شنوایی شناس",
              onChange: (e) => setData("audiologist_med_number", e.target.value),
              error: errors.audiologist_med_number
            }
          ),
          /* @__PURE__ */ jsx(InputError, { message: errors.audiologist_med_number, className: "mt-2" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4 ml-5", children: [
          /* @__PURE__ */ jsx(
            TextInput,
            {
              id: "otolaryngologist_med_number",
              name: "otolaryngologist_med_number",
              type: "number",
              value: data.otolaryngologist_med_number,
              label: "شماره نظام پزشکی پزشک گوش و حلق و بینی",
              onChange: (e) => setData("otolaryngologist_med_number", e.target.value),
              error: errors.otolaryngologist_med_number
            }
          ),
          /* @__PURE__ */ jsx(InputError, { message: errors.otolaryngologist_med_number, className: "mt-2" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/4", children: [
          /* @__PURE__ */ jsx(
            TextInput,
            {
              id: "supplementary_insurance",
              name: "supplementary_insurance",
              value: data.supplementary_insurance,
              label: "نوع بیمه تکمیلی",
              onChange: (e) => setData("supplementary_insurance", e.target.value),
              error: errors.supplementary_insurance
            }
          ),
          /* @__PURE__ */ jsx(InputError, { message: errors.supplementary_insurance, className: "mt-2" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex mt-16", children: [
        /* @__PURE__ */ jsx(
          TextAreaInput,
          {
            id: "description",
            name: "description",
            value: data.description,
            rows: "3",
            label: "توضیحات",
            onChange: (e) => setData("description", e.target.value),
            error: errors.description
          }
        ),
        /* @__PURE__ */ jsx(InputError, { message: errors.description, className: "mt-2" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex justify-between mt-8", children: [
        /* @__PURE__ */ jsx(
          DangerButton,
          {
            className: "!px-4 !py-2",
            type: "button",
            onClick: prevStep,
            children: "مرحله قبل"
          }
        ),
        /* @__PURE__ */ jsx(
          PrimaryButton,
          {
            className: "!px-4 !py-2",
            disabled: processing,
            type: "submit",
            children: "ذخیره و بستن سفارش"
          }
        )
      ] })
    ] })
  ] });
}
const ShippingStep$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: ShippingStep
}, Symbol.toStringTag, { value: "Module" }));
const StepContext = createContext();
function Create({ record, setting, setting_time_orders }) {
  const [step, setStep] = useState(parseInt(new URLSearchParams(window.location.search).get("step")) || 1);
  const passedSteps = (record == null ? void 0 : record.status) ? record.status === "completed" ? 6 : record == null ? void 0 : record.status : 1;
  const prevStep = () => {
    setStep((prev) => prev - 1);
  };
  useEffect(() => {
    const searchParams = new URLSearchParams(window.location.search);
    searchParams.set("step", step);
    const newUrl = `${window.location.pathname}?${searchParams.toString()}`;
    window.history.replaceState(null, "", newUrl);
  }, [step]);
  const nextStep = () => {
    setStep((prev) => prev + 1);
  };
  const showStep = () => {
    switch (step) {
      case 1:
        return /* @__PURE__ */ jsx(PatientStep, {});
      case 2:
        return /* @__PURE__ */ jsx(AidTypeStep, {});
      case 3:
        return /* @__PURE__ */ jsx(AidStep, {});
      case 4:
        return /* @__PURE__ */ jsx(AudiogramStep, {});
      case 5:
        return /* @__PURE__ */ jsx(ShippingStep, {});
    }
  };
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      header: /* @__PURE__ */ jsx(Fragment, { children: record ? "ویرایش سفارش" : "ایجاد سفارش" }),
      breadcrumbs: {
        "سفارشات سمعک": route("records.index"),
        [record ? "ویرایش سفارش" : "ایجاد سفارش"]: "#"
      },
      headerExtra: setting && /* @__PURE__ */ jsxs("div", { className: "flex flex-col text-sm text-gray-700 dark:text-slate-300", children: [
        /* @__PURE__ */ jsxs("span", { className: "mb-3", children: [
          "ساعت سفارش گذاری:",
          /* @__PURE__ */ jsx("span", { className: "mx-1 font-semibold underline", children: setting.start_time_readable }),
          "الی",
          /* @__PURE__ */ jsx("span", { className: "mr-1 font-semibold underline", children: setting.end_time_readable })
        ] }),
        /* @__PURE__ */ jsxs("span", { children: [
          "تعداد سفارشات ثبت شده:",
          /* @__PURE__ */ jsx("span", { className: "mx-1 font-semibold underline", children: setting_time_orders }),
          "از",
          /* @__PURE__ */ jsx("span", { className: "mr-1 font-semibold underline", children: setting.max_record_order })
        ] })
      ] }),
      children: [
        /* @__PURE__ */ jsx(Steps, { step, passedSteps }),
        /* @__PURE__ */ jsx("div", { className: "flex flex-col sm:justify-center items-center mt-12", children: /* @__PURE__ */ jsx("div", { className: "w-full px-6 py-4 bg-white dark:bg-slate-800 border border-white dark:border-slate-600 sm:rounded-lg", children: /* @__PURE__ */ jsx(StepContext.Provider, { value: { record, prevStep, nextStep }, children: showStep() }) }) })
      ]
    }
  );
}
const Create$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  StepContext,
  default: Create
}, Symbol.toStringTag, { value: "Module" }));
const AidContext = createContext();
function AidStep() {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _A, _B, _C, _D, _E, _F, _G, _H, _I, _J, _K, _L, _M, _N, _O, _P, _Q, _R, _S, _T, _U, _V, _W, _X, _Y, _Z;
  const { record, nextStep, prevStep } = useContext(StepContext);
  const { data, setData, post, processing, errors } = useForm({
    left: {
      hearing_aid_size: ((_b = (_a = record.aid) == null ? void 0 : _a.left) == null ? void 0 : _b.hearing_aid_size) || "",
      vent_size: ((_d = (_c = record.aid) == null ? void 0 : _c.left) == null ? void 0 : _d.vent_size) || "",
      wax_guard: ((_f = (_e = record.aid) == null ? void 0 : _e.left) == null ? void 0 : _f.wax_guard) || "",
      receiver: ((_h = (_g = record.aid) == null ? void 0 : _g.left) == null ? void 0 : _h.receiver) || "",
      mold_material: ((_j = (_i = record.aid) == null ? void 0 : _i.left) == null ? void 0 : _j.mold_material) || "hard",
      mold_size: ((_l = (_k = record.aid) == null ? void 0 : _k.left) == null ? void 0 : _l.mold_size) || "",
      has_vent: ((_n = (_m = record.aid) == null ? void 0 : _m.left) == null ? void 0 : _n.has_vent) || false,
      tube_size: ((_p = (_o = record.aid) == null ? void 0 : _o.left) == null ? void 0 : _p.tube_size) || "",
      dome_type: ((_r = (_q = record.aid) == null ? void 0 : _q.left) == null ? void 0 : _r.dome_type) || "",
      dome_size: ((_t = (_s = record.aid) == null ? void 0 : _s.left) == null ? void 0 : _t.dome_size) || "",
      external_receiver_size: ((_v = (_u = record.aid) == null ? void 0 : _u.left) == null ? void 0 : _v.external_receiver_size) || "",
      shell_type: ((_x = (_w = record.aid) == null ? void 0 : _w.left) == null ? void 0 : _x.shell_type) || "",
      description: ((_z = (_y = record.aid) == null ? void 0 : _y.left) == null ? void 0 : _z.description) || ""
    },
    right: {
      hearing_aid_size: ((_B = (_A = record.aid) == null ? void 0 : _A.right) == null ? void 0 : _B.hearing_aid_size) || "",
      vent_size: ((_D = (_C = record.aid) == null ? void 0 : _C.right) == null ? void 0 : _D.vent_size) || "",
      wax_guard: ((_F = (_E = record.aid) == null ? void 0 : _E.right) == null ? void 0 : _F.wax_guard) || "",
      receiver: ((_H = (_G = record.aid) == null ? void 0 : _G.right) == null ? void 0 : _H.receiver) || "",
      mold_material: ((_J = (_I = record.aid) == null ? void 0 : _I.right) == null ? void 0 : _J.mold_material) || "hard",
      mold_size: ((_L = (_K = record.aid) == null ? void 0 : _K.right) == null ? void 0 : _L.mold_size) || "",
      has_vent: ((_N = (_M = record.aid) == null ? void 0 : _M.right) == null ? void 0 : _N.has_vent) || false,
      tube_size: ((_P = (_O = record.aid) == null ? void 0 : _O.right) == null ? void 0 : _P.tube_size) || "",
      dome_type: ((_R = (_Q = record.aid) == null ? void 0 : _Q.right) == null ? void 0 : _R.dome_type) || "",
      dome_size: ((_T = (_S = record.aid) == null ? void 0 : _S.right) == null ? void 0 : _T.dome_size) || "",
      external_receiver_size: ((_V = (_U = record.aid) == null ? void 0 : _U.right) == null ? void 0 : _V.external_receiver_size) || "",
      shell_type: ((_X = (_W = record.aid) == null ? void 0 : _W.right) == null ? void 0 : _X.shell_type) || "",
      description: ((_Z = (_Y = record.aid) == null ? void 0 : _Y.right) == null ? void 0 : _Z.description) || ""
    }
  });
  const submit = (e) => {
    e.preventDefault();
    post(route("records.store_aid", record.id), {
      preserveScroll: true,
      onSuccess: () => {
        nextStep();
      }
    });
  };
  const render_ear = (ear) => /* @__PURE__ */ jsxs(Fragment, { children: [
    (record.type === "CIC" || record.type === "ITC") && /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-3", children: [
      /* @__PURE__ */ jsx("div", { className: "w-full xl:w-1/3 ml-5", children: /* @__PURE__ */ jsx(AidSize, { ear, is_cic: record.type === "CIC" }) }),
      /* @__PURE__ */ jsx("div", { className: "w-full xl:w-1/3 ml-5", children: /* @__PURE__ */ jsx(VentSize, { ear }) }),
      /* @__PURE__ */ jsx("div", { className: "w-full xl:w-1/3", children: /* @__PURE__ */ jsx(ReceiverType, { ear, type: record.type }) })
    ] }) }),
    record.type === "BTE mold" && /* @__PURE__ */ jsx(Fragment, { children: record.has_mold === 1 && /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-6", children: [
      /* @__PURE__ */ jsx("div", { className: `${data[ear].has_vent && data[ear].mold_material !== "soft" ? "w-full xl:w-3/12" : "w-full xl:w-3/12"} ml-5 flex items-center`, children: /* @__PURE__ */ jsx(MoldMaterial, { ear }) }),
      data[ear].mold_material !== "soft" && /* @__PURE__ */ jsx("div", { className: `${data[ear].has_vent && data[ear].mold_material !== "soft" ? "w-full xl:w-2/12" : "w-full xl:w-3/12"} ml-5 flex items-center`, children: /* @__PURE__ */ jsx(HasVent, { ear }) }),
      /* @__PURE__ */ jsx("div", { className: `${data[ear].has_vent && data[ear].mold_material !== "soft" ? "w-full xl:w-4/12 ml-5" : "w-full xl:w-6/12"}`, children: /* @__PURE__ */ jsx(MoldSize, { ear }) }),
      data[ear].has_vent && data[ear].mold_material !== "soft" && /* @__PURE__ */ jsx("div", { className: "w-full xl:w-3/12", children: /* @__PURE__ */ jsx(VentSize, { ear }) })
    ] }) }),
    record.type === "BTE tube" && /* @__PURE__ */ jsx(Fragment, { children: record.has_mold === 1 ? /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-6", children: [
      /* @__PURE__ */ jsx("div", { className: "w-full xl:w-1/3 flex items-center", children: /* @__PURE__ */ jsx(HasVent, { ear }) }),
      /* @__PURE__ */ jsx("div", { className: `${data[ear].has_vent ? "w-full xl:w-1/3 ml-5" : "w-full xl:w-2/3"}`, children: /* @__PURE__ */ jsx(TubeSize, { ear }) }),
      data[ear].has_vent && /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsx("div", { className: "w-full xl:w-1/2", children: /* @__PURE__ */ jsx(VentSize, { ear }) }) })
    ] }) : /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-6", children: [
      /* @__PURE__ */ jsx("div", { className: "w-full xl:w-1/3 ml-5", children: /* @__PURE__ */ jsx(TubeSize, { ear }) }),
      /* @__PURE__ */ jsx("div", { className: "w-full xl:w-1/3 ml-5", children: /* @__PURE__ */ jsx(DomeType, { ear }) }),
      /* @__PURE__ */ jsx("div", { className: "w-full xl:w-1/3", children: /* @__PURE__ */ jsx(DomeSize, { ear }) })
    ] }) }),
    record.type === "RIC" && /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsx("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-6", children: record.has_mold === 1 ? /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx("div", { className: "w-full xl:-1/4 ml-5", children: /* @__PURE__ */ jsx(ReceiverType, { ear, type: "RIC - mold" }) }),
      /* @__PURE__ */ jsx("div", { className: "w-full xl:w-1/4 ml-5", children: /* @__PURE__ */ jsx(ShellType, { ear, hasSlimtip: data[ear].receiver !== "ultra power" }) }),
      /* @__PURE__ */ jsx("div", { className: "w-full xl:w-1/4 ml-5", children: /* @__PURE__ */ jsx(ExternalReceiverSize, { ear }) }),
      /* @__PURE__ */ jsx("div", { className: "w-full xl:w-1/4", children: /* @__PURE__ */ jsx(VentSize, { required: false, ear }) })
    ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx("div", { className: "w-full xl:w-1/4 ml-5", children: /* @__PURE__ */ jsx(ReceiverType, { ear, type: "RIC - no mold" }) }),
      /* @__PURE__ */ jsx("div", { className: "w-full xl:w-1/4 ml-5", children: /* @__PURE__ */ jsx(ExternalReceiverSize, { ear }) }),
      /* @__PURE__ */ jsx("div", { className: "w-full xl:w-1/4 ml-5", children: /* @__PURE__ */ jsx(DomeType, { ear }) }),
      /* @__PURE__ */ jsx("div", { className: "w-full xl:w-1/4", children: /* @__PURE__ */ jsx(DomeSize, { ear }) })
    ] }) }) }),
    /* @__PURE__ */ jsx("div", { className: "w-full mt-5", children: /* @__PURE__ */ jsx(Description, { ear }) })
  ] });
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Head, { title: "سفارش - اطلاعات سمعک" }),
    /* @__PURE__ */ jsxs("form", { className: "w-full", onSubmit: submit, children: [
      /* @__PURE__ */ jsxs(AidContext.Provider, { value: { data, setData, errors }, children: [
        (record.ear === "left" || record.ear === "both") && /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsxs("div", { className: "mb-8", children: [
            /* @__PURE__ */ jsx("div", { className: "inline-block ml-2 w-3 h-3 bg-blue-400 rounded-full" }),
            /* @__PURE__ */ jsx("span", { className: "text-lg text-gray-700 dark:text-slate-200", children: "گوش چپ" }),
            /* @__PURE__ */ jsx("hr", { className: "mt-1 dark:border-slate-600" })
          ] }),
          render_ear("left")
        ] }),
        (record.ear === "right" || record.ear === "both") && /* @__PURE__ */ jsxs("div", { className: record.ear === "both" ? "mt-8" : "", children: [
          /* @__PURE__ */ jsxs("div", { className: "mb-8", children: [
            /* @__PURE__ */ jsx("div", { className: "inline-block ml-2 w-3 h-3 bg-red-600 dark:bg-red-400 rounded-full" }),
            /* @__PURE__ */ jsx("span", { className: "text-lg text-gray-700 dark:text-slate-200", children: "گوش راست" }),
            /* @__PURE__ */ jsx("hr", { className: "mt-1 dark:border-slate-600" })
          ] }),
          render_ear("right")
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex justify-between mt-8", children: [
        /* @__PURE__ */ jsx(
          DangerButton,
          {
            className: "!px-4 !py-2",
            type: "button",
            onClick: prevStep,
            children: "مرحله قبل"
          }
        ),
        /* @__PURE__ */ jsx(
          PrimaryButton,
          {
            className: "!px-4 !py-2",
            disabled: processing,
            type: "submit",
            children: "مرحله بعد"
          }
        )
      ] })
    ] })
  ] });
}
const AidStep$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  AidContext,
  default: AidStep
}, Symbol.toStringTag, { value: "Module" }));
const AidSize = ({ ear, is_cic = false }) => {
  const { data, setData, errors } = useContext(AidContext);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs(
      SelectInput,
      {
        id: `hearing_aid_size_` + ear,
        name: `${ear}.hearing_aid_size`,
        value: data[ear].hearing_aid_size,
        label: "اندازه سمعک",
        onChange: (e) => setData((prevData) => ({
          ...prevData,
          [ear]: {
            ...prevData[ear],
            hearing_aid_size: e.target.value
          }
        })),
        error: errors["hearing_aid_size." + ear],
        children: [
          /* @__PURE__ */ jsx("option", { value: "", disabled: "disabled", children: "انتخاب کنید" }),
          is_cic && /* @__PURE__ */ jsx("option", { value: "CIC", children: "CIC" }),
          !is_cic && /* @__PURE__ */ jsx("option", { value: "Full shell", children: "Full shell" }),
          /* @__PURE__ */ jsx("option", { value: "Canal", children: "Canal" })
        ]
      }
    ),
    /* @__PURE__ */ jsx(InputError, { message: errors[ear + ".hearing_aid_size"], className: "mt-2" })
  ] });
};
const VentSize = ({ ear, required }) => {
  const { data, setData, errors } = useContext(AidContext);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs(
      SelectInput,
      {
        id: `vent_size_` + ear,
        name: `${ear}.vent_size`,
        value: data[ear].vent_size,
        label: "اندازه ونت",
        onChange: (e) => setData((prevData) => ({
          ...prevData,
          [ear]: {
            ...prevData[ear],
            vent_size: e.target.value
          }
        })),
        error: errors.vent_size,
        children: [
          /* @__PURE__ */ jsx("option", { value: "", disabled: "disabled", children: "انتخاب کنید" }),
          /* @__PURE__ */ jsx("option", { value: "2-3 mm", children: "2-3 mm" }),
          /* @__PURE__ */ jsx("option", { value: "1.5 mm", children: "1.5 mm" }),
          /* @__PURE__ */ jsx("option", { value: "1 mm", children: "1 mm" }),
          /* @__PURE__ */ jsx("option", { value: "groove", children: "شیاری" }),
          /* @__PURE__ */ jsx("option", { value: "none", children: "هیچکدام" })
        ]
      }
    ),
    /* @__PURE__ */ jsx(InputError, { message: errors[ear + ".vent_size"], className: "mt-2" })
  ] });
};
const WaxGuard = ({ ear }) => {
  const { data, setData, errors } = useContext(AidContext);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs(
      SelectInput,
      {
        id: `wax_guard_` + ear,
        name: `${ear}.wax_guard`,
        value: data[ear].wax_guard,
        label: "مدل وکسگارد",
        onChange: (e) => setData((prevData) => ({
          ...prevData,
          [ear]: {
            ...prevData[ear],
            wax_guard: e.target.value
          }
        })),
        error: errors.wax_guard,
        children: [
          /* @__PURE__ */ jsx("option", { value: "", disabled: "disabled", children: "انتخاب کنید" }),
          /* @__PURE__ */ jsx("option", { value: "normal", children: "معمولی" }),
          /* @__PURE__ */ jsx("option", { value: "rotating", children: "چرخشی" })
        ]
      }
    ),
    /* @__PURE__ */ jsx(InputError, { message: errors[ear + ".wax_guard"], className: "mt-2" })
  ] });
};
const ReceiverType = ({ type = "CIC", ear }) => {
  const { data, setData, errors } = useContext(AidContext);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs(
      SelectInput,
      {
        id: `receiver_` + ear,
        name: `${ear}.receiver`,
        value: data[ear].receiver,
        label: "نوع رسیور",
        onChange: (e) => setData((prevData) => ({
          ...prevData,
          [ear]: {
            ...prevData[ear],
            receiver: e.target.value
          }
        })),
        error: errors.receiver,
        children: [
          /* @__PURE__ */ jsx("option", { value: "", disabled: "disabled", children: "انتخاب کنید" }),
          type === "CIC" && /* @__PURE__ */ jsxs(Fragment, { children: [
            /* @__PURE__ */ jsx("option", { value: "standard", children: "standard" }),
            /* @__PURE__ */ jsx("option", { value: "power", children: "power" }),
            /* @__PURE__ */ jsx("option", { value: "super power", children: "super power" })
          ] }),
          type === "ITC" && /* @__PURE__ */ jsxs(Fragment, { children: [
            /* @__PURE__ */ jsx("option", { value: "standard", children: "standard" }),
            /* @__PURE__ */ jsx("option", { value: "power", children: "power" }),
            /* @__PURE__ */ jsx("option", { value: "super power", children: "super power" }),
            /* @__PURE__ */ jsx("option", { value: "ultra power", children: "ultra power" })
          ] }),
          type === "RIC - mold" && /* @__PURE__ */ jsxs(Fragment, { children: [
            /* @__PURE__ */ jsx("option", { value: "moderate", children: "moderate" }),
            /* @__PURE__ */ jsx("option", { value: "power", children: "power" }),
            /* @__PURE__ */ jsx("option", { value: "ultra power", children: "ultra power" })
          ] }),
          type === "RIC - no mold" && /* @__PURE__ */ jsxs(Fragment, { children: [
            /* @__PURE__ */ jsx("option", { value: "moderate", children: "moderate" }),
            /* @__PURE__ */ jsx("option", { value: "power", children: "power" })
          ] })
        ]
      }
    ),
    /* @__PURE__ */ jsx(InputError, { message: errors[ear + ".receiver"], className: "mt-2" })
  ] });
};
const HasMold = ({ ear }) => {
  const { data, setData } = useContext(AidContext);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(
      CheckboxInput,
      {
        id: `has_mold_` + ear,
        name: `${ear}.has_mold`,
        value: data[ear].has_mold,
        onChange: (e) => setData((prevData) => ({
          ...prevData,
          [ear]: {
            ...prevData[ear],
            has_mold: e.target.checked
          }
        }))
      }
    ),
    /* @__PURE__ */ jsx(
      InputLabel,
      {
        htmlFor: `has_mold_` + ear,
        value: "قالب ارسال می‌کنم",
        className: "mr-2"
      }
    )
  ] });
};
const MoldMaterial = ({ ear }) => {
  const { data, setData, errors } = useContext(AidContext);
  return /* @__PURE__ */ jsxs("div", { children: [
    /* @__PURE__ */ jsx("p", { className: "inline-block font-medium text-sm text-gray-700 dark:text-slate-200", children: "جنس قالب:" }),
    /* @__PURE__ */ jsx(InputError, { message: errors[ear + ".mail_address"], className: "mt-2" }),
    /* @__PURE__ */ jsxs("div", { className: "inline-block mr-4", children: [
      /* @__PURE__ */ jsxs("div", { className: "inline-block ml-8 mt-2", children: [
        /* @__PURE__ */ jsx(
          RadioInput,
          {
            id: `mold_material_hard_` + ear,
            name: `${ear}.mold_material`,
            checked: data[ear].mold_material === "hard",
            onChange: () => setData((prevData) => ({
              ...prevData,
              [ear]: {
                ...prevData[ear],
                mold_material: "hard"
              }
            }))
          }
        ),
        /* @__PURE__ */ jsx(
          InputLabel,
          {
            htmlFor: `mold_material_hard_` + ear,
            value: "سخت",
            className: "mr-2"
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "inline-block ml-8 mt-2", children: [
        /* @__PURE__ */ jsx(
          RadioInput,
          {
            id: `mold_material_soft_` + ear,
            name: `${ear}.mold_material`,
            checked: data[ear].mold_material === "soft",
            onChange: () => setData((prevData) => ({
              ...prevData,
              [ear]: {
                ...prevData[ear],
                mold_material: "soft"
              }
            }))
          }
        ),
        /* @__PURE__ */ jsx(
          InputLabel,
          {
            htmlFor: `mold_material_soft_` + ear,
            value: "نرم",
            className: "mr-2"
          }
        )
      ] })
    ] })
  ] });
};
const MoldSize = ({ ear }) => {
  const { data, setData, errors } = useContext(AidContext);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs(
      SelectInput,
      {
        id: `mold_size_` + ear,
        name: `${ear}.mold_size`,
        value: data[ear].mold_size,
        label: "اندازه قالب",
        onChange: (e) => setData((prevData) => ({
          ...prevData,
          [ear]: {
            ...prevData[ear],
            mold_size: e.target.value
          }
        })),
        error: errors.mold_size,
        children: [
          /* @__PURE__ */ jsx("option", { value: "", disabled: "disabled", children: "انتخاب کنید" }),
          /* @__PURE__ */ jsx("option", { value: "Canal", children: "Canal" }),
          /* @__PURE__ */ jsx("option", { value: "Half shell", children: "Half shell" }),
          /* @__PURE__ */ jsx("option", { value: "Full shell", children: "Full shell" }),
          /* @__PURE__ */ jsx("option", { value: "Skeleton shell", children: "Skeleton shell" })
        ]
      }
    ),
    /* @__PURE__ */ jsx(InputError, { message: errors[ear + ".mold_size"], className: "mt-2" })
  ] });
};
const HasVent = ({ ear }) => {
  const { data, setData } = useContext(AidContext);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(
      CheckboxInput,
      {
        id: `has_vent_` + ear,
        name: `${ear}.has_vent`,
        checked: data[ear].has_vent,
        onChange: (e) => setData((prevData) => ({
          ...prevData,
          [ear]: {
            ...prevData[ear],
            has_vent: e.target.checked
          }
        }))
      }
    ),
    /* @__PURE__ */ jsx(
      InputLabel,
      {
        htmlFor: `has_vent_` + ear,
        value: "دارای ونت",
        className: "mr-2"
      }
    )
  ] });
};
const TubeSize = ({ ear }) => {
  const { data, setData, errors } = useContext(AidContext);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs(
      SelectInput,
      {
        id: `tube_size_` + ear,
        name: `${ear}.tube_size`,
        value: data[ear].tube_size,
        label: "اندازه اسلیم تیوب",
        onChange: (e) => setData((prevData) => ({
          ...prevData,
          [ear]: {
            ...prevData[ear],
            tube_size: e.target.value
          }
        })),
        error: errors.tube_size,
        children: [
          /* @__PURE__ */ jsx("option", { value: "", disabled: "disabled", children: "انتخاب کنید" }),
          /* @__PURE__ */ jsx("option", { value: "0", children: "سایز 0" }),
          /* @__PURE__ */ jsx("option", { value: "1", children: "سایز 1" }),
          /* @__PURE__ */ jsx("option", { value: "2", children: "سایز 2" }),
          /* @__PURE__ */ jsx("option", { value: "3", children: "سایز 3" })
        ]
      }
    ),
    /* @__PURE__ */ jsx(InputError, { message: errors[ear + ".tube_size"], className: "mt-2" })
  ] });
};
const DomeType = ({ ear }) => {
  const { data, setData, errors } = useContext(AidContext);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs(
      SelectInput,
      {
        id: `dome_type_` + ear,
        name: `${ear}.dome_type`,
        value: data[ear].dome_type,
        label: "نوع Dome",
        onChange: (e) => setData((prevData) => ({
          ...prevData,
          [ear]: {
            ...prevData[ear],
            dome_type: e.target.value
          }
        })),
        error: errors.dome_type,
        children: [
          /* @__PURE__ */ jsx("option", { value: "", disabled: "disabled", children: "انتخاب کنید" }),
          /* @__PURE__ */ jsx("option", { value: "open", children: "open" }),
          /* @__PURE__ */ jsx("option", { value: "closed", children: "closed" }),
          /* @__PURE__ */ jsx("option", { value: "vented", children: "vented" }),
          /* @__PURE__ */ jsx("option", { value: "power", children: "power" })
        ]
      }
    ),
    /* @__PURE__ */ jsx(InputError, { message: errors[ear + ".dome_type"], className: "mt-2" })
  ] });
};
const DomeSize = ({ ear }) => {
  const { data, setData, errors } = useContext(AidContext);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs(
      SelectInput,
      {
        id: `dome_size_` + ear,
        name: `${ear}.dome_size`,
        value: data[ear].dome_size,
        label: "اندازه Dome",
        onChange: (e) => setData((prevData) => ({
          ...prevData,
          [ear]: {
            ...prevData[ear],
            dome_size: e.target.value
          }
        })),
        error: errors.dome_size,
        children: [
          /* @__PURE__ */ jsx("option", { value: "", disabled: "disabled", children: "انتخاب کنید" }),
          /* @__PURE__ */ jsx("option", { value: "large", children: "بزرگ" }),
          /* @__PURE__ */ jsx("option", { value: "medium", children: "متوسط" }),
          /* @__PURE__ */ jsx("option", { value: "small", children: "کوچک" })
        ]
      }
    ),
    /* @__PURE__ */ jsx(InputError, { message: errors[ear + ".dome_size"], className: "mt-2" })
  ] });
};
const ExternalReceiverSize = ({ ear }) => {
  const { data, setData, errors } = useContext(AidContext);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs(
      SelectInput,
      {
        id: `external_receiver_size_` + ear,
        name: `${ear}.external_receiver_size`,
        value: data[ear].external_receiver_size,
        label: "اندازه رسیور خارجی",
        onChange: (e) => setData((prevData) => ({
          ...prevData,
          [ear]: {
            ...prevData[ear],
            external_receiver_size: e.target.value
          }
        })),
        error: errors.external_receiver_size,
        children: [
          /* @__PURE__ */ jsx("option", { value: "", disabled: "disabled", children: "انتخاب کنید" }),
          /* @__PURE__ */ jsx("option", { value: "0", children: "سایز 0" }),
          /* @__PURE__ */ jsx("option", { value: "1", children: "سایز 1" }),
          /* @__PURE__ */ jsx("option", { value: "2", children: "سایز 2" }),
          /* @__PURE__ */ jsx("option", { value: "3", children: "سایز 3" })
        ]
      }
    ),
    /* @__PURE__ */ jsx(InputError, { message: errors[ear + ".external_receiver_size"], className: "mt-2" })
  ] });
};
const ShellType = ({ ear, hasSlimtip = true }) => {
  const { data, setData, errors } = useContext(AidContext);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs(
      SelectInput,
      {
        id: `shell_type_` + ear,
        name: `${ear}.shell_type`,
        value: data[ear].shell_type,
        label: "نوع پوسته",
        onChange: (e) => setData((prevData) => ({
          ...prevData,
          [ear]: {
            ...prevData[ear],
            shell_type: e.target.value
          }
        })),
        error: errors.shell_type,
        children: [
          /* @__PURE__ */ jsx("option", { value: "", disabled: "disabled", children: "انتخاب کنید" }),
          /* @__PURE__ */ jsx("option", { value: "cshell", children: "cshell" }),
          hasSlimtip && /* @__PURE__ */ jsx("option", { value: "Slimtip", children: "Slimtip" })
        ]
      }
    ),
    /* @__PURE__ */ jsx(InputError, { message: errors[ear + ".shell_type"], className: "mt-2" })
  ] });
};
const Description = ({ ear }) => {
  const { data, setData, errors } = useContext(AidContext);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(
      TextAreaInput,
      {
        id: `description_` + ear,
        name: `${ear}.description`,
        value: data[ear].description,
        rows: "4",
        label: "توضیحات",
        onChange: (e) => setData((prevData) => ({
          ...prevData,
          [ear]: {
            ...prevData[ear],
            description: e.target.value
          }
        })),
        error: errors.description
      }
    ),
    /* @__PURE__ */ jsx(InputError, { message: errors[ear + ".description"], className: "mt-2" })
  ] });
};
const AidInputs = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  AidSize,
  Description,
  DomeSize,
  DomeType,
  ExternalReceiverSize,
  HasMold,
  HasVent,
  MoldMaterial,
  MoldSize,
  ReceiverType,
  ShellType,
  TubeSize,
  VentSize,
  WaxGuard
}, Symbol.toStringTag, { value: "Module" }));
export {
  AidTypeStep$1 as A,
  Create$1 as C,
  PatientStep$1 as P,
  ShippingStep$1 as S,
  AudiogramStep$1 as a,
  AidStep$1 as b,
  AidInputs as c
};
