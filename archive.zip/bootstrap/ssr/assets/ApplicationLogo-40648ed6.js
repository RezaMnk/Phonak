import { a as jsx } from "../ssr.js";
function ApplicationLogo({ dark, small = false, ...props }) {
  return small ? /* @__PURE__ */ jsx("img", { ...props, src: dark ? "/storage/logo-s-white.png" : "/storage/logo-s.png", alt: "Neda Samak Ashena Logo" }) : /* @__PURE__ */ jsx("img", { ...props, src: dark ? "/storage/logo-white.png" : "/storage/logo.png", alt: "Neda Samak Ashena Logo" });
}
export {
  ApplicationLogo as A
};
