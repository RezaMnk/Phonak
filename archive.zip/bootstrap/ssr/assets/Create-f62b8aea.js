import { j as jsxs, F as Fragment, a as jsx } from "../ssr.js";
import { useContext, useState, useEffect, createContext } from "react";
import { A as Authenticated } from "./AuthenticatedLayout-c3b08c0f.js";
import { useForm, Head } from "@inertiajs/react";
import { T as TextInput } from "./TextInput-ca1f9780.js";
import { I as InputError } from "./InputError-0c916dba.js";
import { T as TextAreaInput } from "./TextAreaInput-7c309df0.js";
import { P as PrimaryButton } from "./PrimaryButton-6a55fe23.js";
import { S as SelectInput } from "./SelectInput-257ca42f.js";
import { R as RadioInput } from "./RadioInput-a6c65c03.js";
import { I as InputLabel } from "./InputLabel-b9d20af6.js";
import ProductsSlider from "./ProductsSlider-f789ee14.js";
import { D as DangerButton } from "./DangerButton-d6ee3472.js";
import { I as Icon } from "./Icon-2f3a2698.js";
function ShippingStep() {
  var _a, _b, _c, _d, _e, _f;
  const { accessory, prevStep } = useContext(StepContext);
  const { data, setData, post, processing, errors } = useForm({
    expert_phone: ((_a = accessory.shipping) == null ? void 0 : _a.expert_phone) || "",
    type: ((_b = accessory.shipping) == null ? void 0 : _b.type) || "",
    etc_delivery: ((_c = accessory.shipping) == null ? void 0 : _c.etc_delivery) || "",
    description: ((_d = accessory.shipping) == null ? void 0 : _d.description) || "",
    mail_address: ((_e = accessory.shipping) == null ? void 0 : _e.mail_address) || ((_f = accessory.shipping) == null ? void 0 : _f.address.mail_address)
  });
  const submit = (e) => {
    e.preventDefault();
    post(route("accessories.store_shipping", accessory.id), {
      preserveScroll: true
      // onSuccess: () => {
      //     nextStep()
      // }
    });
  };
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Head, { title: "سفارش - ارسال محصول" }),
    /* @__PURE__ */ jsxs("form", { className: "w-full", onSubmit: submit, children: [
      /* @__PURE__ */ jsxs("div", { className: "mt-5 text-gray-700 dark:text-slate-200", children: [
        /* @__PURE__ */ jsx("div", { className: "flex justify-between items-end", children: /* @__PURE__ */ jsx("h5", { children: "ارسال محصول" }) }),
        /* @__PURE__ */ jsx("hr", { className: "dark:border-slate-600" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-6 mb-5", children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3 ml-5", children: [
          /* @__PURE__ */ jsx(
            TextInput,
            {
              id: "expert_phone",
              name: "expert_phone",
              type: "number",
              value: data.expert_phone,
              label: "تلفن همراه شنوایی شناس",
              onChange: (e) => setData("expert_phone", e.target.value),
              error: errors.expert_phone
            }
          ),
          /* @__PURE__ */ jsxs("span", { className: "text-gray-700 dark:text-slate-300 text-xs", children: [
            /* @__PURE__ */ jsx(Icon, { className: "inline-block !w-4 !h-4 ml-1", viewBox: "0 0 24 24", type: "fill", children: /* @__PURE__ */ jsx("path", { d: "M15,8a1,1,0,0,1-1,1H6A1,1,0,0,1,6,7h8A1,1,0,0,1,15,8Zm-1,3H6a1,1,0,0,0,0,2h8a1,1,0,0,0,0-2Zm-4,4H6a1,1,0,0,0,0,2h4a1,1,0,0,0,0-2Zm13-3v8a3,3,0,0,1-3,3H4a3,3,0,0,1-3-3V4A3,3,0,0,1,4,1H16a3,3,0,0,1,3,3v7h3A1,1,0,0,1,23,12ZM17,4a1,1,0,0,0-1-1H4A1,1,0,0,0,3,4V20a1,1,0,0,0,1,1H17Zm4,9H19v8h1a1,1,0,0,0,1-1Z" }) }),
            "جهت ارسال صورتحساب"
          ] }),
          /* @__PURE__ */ jsx(InputError, { message: errors.expert_phone, className: "mt-2" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3 ml-5", children: [
          /* @__PURE__ */ jsxs(
            SelectInput,
            {
              id: "type",
              name: "type",
              value: data.type,
              label: "شیوه ارسال",
              onChange: (e) => setData("type", e.target.value),
              error: errors.type,
              children: [
                /* @__PURE__ */ jsx("option", { value: "", disabled: "disabled", children: "انتخاب کنید" }),
                /* @__PURE__ */ jsx("option", { value: "terminal", children: "ترمینالی" }),
                /* @__PURE__ */ jsx("option", { value: "air", children: "هوایی" }),
                /* @__PURE__ */ jsx("option", { value: "tipax", children: "تیپاکس" }),
                /* @__PURE__ */ jsx("option", { value: "post", children: "پست" }),
                /* @__PURE__ */ jsx("option", { value: "co-worker delivery", children: "تحویل به پیک همکار" }),
                /* @__PURE__ */ jsx("option", { value: "company delivery", children: "ارسال با پیک شرکت" }),
                /* @__PURE__ */ jsx("option", { value: "etc", children: "سایر" })
              ]
            }
          ),
          /* @__PURE__ */ jsx(InputError, { message: errors.type, className: "mt-2" })
        ] }),
        data.type === "etc" && /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-1/3", children: [
          /* @__PURE__ */ jsx(
            TextInput,
            {
              id: "etc_delivery",
              etc_delivery: "etc_delivery",
              value: data.etc_delivery,
              label: "شیوه ارسال محصول",
              onChange: (e) => setData("etc_delivery", e.target.value),
              error: errors.etc_delivery
            }
          ),
          /* @__PURE__ */ jsx(InputError, { message: errors.etc_delivery, className: "mt-2" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mt-8 text-gray-700 dark:text-slate-200", children: [
        /* @__PURE__ */ jsx("div", { className: "flex justify-between items-end", children: /* @__PURE__ */ jsx("h5", { children: "آدرس جهت ارسال" }) }),
        /* @__PURE__ */ jsx("hr", { className: "dark:border-slate-600" })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "flex mt-8", children: /* @__PURE__ */ jsxs("div", { className: "w-full ml-5 text-gray-700 dark:text-slate-200", children: [
        /* @__PURE__ */ jsx("p", { children: "مرسولات شما به کدام آدرس ارسال شوند؟" }),
        /* @__PURE__ */ jsx(InputError, { message: errors.mail_address, className: "mt-2" }),
        /* @__PURE__ */ jsxs("div", { className: "mb-5 mt-2", children: [
          /* @__PURE__ */ jsxs("div", { className: "mb-5", children: [
            /* @__PURE__ */ jsx(
              RadioInput,
              {
                className: "hidden peer",
                id: "mail_address_work",
                name: "mail_address",
                checked: data.mail_address === "work",
                onChange: () => setData("mail_address", "work")
              }
            ),
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                className: "!block md:!inline-block p-4 rounded-lg bg-gray-100 dark:bg-slate-700 peer-checked:bg-sky-100 peer-checked:dark:bg-sky-900 border border-gray-200 dark:border-slate-500 peer-checked:border-sky-400",
                htmlFor: "mail_address_work",
                children: /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("h6", { className: "font-semibold border-b pb-2", children: "محل کار" }),
                  /* @__PURE__ */ jsxs("p", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-5 xl:mt-2", children: [
                    /* @__PURE__ */ jsxs("span", { className: "inline-block", children: [
                      "استان: ",
                      accessory.shipping.address.work_state,
                      " - شهر: ",
                      accessory.shipping.address.work_city
                    ] }),
                    /* @__PURE__ */ jsxs("span", { className: "inline-block xl:mr-5", children: [
                      "آدرس: ",
                      accessory.shipping.address.work_address
                    ] }),
                    /* @__PURE__ */ jsxs("span", { className: "inline-block xl:mr-5 xl:pr-5 xl:border-r border-gray-300 dark:border-slate-600", children: [
                      "کدپستی: ",
                      accessory.shipping.address.work_post_code
                    ] }),
                    accessory.shipping.address.work_phone && /* @__PURE__ */ jsxs(
                      "span",
                      {
                        className: "inline-block xl:mr-5 xl:pr-5 xl:border-r border-gray-300 dark:border-slate-600",
                        children: [
                          "تلفن: ",
                          accessory.shipping.address.work_phone
                        ]
                      }
                    )
                  ] })
                ] })
              }
            )
          ] }),
          accessory.shipping.address.second_work_address && /* @__PURE__ */ jsxs("div", { className: "mb-5", children: [
            /* @__PURE__ */ jsx(
              RadioInput,
              {
                className: "hidden peer",
                id: "second_mail_address_work",
                name: "mail_address",
                checked: data.mail_address === "second_work",
                onChange: () => setData("mail_address", "second_work")
              }
            ),
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                className: "!block md:!inline-block p-4 rounded-lg bg-gray-100 dark:bg-slate-700 peer-checked:bg-sky-100 peer-checked:dark:bg-sky-900 border border-gray-200 dark:border-slate-500 peer-checked:border-sky-400",
                htmlFor: "second_mail_address_work",
                children: /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("h6", { className: "font-semibold border-b pb-2", children: "محل کار دوم" }),
                  /* @__PURE__ */ jsxs("p", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-5 xl:mt-2", children: [
                    /* @__PURE__ */ jsxs("span", { className: "inline-block", children: [
                      "استان: ",
                      accessory.shipping.address.second_work_state,
                      " - شهر: ",
                      accessory.shipping.address.second_work_city
                    ] }),
                    /* @__PURE__ */ jsxs("span", { className: "inline-block xl:mr-5", children: [
                      "آدرس: ",
                      accessory.shipping.address.second_work_address
                    ] }),
                    /* @__PURE__ */ jsxs("span", { className: "inline-block xl:mr-5 xl:pr-5 xl:border-r border-gray-300 dark:border-slate-600", children: [
                      "کدپستی: ",
                      accessory.shipping.address.second_work_post_code
                    ] }),
                    accessory.shipping.address.second_work_phone && /* @__PURE__ */ jsxs(
                      "span",
                      {
                        className: "inline-block xl:mr-5 xl:pr-5 xl:border-r border-gray-300 dark:border-slate-600",
                        children: [
                          "تلفن: ",
                          accessory.shipping.address.second_work_phone
                        ]
                      }
                    )
                  ] })
                ] })
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "inline-block", children: [
            /* @__PURE__ */ jsx(
              RadioInput,
              {
                className: "hidden peer",
                id: "mail_address_home",
                name: "mail_address",
                checked: data.mail_address === "home",
                onChange: () => setData("mail_address", "home")
              }
            ),
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                className: "!block md:!inline-block p-4 rounded-lg bg-gray-100 dark:bg-slate-700 peer-checked:bg-sky-100 peer-checked:dark:bg-sky-900 border border-gray-200 dark:border-slate-500 peer-checked:border-sky-400",
                htmlFor: "mail_address_home",
                children: /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("h6", { className: "font-semibold border-b pb-2", children: "محل سکونت" }),
                  /* @__PURE__ */ jsxs("p", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-5 xl:mt-2", children: [
                    /* @__PURE__ */ jsxs("span", { className: "inline-block", children: [
                      "استان: ",
                      accessory.shipping.address.home_state,
                      " - شهر: ",
                      accessory.shipping.address.home_city
                    ] }),
                    /* @__PURE__ */ jsxs("span", { className: "inline-block xl:mr-5", children: [
                      "آدرس: ",
                      accessory.shipping.address.home_address
                    ] }),
                    /* @__PURE__ */ jsxs("span", { className: "inline-block xl:mr-5 xl:pr-5 xl:border-r border-gray-300 dark:border-slate-600", children: [
                      "کدپستی: ",
                      accessory.shipping.address.home_post_code
                    ] }),
                    accessory.shipping.address.home_phone && /* @__PURE__ */ jsxs(
                      "span",
                      {
                        className: "inline-block xl:mr-5 xl:pr-5 xl:border-r border-gray-300 dark:border-slate-600",
                        children: [
                          "تلفن: ",
                          accessory.shipping.address.home_phone
                        ]
                      }
                    )
                  ] })
                ] })
              }
            )
          ] })
        ] })
      ] }) }),
      /* @__PURE__ */ jsxs("div", { className: "flex mt-16", children: [
        /* @__PURE__ */ jsx(
          TextAreaInput,
          {
            id: "description",
            name: "description",
            value: data.description,
            rows: "3",
            label: "توضیحات",
            onChange: (e) => setData("description", e.target.value),
            error: errors.description
          }
        ),
        /* @__PURE__ */ jsx(InputError, { message: errors.description, className: "mt-2" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex justify-between mt-8", children: [
        /* @__PURE__ */ jsx(
          DangerButton,
          {
            className: "!px-4 !py-2",
            type: "button",
            onClick: prevStep,
            children: "مرحله قبل"
          }
        ),
        /* @__PURE__ */ jsx(
          PrimaryButton,
          {
            className: "!px-4 !py-2",
            disabled: processing,
            type: "submit",
            children: "ذخیره و بستن سفارش"
          }
        )
      ] })
    ] })
  ] });
}
const ShippingStep$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: ShippingStep
}, Symbol.toStringTag, { value: "Module" }));
function ProductStep() {
  const { accessory, nextStep } = useContext(StepContext);
  const { data, setData, post, patch, processing, errors, clearErrors, reset } = useForm({
    brand: (accessory == null ? void 0 : accessory.brand) || "",
    count: (accessory == null ? void 0 : accessory.count) || "",
    product: (accessory == null ? void 0 : accessory.product_id) || ""
  });
  const [didMount, setDidMount] = useState(false);
  const [products, setProducts] = useState({});
  const [product, setProduct] = useState((accessory == null ? void 0 : accessory.product) || {});
  useEffect(() => {
    setDidMount(true);
  }, []);
  useEffect(() => {
    setData("product", product.id);
    clearErrors("product");
  }, [product]);
  useEffect(() => {
    if (data.brand)
      get_products();
    if (didMount) {
      reset("product");
      setProduct({});
    }
  }, [data.brand]);
  const submit = (e) => {
    e.preventDefault();
    if (accessory)
      patch(route("accessories.update", accessory.id), {
        preserveScroll: true,
        onSuccess: () => {
          nextStep();
        }
      });
    else
      post(route("accessories.store"), {
        preserveScroll: true,
        onSuccess: () => {
          nextStep();
        }
      });
  };
  const get_products = async () => {
    try {
      const response = await axios.post(route("accessories.products"), { brand: data.brand });
      let new_products = response.data.products;
      if (new_products) {
        setProducts(new_products);
      } else {
        console.log("none");
      }
    } catch (error) {
      console.log("error!");
    }
  };
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Head, { title: "سفارش - محصول" }),
    /* @__PURE__ */ jsxs("form", { className: "w-full", onSubmit: submit, noValidate: true, children: [
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col xl:flex-row space-y-5 xl:space-y-0 mt-3", children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-2/5 ml-5 text-gray-700 dark:text-slate-200", children: [
          /* @__PURE__ */ jsx("p", { children: "برند مورد سفارش:" }),
          /* @__PURE__ */ jsx(InputError, { message: errors.brand, className: "mt-2" }),
          /* @__PURE__ */ jsxs("div", { className: "mt-5 flex flex-wrap gap-10 justify-around xl:justify-start", children: [
            /* @__PURE__ */ jsxs("div", { className: "inline-block", children: [
              /* @__PURE__ */ jsx(
                RadioInput,
                {
                  id: "brand_phonak",
                  className: "hidden peer",
                  name: "brand",
                  checked: data.brand === "phonak",
                  onChange: () => setData("brand", "phonak")
                }
              ),
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "brand_phonak",
                  className: "bg-lime-500/30 dark:bg-lime-400/40 peer-checked:bg-lime-500/50 peer-checked:dark:bg-lime-400/50 border border-gray-200 dark:border-slate-500 rounded-lg peer-checked:border-green-400",
                  children: /* @__PURE__ */ jsxs("div", { className: "p-2", children: [
                    /* @__PURE__ */ jsx("img", { src: "/storage/brands/phonak.png", alt: "", className: "w-20 h-20 object-contain" }),
                    /* @__PURE__ */ jsx("hr", { className: "my-4 border-gray-200 dark:border-slate-500" }),
                    /* @__PURE__ */ jsx("p", { className: "text-center", children: "فوناک" })
                  ] })
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "inline-block", children: [
              /* @__PURE__ */ jsx(
                RadioInput,
                {
                  id: "brand_hansaton",
                  className: "hidden peer",
                  name: "brand",
                  checked: data.brand === "hansaton",
                  onChange: () => setData("brand", "hansaton")
                }
              ),
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "brand_hansaton",
                  className: "bg-red-500/30 dark:bg-red-400/40 peer-checked:bg-red-500/50 peer-checked:dark:bg-red-400/50 border border-gray-200 dark:border-slate-500 rounded-lg peer-checked:border-red-400",
                  children: /* @__PURE__ */ jsxs("div", { className: "p-2", children: [
                    /* @__PURE__ */ jsx("img", { src: "/storage/brands/hansaton.png", alt: "", className: "w-20 h-20 object-contain" }),
                    /* @__PURE__ */ jsx("hr", { className: "my-4 border-gray-200 dark:border-slate-500" }),
                    /* @__PURE__ */ jsx("p", { className: "text-center", children: "هنزاتون" })
                  ] })
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "inline-block", children: [
              /* @__PURE__ */ jsx(
                RadioInput,
                {
                  id: "brand_rayovac",
                  className: "hidden peer",
                  name: "brand",
                  checked: data.brand === "rayovac",
                  onChange: () => setData("brand", "rayovac")
                }
              ),
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "brand_rayovac",
                  className: "bg-stone-500/30 dark:bg-stone-400/40 peer-checked:bg-stone-500/50 peer-checked:dark:bg-stone-400/50 border border-gray-200 dark:border-slate-500 rounded-lg peer-checked:border-stone-400",
                  children: /* @__PURE__ */ jsxs("div", { className: "p-2", children: [
                    /* @__PURE__ */ jsx("img", { src: "/storage/brands/rayovac.png", alt: "", className: "w-20 h-20 object-contain" }),
                    /* @__PURE__ */ jsx("hr", { className: "my-4 border-gray-200 dark:border-slate-500" }),
                    /* @__PURE__ */ jsx("p", { className: "text-center", children: "ریواک" })
                  ] })
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "inline-block", children: [
              /* @__PURE__ */ jsx(
                RadioInput,
                {
                  id: "brand_detax",
                  className: "hidden peer",
                  name: "brand",
                  checked: data.brand === "detax",
                  onChange: () => setData("brand", "detax")
                }
              ),
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "brand_detax",
                  className: "bg-slate-500/30 dark:bg-slate-300/40 peer-checked:bg-slate-500/50 peer-checked:dark:bg-slate-300/50 border border-gray-200 dark:border-slate-500 rounded-lg peer-checked:border-slate-400",
                  children: /* @__PURE__ */ jsxs("div", { className: "p-2", children: [
                    /* @__PURE__ */ jsx("img", { src: "/storage/brands/detax.png", alt: "", className: "w-20 h-20 object-contain" }),
                    /* @__PURE__ */ jsx("hr", { className: "my-4 border-gray-200 dark:border-slate-500" }),
                    /* @__PURE__ */ jsx("p", { className: "text-center", children: "دیتاکس" })
                  ] })
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "inline-block", children: [
              /* @__PURE__ */ jsx(
                RadioInput,
                {
                  id: "brand_etc",
                  className: "hidden peer",
                  name: "brand",
                  checked: data.brand === "etc",
                  onChange: () => setData("brand", "etc"),
                  required: true
                }
              ),
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "brand_etc",
                  className: "bg-purple-500/30 dark:bg-purple-400/40 peer-checked:bg-purple-500/50 peer-checked:dark:bg-purple-400/50 border border-gray-200 dark:border-slate-500 rounded-lg peer-checked:border-purple-400",
                  children: /* @__PURE__ */ jsxs("div", { className: "p-2", children: [
                    /* @__PURE__ */ jsx("img", { src: "/storage/brands/etc.png", alt: "", className: "w-20 h-20 object-contain" }),
                    /* @__PURE__ */ jsx("hr", { className: "my-4 border-gray-200 dark:border-slate-500" }),
                    /* @__PURE__ */ jsx("p", { className: "text-center", children: "سایر" })
                  ] })
                }
              )
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-3/5 flex flex-col space-y-5 xl:space-y-0", children: [
          /* @__PURE__ */ jsx("p", { className: "mb-5 text-gray-700 dark:text-slate-200", children: "محصولات:" }),
          Object.keys(products).length === 0 && /* @__PURE__ */ jsx("p", { className: "text-lg text-gray-700 dark:text-slate-300", children: "با اطلاعات وارد شده، محصول قابل سفارشی برای گروه شما وجود ندارد!" }),
          /* @__PURE__ */ jsxs("div", { className: `transition-all ${!(accessory == null ? void 0 : accessory.product_id) && "ease-in-out duration-500"} ${Object.keys(products).length ? "max-h-full" : "max-h-0"} overflow-hidden`, children: [
            /* @__PURE__ */ jsx(ProductsSlider, { products, setProduct, product: product.id, error: errors.product }),
            /* @__PURE__ */ jsx(InputError, { message: errors.product, className: "mt-2" })
          ] })
        ] })
      ] }),
      product.has_count === 1 && /* @__PURE__ */ jsx("div", { className: "flex mt-5", children: /* @__PURE__ */ jsx("div", { className: "w-full flex", children: /* @__PURE__ */ jsxs("div", { className: "w-1/3 ml-5", children: [
        /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "count",
            type: "number",
            name: "count",
            value: data.count,
            label: "تعداد مورد سفارش",
            onChange: (e) => setData("count", e.target.value),
            error: errors.count,
            required: true
          }
        ),
        /* @__PURE__ */ jsx(InputError, { message: errors.count, className: "mt-2" })
      ] }) }) }),
      /* @__PURE__ */ jsx("div", { className: "flex justify-end mt-8", children: /* @__PURE__ */ jsx(
        PrimaryButton,
        {
          className: "!px-4 !py-2",
          disabled: processing,
          type: "submit",
          children: "مرحله بعد"
        }
      ) })
    ] })
  ] });
}
const ProductStep$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: ProductStep
}, Symbol.toStringTag, { value: "Module" }));
const StepContext = createContext();
function Create({ accessory }) {
  const [step, setStep] = useState(parseInt(new URLSearchParams(window.location.search).get("step")) || 1);
  const prevStep = () => {
    setStep((prev) => prev - 1);
  };
  useEffect(() => {
    const searchParams = new URLSearchParams(window.location.search);
    searchParams.set("step", step);
    const newUrl = `${window.location.pathname}?${searchParams.toString()}`;
    window.history.replaceState(null, "", newUrl);
  }, [step]);
  const nextStep = () => {
    setStep((prev) => prev + 1);
  };
  const showStep = () => {
    switch (step) {
      case 1:
        return /* @__PURE__ */ jsx(ProductStep, {});
      case 2:
        return /* @__PURE__ */ jsx(ShippingStep, {});
    }
  };
  return /* @__PURE__ */ jsx(
    Authenticated,
    {
      header: /* @__PURE__ */ jsx(Fragment, { children: "ایجاد کاربر" }),
      breadcrumbs: {
        "سفارشات لوازم جانبی": route("accessories.index"),
        [accessory ? "ویرایش سفارش" : "ایجاد سفارش"]: "#"
      },
      children: /* @__PURE__ */ jsx("div", { className: "flex flex-col sm:justify-center items-center", children: /* @__PURE__ */ jsx("div", { className: "w-full px-6 py-4 bg-white dark:bg-slate-800 border border-white dark:border-slate-600 sm:rounded-lg", children: /* @__PURE__ */ jsx(StepContext.Provider, { value: { accessory, prevStep, nextStep }, children: showStep() }) }) })
    }
  );
}
const Create$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  StepContext,
  default: Create
}, Symbol.toStringTag, { value: "Module" }));
export {
  Create$1 as C,
  ProductStep$1 as P,
  ShippingStep$1 as S
};
